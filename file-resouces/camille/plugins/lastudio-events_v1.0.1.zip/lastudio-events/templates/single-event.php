<?php
/**
 * The Template for displaying the single event posts.
 *
 * @package WordPress
 * @subpackage LaStudio Events
 * @since LaStudio Events 1.0.0
 */
get_header( 'events' );
?>
	single event
<?php
get_footer( 'events' );
?>