== LaStudio Playlist ==
Contributors: lastudio
Tags: page builder
Requires at least: 4.9
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin to manage your playlists

== Installation ==

1. Upload the `lastduio-playlist-manager` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Being a free product, this plugin is distributed as-is without official support.
Verified customers however, who have purchased a premium theme on [ThemeForest](https://themeforest.net/user/la-studio/portfolio?ref=la-studio) will have access to the [support forums](https://support.la-studioweb.com/).

== Changelog ==

#### 8th May 2018 - Version 1.0.0

* Initial release