<?php
/**
 * LaStudio Playlist Uninstall
 *
 * Uninstalling LaStudio Playlist
 *
 * @author LaStudio
 * @category Core
 * @package LaStudiolistManager/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}