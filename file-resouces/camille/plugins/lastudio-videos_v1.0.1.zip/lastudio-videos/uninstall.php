<?php
/**
 * LaStudio Videos Uninstall
 *
 * Uninstalling LaStudio Videos
 *
 * @author LaStudio
 * @category Core
 * @package LaStudioVideos/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}