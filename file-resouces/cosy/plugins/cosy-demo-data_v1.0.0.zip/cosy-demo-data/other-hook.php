<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


add_filter('cosy/filter/product_per_page', 'cosy_preset_product_per_page');
function cosy_preset_product_per_page( $value ){
    if(isset($_GET['la_preset']) && ( $_GET['la_preset'] == 'shop-fullwidth' || $_GET['la_preset'] == 'shop-fullwidth2')){
        return 10;
    }
    return $value;
}


add_filter('cosy/setting/get_setting_by_context', 'cosy_preset_custom_bottom_block', 10, 3);

function cosy_preset_custom_bottom_block( $value, $key, $context ){
    if( $key == 'block_content_bottom' ){
        if( !in_array('is_page', $context) && !in_array('is_404', $context)){
            return 122;
        }
    }
    return $value;
}

add_filter('body_class', 'cosy_preset_add_body_classes');

function cosy_preset_add_body_classes( $class ){
    $class[] = 'isLaWebRoot';
    return $class;
}

add_filter('pre_option_posts_per_page', 'cosy_preset_pre_option_posts_per_page', 10, 2);
function cosy_preset_pre_option_posts_per_page( $value, $option_name ){
    if(isset($_GET['la_preset']) && ( $_GET['la_preset'] == 'blog3' )){
        return 6;
    }
    return $value;
}

add_filter( 'get_avatar_url', 'cosy_preset_new_gravatar', 10, 3);
function cosy_preset_new_gravatar ( $url, $id_or_email, $args ) {

    if ( is_object( $id_or_email ) && isset( $id_or_email->comment_author_email ) ) {
        if ( strpos($id_or_email->comment_author_email, 'la-studioweb.com') !== false ){
            return home_url('/wp-content/uploads/2017/04/avatar.png');
        }
        if ( $id_or_email->comment_author_email == 'info@localhost.com' ){
            return Cosy::$template_dir_url . '/assets/images/avatar-1.jpg';
        }
        if ( $id_or_email->comment_author_email == 'info2@localhost.com' ){
            return Cosy::$template_dir_url . '/assets/images/avatar-2.jpg';
        }
    }
    if ( $id_or_email == 'dpv.0990@gmail.com' ){
        return Cosy::$template_dir_url . '/assets/images/avatar.jpg';
    }
    return $url;

}

add_action( 'pre_get_posts', 'cosy_preset_change_blog_posts' );
function cosy_preset_change_blog_posts( $query ){
    if(isset($_GET['la_preset']) && ( $_GET['la_preset'] == 'blog2' || $_GET['la_preset'] == 'blog5')){
        if ( $query->is_home() && $query->is_main_query() ) {
            $query->set( 'post__not_in', array(681) );
        }
    }
}

add_filter('cosy/filter/blog/post_thumbnail', 'cosy_preset_modify_thumbnail_for_blog_masonry', 10, 2);
function cosy_preset_modify_thumbnail_for_blog_masonry( $size, $loop ){
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog5' && isset($loop['loop_index'])){
        $idx = absint($loop['loop_index']);
        $ref = array(
            array(370,260),
            array(370,200),
            array(370,260),
            array(370,200),
            array(370,305),
            array(370,250),
            array(370,250),
            array(370,260),
            array(370,250),
            array(370,250),
            array(370,200)
        );
        if(isset($ref[$idx-1])){
            return $ref[$idx-1];
        }
    }
    return $size;
}