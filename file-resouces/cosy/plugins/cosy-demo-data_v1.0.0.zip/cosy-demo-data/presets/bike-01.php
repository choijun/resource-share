<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_bike_01(){
    return array(
        array(
            'key' => 'logo',
            'value' => 915
        ),
        array(
            'key' => 'logo_2x',
            'value' => 916
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 917
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 918
        ),
        array(
            'key' => 'header_layout',
            'value' => 3
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_1',
            'value' => 'bike-footer-1'
        )
    );
}