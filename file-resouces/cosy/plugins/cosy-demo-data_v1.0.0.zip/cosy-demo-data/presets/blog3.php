<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_blog3(){
    return array(
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_1'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '570x360'
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => 25
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg' => 2,
                'lg' => 2,
                'md' => 2,
                'sm' => 2,
                'xs' => 1,
                'mb' => 1
            )
        ),
        array(
            'filter_name' => 'cosy/filter/page_title',
            'value' => '<header><div class="page-title h1">BLOG 2 COLUMNS</div></header>'
        )
    );
}