<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_blog4(){
    return array(
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_small_layout',
            'value' => 'on'
        ),
        array(
            'filter_name' => 'cosy/filter/page_title',
            'value' => '<header><div class="page-title h1">BLOG NO SIDEBAR</div></header>'
        )
    );
}