<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_electronic_01(){
    return array(
        array(
            'key' => 'logo',
            'value' => 987
        ),
        array(
            'key' => 'logo_2x',
            'value' => 988
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 987
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 988
        ),
        array(
            'key' => 'header_layout',
            'value' => 4
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'woocommerce_show_rating_on_catalog',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row"><div class="col-xs-12"><div class="small text-center letter-spacing-2 text-uppercase">© 2017 Created by LaStudio</div></div></div>'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#232324'
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array (
            'key' => 'text_color',
            'value' => '#8a8a8a',
        ),
        array (
            'key' => 'border_color',
            'value' => 'rgba(138, 138, 138, 0.3)',
        ),
        array (
            'key' => 'primary_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'header_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'mm_lv_1_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'header_top_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'transparency_header_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'offcanvas_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'mb_lv_1_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'mb_lv_2_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'page_title_bar_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'footer_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'footer_copyright_link_hover_color',
            'value' => '#5e7de4',
        ),
        array (
            'key' => 'la_custom_css',
            'value' => '.la-footer-3col444 .footer-bottom { border: none } .site-footer .widget .widget-title { font-size: 18px; letter-spacing: 1px}',
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_1',
            'value' => 'electronic-footer-1'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_2',
            'value' => 'sport-footer-3'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_3',
            'value' => 'sport-footer-4'
        )
    );
}