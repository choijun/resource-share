<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_fashion_01(){
    return array(
        array(
            'key' => 'logo',
            'value' => 847
        ),
        array(
            'key' => 'logo_2x',
            'value' => 848
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 847
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 848
        ),
        array(
            'key' => 'header_layout',
            'value' => 5
        )
    );
}