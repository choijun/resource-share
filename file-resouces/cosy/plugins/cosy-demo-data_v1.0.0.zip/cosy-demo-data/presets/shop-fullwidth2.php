<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_shop_fullwidth2(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 5,
                'lg' => 5,
                'md' => 4,
                'sm' => 3,
                'xs' => 1,
                'mb' => 1
            )
        ),
        array(
            'key' => 'page_title_bar_layout',
            'value' => 1
        ),
        array(
            'key' => 'page_title_bar_background',
            'value' => array(
                'image' => Cosy_Data_Demo_Plugin_Class::$plugin_dir_url . '/assets/images/m-bg-page-title-bg.jpg',
                'size' => 'cover'
            )
        ),
        array(
            'key' => 'page_title_bar_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'page_title_bar_text_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'page_title_bar_link_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => 75,
                'bottom' => 75
            )
        ),
        array(
            'key' => 'shop_catalog_grid_style',
            'value' => 2
        ),
        array(
            'key' => 'product_per_page_allow',
            'value' => '10,15,30'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.section-page-header .page-title{ margin-bottom: 10px}'
        ),
        array(
            'filter_name' => 'cosy/filter/page_title',
            'value' => '<header><div class="page-title h1">SHOP FULLWIDTH</div></header>'
        )
    );
}

