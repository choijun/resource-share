<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_shop_sidebar2(){
    return array(
        array(
            'key' => 'layout_archive_product',
            'value' => 'col-2cl'
        ),
        array(
            'key' => 'shop_catalog_display_type',
            'value' => 'list'
        ),
        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 4,
                'lg' => 3,
                'md' => 3,
                'sm' => 3,
                'xs' => 1,
                'mb' => 1
            )
        ),
        array(
            'filter_name' => 'cosy/filter/page_title',
            'value' => '<header><div class="page-title h1">SHOP SIDEBAR</div></header>'
        )
    );
}

