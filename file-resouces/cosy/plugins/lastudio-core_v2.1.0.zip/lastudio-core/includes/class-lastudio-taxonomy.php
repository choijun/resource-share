<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Taxonomy Class
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class LaStudio_Taxonomy{

  /**
   *
   * taxonomy options
   * @access public
   * @var array
   *
   */
  public $options = array();

  /**
   *
   * instance
   * @access private
   * @var class
   *
   */
  private static $instance = null;

  // run taxonomy construct
  public function __construct( $options ) {

    $this->options = $options;

    if( ! empty( $this->options ) ) {
      add_action( 'admin_init', array( &$this, 'add_taxonomy_fields') );
    }

  }

  // instance
  public static function instance( $options = array() ) {
    if ( is_null( self::$instance ) ) {
      self::$instance = new self( $options );
    }
    return self::$instance;
  }

  // add taxonomy add/edit fields
  public function add_taxonomy_fields() {

    foreach ( $this->options as $option ) {

      $opt_taxonomy = $option['taxonomy'];
      $get_taxonomy = la_get_var( 'taxonomy' );

      if( $get_taxonomy == $opt_taxonomy ) {

        add_action( $opt_taxonomy .'_add_form_fields', array( &$this, 'render_taxonomy_form_fields') );
        add_action( $opt_taxonomy .'_edit_form', array( &$this, 'render_taxonomy_form_fields') );

        add_action( 'created_'. $opt_taxonomy, array( &$this, 'save_taxonomy') );
        add_action( 'edited_'. $opt_taxonomy, array( &$this, 'save_taxonomy') );
        add_action( 'delete_'. $opt_taxonomy, array( &$this, 'delete_taxonomy') );

      }

    }

  }

  // render taxonomy add/edit form fields
  public function render_taxonomy_form_fields( $term ) {

    global $la_errors;

    $form_edit = ( is_object( $term ) && isset( $term->taxonomy ) ) ? true : false;
    $taxonomy  = ( $form_edit ) ? $term->taxonomy : $term;
    $classname = ( $form_edit ) ? 'edit' : 'add';
    $la_errors = get_transient( 'la-taxonomy-transient' );

    wp_nonce_field( 'la-taxonomy', 'la-taxonomy-nonce' );

    echo '<div class="la-framework la-taxonomy la-taxonomy-'. $classname .'-fields">';

      foreach( $this->options as $option ) {

        if( $taxonomy == $option['taxonomy'] ) {

          $tax_value = ( $form_edit ) ? get_term_meta( $term->term_id, $option['id'], true ) : '';

          foreach ( $option['fields'] as $field ) {

            $default    = ( isset( $field['default'] ) ) ? $field['default'] : '';
            $elem_id    = ( isset( $field['id'] ) ) ? $field['id'] : '';
            $elem_value = ( is_array( $tax_value ) && isset( $tax_value[$elem_id] ) ) ? $tax_value[$elem_id] : $default;

            echo la_fw_add_element( $field, $elem_value, $option['id'] );

          }

        }

      }

    echo '</div>';

  }

  // save taxonomy form fields
  public function save_taxonomy( $term_id ) {

    if ( wp_verify_nonce( la_get_var( 'la-taxonomy-nonce' ), 'la-taxonomy' ) ) {

      $errors = array();
      $taxonomy = la_get_var( 'taxonomy' );

      foreach ( $this->options as $request_value ) {

        if( $taxonomy == $request_value['taxonomy'] ) {

          $request_key = $request_value['id'];
          $request = la_get_var( $request_key, array() );

          // ignore _nonce
          if( isset( $request['_nonce'] ) ) {
            unset( $request['_nonce'] );
          }

          if( isset( $request_value['fields'] ) ) {

            foreach( $request_value['fields'] as $field ) {

              if( isset( $field['type'] ) && isset( $field['id'] ) ) {

                $field_value = la_get_vars( $request_key, $field['id'] );

                // sanitize options
                if( isset( $field['sanitize'] ) && $field['sanitize'] !== false ) {
                  $sanitize_type = $field['sanitize'];
                } else if ( ! isset( $field['sanitize'] ) ) {
                  $sanitize_type = $field['type'];
                }

                if( has_filter( 'la_sanitize_'. $sanitize_type ) ) {
                  $request[$field['id']] = apply_filters( 'la_sanitize_' . $sanitize_type, $field_value, $field, $request_value['fields'] );
                }

                // validate options
                if ( isset( $field['validate'] ) && has_filter( 'la_validate_'. $field['validate'] ) ) {

                  $validate = apply_filters( 'la_validate_' . $field['validate'], $field_value, $field, $request_value['fields'] );

                  if( ! empty( $validate ) ) {

                    $meta_value = get_term_meta( $term_id, $request_key, true );

                    $errors[$field['id']] = array( 'code' => $field['id'], 'message' => $validate, 'type' => 'error' );
                    $default_value = isset( $field['default'] ) ? $field['default'] : '';
                    $request[$field['id']] = ( isset( $meta_value[$field['id']] ) ) ? $meta_value[$field['id']] : $default_value;

                  }

                }

              }

            }

          }

          $request = apply_filters( 'la_save_taxonomy', $request, $request_key, $term_id );

          if( empty( $request ) ) {

            delete_term_meta( $term_id, $request_key );

          } else {

            if( get_term_meta( $term_id, $request_key, true ) ) {

              update_term_meta( $term_id, $request_key, $request );

            } else {

              add_term_meta( $term_id, $request_key, $request );

            }

          }

        }

      }

      set_transient( 'la-taxonomy-transient', $errors, 10 );

    }

  }

  // delete taxonomy
  public function delete_taxonomy( $term_id ) {

    $taxonomy = la_get_var( 'taxonomy' );

    if( ! empty( $taxonomy ) ) {

      foreach ( $this->options as $request_value ) {

        if( $taxonomy == $request_value['taxonomy'] ) {

          $request_key = $request_value['id'];

          delete_term_meta( $term_id, $request_key );

        }

      }

    }

  }

}
