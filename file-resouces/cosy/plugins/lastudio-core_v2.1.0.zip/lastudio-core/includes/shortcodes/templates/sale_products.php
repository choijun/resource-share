<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$query_args = array(
    'posts_per_page'	=> $atts['per_page'],
    'orderby' 			=> $atts['orderby'],
    'order' 			=> $atts['order'],
    'no_found_rows' 	=> 1,
    'post_status' 		=> 'publish',
    'post_type' 		=> 'product',
    'paged'             => $atts['paged'],
    'meta_query' 		=> WC()->query->get_meta_query(),
    'post__in'			=> array_merge( array( 0 ), wc_get_product_ids_on_sale() )
);
if(!empty($atts['category__in'])){
    $query_args['tax_query'] = array(
        array(
            'taxonomy' 		=> 'product_cat',
            'terms' 		=> array_map( 'sanitize_title', explode( ',', $atts['category__in'] ) ),
            'field' 		=> 'term_id'
        )
    );
}

LaStudio_Shortcodes_Helper::getLoopProducts($query_args, $atts, $this->getShortcode());