<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_blog_05()
{
    return array(

        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'blog_design',
            'value' => 'grid_6'
        ),

        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => '210',
                'bottom' => '135'
            )
        ),

        array(
            'key' => 'page_title_bar_spacing_desktop_small',
            'value' => array(
                'top' => '210',
                'bottom' => '135'
            )
        ),

        array(
            'key' => 'blog_thumbnail_height_mode',
            'value' => 'custom'
        ),

        array(
            'key' => 'blog_thumbnail_height_custom',
            'value' => '45%'
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
#section_page_header{
    background-image: linear-gradient(-134deg, #EB3F5C 0%, #C86DD7 100%);
}
#section_page_header,
#section_page_header a,
#section_page_header .page-title{
    color: #fff;
}

div#main {
    background-color: #F9F9F9;
}

@media(min-width: 1500px){
    div#main {
        padding-top: 100px;
        padding-bottom: 100px;
    }
}
.blog-main-loop .format-quote.has-post-thumbnail .loop__item__thumbnail--bkg {
    display: none;
}
.blog-main-loop .format-quote.has-post-thumbnail .quote-wrapper {
    position: static;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}