<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_03()
{
    return array(
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),

        array(
            'key' => 'header_layout',
            'value' => 'pre-header-03'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '2769'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#2F21B3'
        ),

        array(
            'key'   => 'main_font|secondary_font',
            'value' => array(
                'family' => 'Abel',
                'font' => 'google'
            )
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.enable-header-transparency .lahfb-wrap:not(.is-sticky) .lahfb-nav-wrap .menu > li.current > a,
.enable-header-transparency .lahfb-wrap:not(.is-sticky) .lahfb-nav-wrap .menu > li > a:hover {
    color: #fff;
}

.responav > li.menu-item > a,
.lahfb-nav-wrap .menu > li.menu-item > a {
    text-transform: uppercase;
}

.hamburger-menu-wrap.hm-dark{
    color: rgba(255, 255, 255, 0.8);
}

.responav li.menu-item.current > a,
.responav li.menu-item > a:hover,
.responav li.menu-item > ul li > a:hover,
.hamburger-menu-wrap .hamburger-nav li a:hover,
.lahfb-wrap .lahfb-nav-wrap .menu li.current ul li a:hover, 
.lahfb-wrap .lahfb-nav-wrap .menu ul.sub-menu li.current > a, 
.lahfb-wrap .lahfb-nav-wrap .menu ul li.menu-item:hover > a{
    color: #fff;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
    );
}