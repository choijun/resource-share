<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_12()
{
    return array(
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),
        array(
            'key' => 'header_layout',
            'value' => 'pre-header-06'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#11CCD3'
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.rev_slider .tp-caption.rev-btn{
    transition: all .3s !important;
}
.rev_slider .tp-caption.rev-btn i {
    font-size: 40px;
    font-weight: bold;
    height: 40px;
    width: 40px;
    top: 12px;
    position: relative;
    left: -10px;
}

@media(max-width: 778px){
.rev_slider .tp-caption.rev-btn i{
    display: none;
}
}

';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
    );
}