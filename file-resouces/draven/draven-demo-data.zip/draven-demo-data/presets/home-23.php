<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_23()
{
    return array(
        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_layout',
            'value' => 'pre-header-05'
        ),
        array(
            'key' => 'enable_header_mb_footer_bar',
            'value' => 'no'
        ),
    );
}