<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_28()
{
    return array(

        array(
            'key' => 'primary_color',
            'value' => '#FFD600'
        ),

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),

        array(
            'key' => 'header_layout',
            'value' => 'pre-header-01'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '2753'
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.enable-header-transparency .lahfb-wrap:not(.is-sticky) .lahfb-desktop-view .lahfb-row1-area .lahfb-element{
    color: inherit;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
    );
}