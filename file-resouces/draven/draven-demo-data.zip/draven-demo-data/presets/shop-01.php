<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_shop_01()
{
    return array(

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 4,
                'lg' => 4,
                'md' => 4,
                'sm' => 3,
                'xs' => 2,
                'mb' => 1
            )
        ),

        array(
            'filter_name' => 'draven/filter/page_title',
            'value' => '<header><h1 class="page-title">Shop</h1></header>'
        ),
    );
}