<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


add_filter('woocommerce_product_related_posts_relate_by_category', '__return_false');
add_filter('woocommerce_product_related_posts_relate_by_tag', '__return_false');
add_filter('woocommerce_product_related_posts_force_display', '__return_true');


add_filter('body_class', 'helas_preset_add_body_classes');

function helas_preset_add_body_classes( $class ){
    $class[] = 'isLaWebRoot';
    return $class;
}

add_action( 'pre_get_posts', 'helas_preset_change_blog_posts' );
function helas_preset_change_blog_posts( $query ){

    if($query->is_home() && $query->is_main_query()){

        if(isset($_GET['la_preset'])){
            if($_GET['la_preset'] == 'blog-metro'){
                $query->set( 'category__in', array(90) );
                $query->set( 'posts_per_page', 5 );
            }

            if($_GET['la_preset'] == 'blog-1-column'){
                $query->set( 'category__in', array(92) );
                $query->set( 'posts_per_page', 5 );
            }

            if($_GET['la_preset'] == 'blog-2-columns'){
                $query->set( 'category__in', array(96) );
                $query->set( 'posts_per_page', 6 );
            }
            if($_GET['la_preset'] == 'blog-left-sidebar'){
                $query->set( 'category__in', array(90,92,96) );
                $query->set( 'posts_per_page', 4 );
            }
            if($_GET['la_preset'] == 'blog-masonry'){
                $query->set( 'category__in', array(90,92,96) );
                $query->set( 'posts_per_page', 8 );
            }
        }


        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-02'){
            $query->set( 'category__in', array(59) );
            $query->set( 'posts_per_page', 5 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-03'){
            $query->set( 'posts_per_page', 16 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-04'){
            $query->set( 'posts_per_page', 12 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-05'){
            $query->set( 'category__in', array(62,58,59) );
            $query->set( 'posts_per_page', 8 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-06'){
            $query->set( 'category__in', array(62,58,59) );
            $query->set( 'posts_per_page', 6 );
        }

    }

}

add_action( 'woocommerce_product_query', 'helas_demo_product_query', 20);
function helas_demo_product_query( $q ){
    if(is_shop()){
        if(!isset($_GET['orderby']) || ( isset($_GET['orderby']) && $_GET['orderby'] != 'date' )){
            $q->set( 'orderby', 'date' );
            $q->set( 'order', 'ASC' );
        }
    }
}

add_filter( 'helas/filter/page_title', 'helas_demo_modify_product_page_title', 10, 12 );
function helas_demo_modify_product_page_title( $title ) {
    if(is_singular('product')){
        global $product;
        return sprintf( '<header><div class="text-uppercase page-title h3">%s</div></header>', $product->get_type() . ' Product' );
    }
    return $title;
}