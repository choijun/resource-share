<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_blog_1_column()
{
    return array(

        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),

        array(
            'key' => 'main_space',
            'value' => array(
                'top' => '100',
                'bottom' => '0'
            )
        ),

        array(
            'key' => 'blog_design',
            'value' => 'grid_5'
        ),
        array(
            'key' => 'format_content_blog',
            'value' => 'on'
        ),

        array(
            'key' => 'blog_thumbnail_size',
            'value' => '1170x490'
        ),

        array(
            'key' => 'blog_excerpt_length',
            'value' => 24
        ),

        array(
            'filter_name' => 'helas/filter/page_title',
            'value' => '<header><div class="page-title h3">Blog 01 Column</div></header>'
        ),
        
    );
}