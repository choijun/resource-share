<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_blog_metro()
{
    return array(

        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),

        array(
            'key' => 'main_space',
            'value' => array(
                'top' => '0',
                'bottom' => '0'
            )
        ),

        array(
            'key' => 'blog_design',
            'value' => 'grid_9'
        ),

        array(
            'key' => 'blog_thumbnail_size',
            'value' => '960x590'
        ),

        array(
            'key' => 'blog_excerpt_length',
            'value' => 24
        ),

        array(
            'filter_name' => 'helas/filter/page_title',
            'value' => '<header><div class="page-title h3">Blog Metro</div></header>'
        ),

    );
}