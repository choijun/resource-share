<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_02()
{
    return array(

        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '1col'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color'     => '#f7f7f7',
                'image'     => '//helas.la-studioweb.com/wp-content/uploads/2017/12/bg-white-radius.png',
                'repeat'    => 'no-repeat',
                'position'  => 'top center'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '60px',
                'padding_bottom' => '0px',
            )
        ),

        array(
            'key' => 'footer_text_color',
            'value' => '#8a8a8a'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => '#36393e'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row"><div class="col-xs-12"><div class="font-size-10 text-uppercase text-center letter-spacing-5">2018 Created by LaStudio</div></div></div>'
        ),

        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#f7f7f7'
        ),

        array(
            'key' => 'footer_copyright_text_color',
            'value' => '#8a8a8a'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'helas/filter/footer_column_1',
            'value' => 'home-01-footer-column'
        ),

        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '

                ';

                return $value;
            },
            'filter_priority'  => 20,
            'filter_args'  => 3
        ),
    );
}