<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_03()
{
    return array(

        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '4col3333'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row"><div class="col-xs-12"><div class="font-size-10 text-uppercase text-center letter-spacing-2">&copy; Helas Theme by LaStudio. All Right Reserved 2018.</div></div></div>'
        ),

        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#f7f7f7'
        ),
        array(
            'key' => 'footer_copyright_text_color|footer_copyright_link_color',
            'value' => 'rgba(86, 86, 86, 0.5)'
        )
        /**
         * Filters
         */



    );
}