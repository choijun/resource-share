<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_08()
{
    return array(

        array(
            'key' => 'logo_transparency',
            'value' => '328'
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => '329'
        ),
        array(
            'key' => 'logo_mobile_transparency',
            'value' => '328'
        ),
        array(
            'key' => 'logo_mobile_transparency_2x',
            'value' => '329'
        ),

        array(
            'key' => 'header_layout',
            'value' => '2'
        ),

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'yes'
        ),


        array(
            'key' => 'transparency_header_text_color|transparency_header_link_color|transparency_mm_lv_1_color|transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color'     => '#121220',
                'repeat'    => 'no-repeat',
                'position'  => 'top center'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '60px',
                'padding_bottom' => '30px',
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => 'rgba(138, 138, 138, 1)'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => 'rgba(138, 138, 138, 0.4)'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => 'rgba(138, 138, 138, 0.4)'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => 'rgba(138, 138, 138, 1)'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'helas/filter/footer_column_1',
            'value' => 'home-08-footer-column-1'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_2',
            'value' => 'home-08-footer-column-2'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_3',
            'value' => 'home-08-footer-column-3'
        ),


        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.la-contact-info.icon-color-primary .la-contact-item:before {
    color: rgba(211, 180, 140, 0.5);
}
                ';

                return $value;
            },
            'filter_priority'  => 20,
            'filter_args'  => 3
        ),
    );
}