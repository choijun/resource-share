<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_10()
{
    return array(

        array(
            'key' => 'logo',
            'value' => '328'
        ),
        array(
            'key' => 'logo_2x',
            'value' => '329'
        ),
        array(
            'key' => 'logo_mobile',
            'value' => '328'
        ),
        array(
            'key' => 'logo_mobile_transparency',
            'value' => '329'
        ),

        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),


        array(
            'key' => 'footer_layout',
            'value' => '5col32223'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),


        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#0e1219'
            )
        ),
        array(
            'key' => 'header_text_color|header_link_color|mm_lv_1_color|mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#d3b48c'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color'     => '#232324',
                'repeat'    => 'no-repeat',
                'position'  => 'top center'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '65px',
                'padding_bottom' => '25px',
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => 'rgba(255,255,255,0.6)'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => 'rgba(255,255,255,0.6)'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'main_google_font_face|secondary_google_font_face',
            'value' => 'Montserrat'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'helas/filter/footer_column_1',
            'value' => 'home-06-footer-column-1'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_2',
            'value' => 'home-06-footer-column-2'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_3',
            'value' => 'home-06-footer-column-3'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_4',
            'value' => 'home-06-footer-column-4'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_5',
            'value' => 'home-06-footer-column-5'
        ),

        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value = '
@import url(https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i|Playfair+Display:400,400i,700,700i);
.site-main-nav .main-menu > li > a {
    text-transform: uppercase;
    font-size: 14px;
    letter-spacing: 1px;
}
.footer-top {
    font-size: 10px;
    letter-spacing: 1px;
}
.site-footer .widget .widget-title{
    font-size: 14px;
    font-family: inherit;
    letter-spacing: 2px;
    margin-bottom: 35px;
}
.site-footer ul li{
    margin-bottom: 30px;
}
.footer-top .container {
    width: 1500px;
}
                ';

                return $value;
            },
            'filter_priority'  => 20,
            'filter_args'  => 3
        ),
    );
}