<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_12()
{
    return array(

        array(
            'key' => 'logo',
            'value' => '792'
        ),
        array(
            'key' => 'logo_2x',
            'value' => '793'
        ),
        array(
            'key' => 'header_layout',
            'value' => '3'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'store_working_hours',
            'value' => 'MON-SAT:8AM TO 9PM'
        ),
        array(
            'key' => 'store_email',
            'value' => 'INFO@DOMAIN.COM'
        ),
        array(
            'key' => 'store_phone',
            'value' => '+56.653.534'
        ),



        array(
            'key' => 'footer_layout',
            'value' => '1col'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color'     => '#f7f7f7',
                'image'     => '//helas.la-studioweb.com/wp-content/uploads/2018/01/m12-bg-2.jpg',
                'repeat'    => 'no-repeat',
                'position'  => 'top center',
                'size'      => 'cover'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '50px',
                'padding_bottom' => '0px',
            )
        ),

        array(
            'key' => 'footer_text_color',
            'value' => '#8a8a8a'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => '#36393e'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'helas/filter/footer_column_1',
            'value' => 'home-12-footer-column-1'
        ),

        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '

                ';

                return $value;
            },
            'filter_priority'  => 20,
            'filter_args'  => 3
        ),
    );
}