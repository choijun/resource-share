<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_13()
{
    return array(

        array(
            'key' => 'logo',
            'value' => '893'
        ),
        array(
            'key' => 'logo_2x',
            'value' => '894'
        ),

        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),


        array(
            'key' => 'footer_layout',
            'value' => '5col32223'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),


        array(
            'key' => 'primary_color|header_link_hover_color|mm_lv_1_hover_color|header_top_link_hover_color|transparency_header_link_hover_color|transparency_mm_lv_1_hover_color|transparency_header_top_link_hover_color|offcanvas_link_hover_color|mb_lv_1_hover_color|page_title_bar_link_hover_color',
            'value' => '#54dfb2'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color'     => '#232324',
                'repeat'    => 'no-repeat',
                'position'  => 'top center'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '65px',
                'padding_bottom' => '25px',
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => 'rgba(255,255,255,0.6)'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => 'rgba(255,255,255,0.6)'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'main_google_font_face|secondary_google_font_face',
            'value' => 'Roboto Condensed'
        ),
        /**
         * Filters
         */

        array(
            'filter_name' => 'helas/filter/footer_column_1',
            'value' => 'home-06-footer-column-1'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_2',
            'value' => 'home-06-footer-column-2'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_3',
            'value' => 'home-06-footer-column-3'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_4',
            'value' => 'home-06-footer-column-4'
        ),
        array(
            'filter_name' => 'helas/filter/footer_column_5',
            'value' => 'home-06-footer-column-5'
        ),

        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.site-main-nav .main-menu > li > a {
    text-transform: uppercase;
    font-weight: bold;
}
.footer-top {
    font-size: 10px;
    letter-spacing: 1px;
}
.footer-top .container{
    width: 1470px;
}
.site-footer .widget .widget-title{
    font-size: 14px;
    font-family: inherit;
    letter-spacing: 2px;
    margin-bottom: 35px;
}
.site-footer ul li{
    margin-bottom: 30px;
}
                ';

                return $value;
            },
            'filter_priority'  => 20,
            'filter_args'  => 3
        ),
    );
}