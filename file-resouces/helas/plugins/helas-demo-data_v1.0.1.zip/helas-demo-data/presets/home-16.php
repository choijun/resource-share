<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_home_16()
{
    return array(

        array(
            'key' => 'header_layout',
            'value' => '8'
        ),
        array(
            'key' => 'header_sticky|header_full_width|header_transparency',
            'value' => 'no'
        ),


        array(
            'key' => 'footer_layout',
            'value' => '1col'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color'     => '#fff'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '45px',
                'padding_bottom' => '0px',
            )
        ),

        array(
            'key' => 'footer_text_color',
            'value' => '#8a8a8a'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => '#36393e'
        ),

        array(
            'key' => 'enable_footer_copyright',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row"><div class="col-xs-12"><div class="font-size-10 text-uppercase text-center letter-spacing-5">2018 Created by LaStudio</div></div></div>'
        ),

        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'footer_copyright_text_color',
            'value' => '#8a8a8a'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'helas/filter/footer_column_1',
            'value' => 'home-16-footer-column-1'
        ),

        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '

                ';

                return $value;
            },
            'filter_priority'  => 20,
            'filter_args'  => 3
        ),
    );
}