<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_shop_left_sidebar()
{
    return array(
        /**
         * Settings
         */

        array(
            'filter_name' => 'helas/filter/page_title',
            'value' => '<header><div class="page-title h3">SHOP LEFT SIDEBAR</div></header>'
        )
    );
}