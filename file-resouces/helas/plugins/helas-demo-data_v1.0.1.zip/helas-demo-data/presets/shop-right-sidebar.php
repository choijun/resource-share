<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_helas_preset_shop_right_sidebar()
{
    return array(
        /**
         * Settings
         */

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-2cr'
        ),
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'active_shop_filter',
            'value' => 'off'
        ),
        array(
            'key' => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),

        array(
            'key'   => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 4,
                'lg' => 4,
                'md' => 3,
                'sm' => 2,
                'xs' => 2,
                'mb' => 1
            )
        ),

        array(
            'key' => 'main_space',
            'value' => array(
                'top' => 40,
                'bottom' => 30
            )
        ),
        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => 230,
                'bottom' => 200
            )
        ),

        array(
            'filter_name' => 'helas/filter/page_title',
            'value' => '<header><div class="page-title h3">SUMMER 2018</div></header>'
        ),

        array(
            'filter_name' => 'helas/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.section-page-header{
    background-image: url(//helas.la-studioweb.com/wp-content/uploads/2018/02/shop-right-sidebar-page-title-bg.jpg);
}
.wc-toolbar-top {
    padding-top: 15px;
    margin-bottom: 40px;
}
@media (min-width: 1300px) {
    .site-main > .container{
        padding-left: 35px;
        padding-right: 35px;
    }
}
@media (min-width: 1400px) {
    .site-main > .container{
        padding-left: 45px;
        padding-right: 45px;
    }
}
@media (min-width: 1500px) {
    .site-main > .container{
        padding-left: 80px;
        padding-right: 80px;
    }
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}