<?php
if (!defined('ABSPATH')){ die(); }

if(!class_exists('LaStudio_ContentType_Class')){

    class LaStudio_ContentType_Class{

        protected $options;

        function __construct( $options = array() ) {
            $this->options = shortcode_atts(array(
                'la_block'          => true,
                'la_testimonial'    => true,
                'la_portfolio'      => true,
                'la_team_member'    => false
            ), $options);

            add_action( 'init', array( $this, 'loadContentType' ) );
        }

        public function loadContentType(){
            if($this->options['la_block']){
                $this->loadLaBlock();
            }
            if($this->options['la_testimonial']){
                $this->loadLaTestimonial();
            }
            if($this->options['la_team_member']){
                $this->loadLaTeamMember();
            }
            if($this->options['la_portfolio']){
                $this->loadLaPortfolio();
            }
        }

        protected function loadLaBlock(){
            register_post_type(
                'la_block',
                array(
                    'label'                 => __( 'Custom Block', LA_TEXTDOMAIN ),
                    'labels'                => array(
                        'name'                  => __( 'Custom Blocks', LA_TEXTDOMAIN ),
                        'singular_name'         => __( 'Custom Block', LA_TEXTDOMAIN ),
                        'menu_name'             => __( 'Custom Block', LA_TEXTDOMAIN ),
                        'name_admin_bar'        => __( 'Custom Block', LA_TEXTDOMAIN )
                    ),
                    'supports'              => array( 'title', 'editor'),
                    'menu_icon'             => 'dashicons-slides',
                    'public'                => true,
                    'show_ui'               => true,
                    'show_in_menu'          => true,
                    'menu_position'         => 6,
                    'show_in_admin_bar'     => false,
                    'show_in_nav_menus'     => false,
                    'can_export'            => true,
                    'has_archive'           => false,
                    'exclude_from_search'   => true,
                    'publicly_queryable'    => false,
                    'capability_type'       => 'page',
                )
            );
        }

        protected function loadLaTestimonial(){
            register_post_type(
                'la_testimonial',
                array(
                    'label'                 => __( 'Testimonial', LA_TEXTDOMAIN ),
                    'labels'                => array(
                        'name'                  => __( 'Testimonials', LA_TEXTDOMAIN ),
                        'singular_name'         => __( 'Testimonial', LA_TEXTDOMAIN ),
                        'menu_name'             => __( 'Testimonial', LA_TEXTDOMAIN ),
                        'name_admin_bar'        => __( 'Testimonial', LA_TEXTDOMAIN )
                    ),
                    'supports'              => array('title'),
                    'menu_icon'             => 'dashicons-testimonial',
                    'public'                => true,
                    'show_ui'               => true,
                    'show_in_menu'          => true,
                    'menu_position'         => 7,
                    'show_in_admin_bar'     => false,
                    'show_in_nav_menus'     => false,
                    'can_export'            => true,
                    'has_archive'           => false,
                    'exclude_from_search'   => true,
                    'publicly_queryable'    => false,
                    'capability_type'       => 'page',
                    'rewrite'               => array( 'slug' => 'testimonial' ),
                )
            );
        }

        protected function loadLaTeamMember(){
            register_post_type(
                'la_team_member',
                array(
                    'label'                 => __( 'Team Member', LA_TEXTDOMAIN ),
                    'labels'                => array(
                        'name'                  => __( 'Team Members', LA_TEXTDOMAIN ),
                        'singular_name'         => __( 'Team Member', LA_TEXTDOMAIN ),
                        'menu_name'             => __( 'Team Member', LA_TEXTDOMAIN ),
                        'name_admin_bar'        => __( 'Team Member', LA_TEXTDOMAIN )
                    ),
                    'supports'              => array('title', 'editor', 'thumbnail'),
                    'menu_icon'             => 'dashicons-groups',
                    'public'                => true,
                    'show_ui'               => true,
                    'show_in_menu'          => true,
                    'menu_position'         => 8,
                    'show_in_admin_bar'     => false,
                    'show_in_nav_menus'     => false,
                    'can_export'            => true,
                    'has_archive'           => false,
                    'exclude_from_search'   => true,
                    'publicly_queryable'    => false,
                    'capability_type'       => 'page',
                    'rewrite'               => array( 'slug' => 'team-member' ),
                )
            );
        }

        protected function loadLaPortfolio(){
            register_post_type(
                'la_portfolio',
                array(
                    'label'                 => __( 'Portfolio', LA_TEXTDOMAIN ),
                    'labels'                => array(
                        'name'                  => __( 'Portfolios', LA_TEXTDOMAIN ),
                        'singular_name'         => __( 'Portfolio', LA_TEXTDOMAIN ),
                        'menu_name'             => __( 'Portfolio', LA_TEXTDOMAIN ),
                        'name_admin_bar'        => __( 'Portfolio', LA_TEXTDOMAIN )
                    ),
                    'supports'              => array('title', 'editor', 'thumbnail'),
                    'menu_icon'             => 'dashicons-portfolio',
                    'public'                => true,
                    'menu_position'         => 8,
                    'can_export'            => true,
                    'has_archive'           => true,
                    'exclude_from_search'   => false,
                    'rewrite'               => array( 'slug' => 'portfolio' ),
                )
            );
            register_taxonomy(
                'la_portfolio_category',
                'la_portfolio',
                array(
                    'hierarchical'      => true,
                    'show_in_nav_menus' => true,
                    'labels'            => array(
                        'name'          => __( 'Portfolio Categories', LA_TEXTDOMAIN ),
                        'singular_name' => __( 'Portfolio Category', LA_TEXTDOMAIN )
                    ),
                    'query_var'         => true,
                    'show_admin_column' => true,
                    'rewrite'           => array('slug' => 'portfolio-category')
                )
            );
//            register_taxonomy(
//                'la_portfolio_skill',
//                'la_portfolio',
//                array(
//                    'hierarchical'      => true,
//                    'show_in_nav_menus' => true,
//                    'labels'            => array(
//                        'name'          => __( 'Portfolio Skills', LA_TEXTDOMAIN ),
//                        'singular_name' => __( 'Portfolio Skill', LA_TEXTDOMAIN )
//                    ),
//                    'query_var'         => true,
//                    'show_admin_column' => true,
//                    'rewrite'           => array('slug' => 'portfolio-skill')
//                )
//            );

        }

    }
}