<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// SHORTCODE GENERATOR OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options       = array();

// -----------------------------------------
// Basic Shortcode Examples                -
// -----------------------------------------
$options[]     = array(
    'title'      => 'LA Shortcodes',
    'shortcodes' => array(

        // begin: shortcode
        array(
            'name'      => 'la_dropcap',
            'title'     => 'DropCap',
            'fields'    => array(
                array(
                    'id'    => 'style',
                    'type'  => 'select',
                    'title' => 'Design',
                    'options'        => array(
                        '1'          => 'Style 1'
                    )
                ),
                array(
                    'id'    => 'color',
                    'type'  => 'color_picker',
                    'title' => 'Text Color'
                ),
                array(
                    'id'    => 'content',
                    'type'  => 'textarea',
                    'title' => 'Content',
                )
            )
        ),
        // end: shortcode

    ),
);
CSFramework_Shortcode_Manager::instance( $options );