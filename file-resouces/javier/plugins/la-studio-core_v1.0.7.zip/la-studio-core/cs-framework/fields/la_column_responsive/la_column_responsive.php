<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Number
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class CSFramework_Option_la_column_responsive extends CSFramework_Options {

    public function __construct( $field, $value = '', $unique = '' ) {
        parent::__construct( $field, $value, $unique );
    }

    public function output() {


        echo $this->element_before();

        $option_defaults = array(
            'xlg'   => array('1'=>'1' ,'2'=>'2', '3'=>'3' ,'4'=>'4' ,'5'=>'5' ,'6'=>'6'),
            'lg'    => array('1'=>'1' ,'2'=>'2', '3'=>'3' ,'4'=>'4' ,'5'=>'5' ,'6'=>'6'),
            'md'    => array('1'=>'1' ,'2'=>'2', '3'=>'3' ,'4'=>'4' ,'5'=>'5' ,'6'=>'6'),
            'sm'    => array('1'=>'1' ,'2'=>'2', '3'=>'3' ,'4'=>'4' ,'5'=>'5' ,'6'=>'6'),
            'xs'    => array('1'=>'1' ,'2'=>'2', '3'=>'3' ,'4'=>'4' ,'5'=>'5' ,'6'=>'6')
        );

        $value_defaults = array(
            'xlg'   => '1',
            'lg'    => '1',
            'md'    => '1',
            'sm'    => '1',
            'xs'    => '1'
        );

        $this->options = wp_parse_args( isset($this->field['options']) ? $this->field['options'] : array() , $option_defaults );
        $this->value    = wp_parse_args( $this->element_value(), $value_defaults );

        if($this->options['xlg'] || $this->options['lg'] || $this->options['md'] || $this->options['sm'] || $this->options['xs'] ){
            echo '<fieldset>';

	        if($this->options['xlg']){
		        echo cs_add_element( array(
			        'pseudo'          => true,
			        'id'              => $this->field['id'].'_xlg',
			        'type'            => 'select',
			        'name'            => $this->element_name( '[xlg]' ),
			        'options'         => $this->options['xlg'],
			        'value'           => $this->value['xlg'],
                    'attributes'        => array(
                        'data-customize-setting-link' => $this->element_name( '[xlg]' )
                    ),
			        'before'          => '<span class="la-tooltip">' . __('On Extra Large devices Desktops >= 1440px', 'broly') . '</span><label><i class="fa fa-desktop"></i></label>'
		        ) );
	        }

            if($this->options['lg']){
                echo cs_add_element( array(
                    'pseudo'          => true,
                    'id'              => $this->field['id'].'_lg',
                    'type'            => 'select',
                    'name'            => $this->element_name( '[lg]' ),
                    'options'         => $this->options['lg'],
                    'value'           => $this->value['lg'],
                    'attributes'        => array(
                        'data-customize-setting-link' => $this->element_name( '[lg]' )
                    ),
                    'before'          => '<span class="la-tooltip">' . __('On Large devices Desktops >= 1200px', 'broly') . '</span><label><i class="dashicons dashicons-desktop"></i></label>'
                ) );
            }

            if($this->options['md']){
                echo cs_add_element( array(
                    'pseudo'          => true,
                    'id'              => $this->field['id'].'_md',
                    'type'            => 'select',
                    'name'            => $this->element_name( '[md]' ),
                    'options'         => $this->options['md'],
                    'value'           => $this->value['md'],
                    'attributes'        => array(
                        'data-customize-setting-link' => $this->element_name( '[md]' )
                    ),
                    'before'          => '<span class="la-tooltip">' . __('On Medium devices Desktops  >= 992px', 'broly') . '</span><label><i class="dashicons dashicons-desktop" style="transform: scale(0.8);"></i></label>'
                ) );
            }

            if($this->options['sm']){
                echo cs_add_element( array(
                    'pseudo'          => true,
                    'id'              => $this->field['id'].'_sm',
                    'type'            => 'select',
                    'name'            => $this->element_name( '[sm]' ),
                    'options'         => $this->options['sm'],
                    'value'           => $this->value['sm'],
                    'attributes'        => array(
                        'data-customize-setting-link' => $this->element_name( '[sm]' )
                    ),
                    'before'          => '<span class="la-tooltip">' . __('On Small devices Tablets  >= 768px', 'broly') . '</span><label><i class="dashicons dashicons-tablet"></i></label>'
                ) );
            }

            if($this->options['xs']){
                echo cs_add_element( array(
                    'pseudo'          => true,
                    'id'              => $this->field['id'].'_xs',
                    'type'            => 'select',
                    'name'            => $this->element_name( '[xs]' ),
                    'options'         => $this->options['xs'],
                    'value'           => $this->value['xs'],
                    'attributes'        => array(
                        'data-customize-setting-link' => $this->element_name( '[xs]' )
                    ),
                    'before'          => '<span class="la-tooltip">' . __('On Extra small devices < 768px', 'broly') . '</span><label><i class="dashicons dashicons-smartphone"></i></label>'
                ) );
            }


            echo '</fieldset>';
        }

        echo $this->element_after();

    }

}