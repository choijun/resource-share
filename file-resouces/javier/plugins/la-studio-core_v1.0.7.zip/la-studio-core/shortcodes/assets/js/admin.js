(function($) {
    "use strict";

    /*
     *   Get hidden field values
     *---------------------------------------------------*/
    function get_responsive_values_in_input(t) {
        var mv = t.find('.lastudio-responsive-value').val(),
            counter = 0;
        if (mv != "") {
            var vals = mv.split(";");
            $.each(vals, function(i, vl) {
                if (vl != "") {
                    t.find('.la-responsive-input').each(function() {
                        var that        = $(this),
                            splitval    = vl.split(":");
                        if( that.attr('data-id') == splitval[0] ) {
                            var mval = splitval[1].split( that.attr('data-unit') );
                            that.val(mval[0]);
                            counter++;
                        }
                    })
                }
            });

            if(counter>1) {
                t.find('.simplify').attr('la-toggle', 'expand');
                t.find('.la-responsive-item.optional, .lastudio-unit-section').show();
            }
            else {
                t.find('.simplify').attr('la-toggle', 'collapse');
                t.find('.la-responsive-item.optional, .lastudio-unit-section').hide();
            }
        }
        else {
            var i=0;      // set default - Values
            t.find(".la-responsive-input").each(function() {
                var that = $(this),
                    d    = that.attr('data-default');
                if(d!=''){
                    that.val(d);
                    i++;
                }
            });
            if(i<=1) {    // set default - Collapse
                t.find('.simplify').attr('la-toggle', 'collapse');
                t.find('.la-responsive-item.optional, .lastudio-unit-section').hide();
            }
        }
    }
    /*
     *   Set hidden field values
     *---------------------------------------------------*/
    function set_responsive_values_in_hidden(t) {
        var new_val = '';
        t.find('.la-responsive-input').each(function() {
            var that    =   $(this),
                unit    =   that.attr('data-unit'),
                ival    =   that.val();
            if ($.isNumeric(ival)) {
                new_val += that.attr('data-id') + ':' + ival + unit + ';';
            }
        });
        t.find('.lastudio-responsive-value').val(new_val);
    }
    $(document).ready(function(){

        $(document)
            .on('vc_param.la_columns', '.lastudio-responsive-wrapper',  function(e){
                get_responsive_values_in_input($(this));
                set_responsive_values_in_hidden($(this));
            })
            .on('click', '.simplify', function(e){
                var $this   = $(this).closest('.lastudio-responsive-wrapper'),
                    status  = $(this).attr('la-toggle');
                switch(status) {
                    case 'expand':
                        $this.find('.simplify').attr('la-toggle', 'collapse');
                        $this.find('.la-responsive-item.optional, .lastudio-unit-section').hide();
                        break;
                    case 'collapse':
                        $this.find('.simplify').attr('la-toggle', 'expand');
                        $this.find('.la-responsive-item.optional, .lastudio-unit-section').show();
                        break;
                    default:
                        $this.find('.simplify').attr('la-toggle', 'collapse');
                        $this.find('.la-responsive-item.optional, .lastudio-unit-section').hide();
                        break;
                }
            })
            /* On change - input / select */
            .on('change', '.la-responsive-input', function(e){
                set_responsive_values_in_hidden($(this).closest('.lastudio-responsive-wrapper'));
            });

        $('.lastudio-responsive-wrapper').trigger('vc_param.la_columns');
    })

})(jQuery);



/** Check for plugin updates **/
(function($) {
    'use strict';

    var lasf_ajax_xhr = null;

    $(function(){
        $('.lasf-button-check-plugins-for-updates').on('click', function(e){
            e.preventDefault();
            var $this = $(this);
            if($this.hasClass('loading')){
                return false;
            }
            $this.addClass('loading');
            if(lasf_ajax_xhr){
                lasf_ajax_xhr.abort();
            }
            lasf_ajax_xhr = $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {
                    action: 'lasf_check_plugins_for_updates'
                },
                success: function( content ) {

                    if( $('.msg', $this.closest('.lasf_table')).length ) {
                        $('.msg', $this.closest('.lasf_table')).html(content);
                    }
                    else{
                        $('<div></div>').addClass('msg').html(content).appendTo($this.closest('.lasf_table'));
                    }

                    $this.removeClass('loading');
                    lasf_ajax_xhr = null;
                }
            })

        });
    });

})(jQuery);