(function($) {
    "use strict";
    $(function() {
        $('.lastudio-responsive-wrapper').trigger('vc_param.la_columns');
    });
})(jQuery);