<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'dropdown',
        'heading' => __('Design',LA_TEXTDOMAIN),
        'param_name' => 'style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'default',
            __('Description at bottom',LA_TEXTDOMAIN) => '1',
            __('Description at left center',LA_TEXTDOMAIN) => '2',
            __('Description at right center',LA_TEXTDOMAIN) => '3'
        ),
        'default' => 'default'
    ),
    array(
        'type' => 'attach_image',
        'heading' => __('Upload the banner image', LA_TEXTDOMAIN),
        'param_name' => 'banner_id'
    ),
    array(
        'type' => 'vc_link',
        'heading' => __('Banner Link', LA_TEXTDOMAIN),
        'param_name' => 'banner_link',
        'description' => __('Add link / select existing page to link to this banner', LA_TEXTDOMAIN),
    ),
    array(
        'type' => 'textarea_html',
        'heading' => __('Heading (Optional)', LA_TEXTDOMAIN),
        'param_name' => 'content'
    ),
    LaStudio_Shortcodes_Helper::fieldCssAnimation(),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Banner Box', LA_TEXTDOMAIN),
        'base'			=> 'la_banner',
        'icon'          => 'la-wpb-icon la_banner',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description'   => __('Displays the banner image with Information', LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_banner'
);