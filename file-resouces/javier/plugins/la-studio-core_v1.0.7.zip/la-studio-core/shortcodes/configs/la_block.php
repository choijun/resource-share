<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'autocomplete',
        'heading' => __( 'Select identificator', LA_TEXTDOMAIN ),
        'param_name' => 'id',
        'description' => __( 'Input block ID or block title to see suggestions', LA_TEXTDOMAIN ),
    ),
    array(
        'type' => 'hidden',
        'param_name' => 'name',
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass(),
);


return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('La Custom Block', LA_TEXTDOMAIN),
        'base'			=> 'la_block',
        'icon'          => 'la-wpb-icon la_block',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description'   => __('Displays the custom block', LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_block'
);