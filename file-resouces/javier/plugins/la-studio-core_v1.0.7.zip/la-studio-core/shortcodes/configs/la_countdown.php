<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }


$shortcode_params = array(
	array(
		"type" => "dropdown",
		"heading" => __("Design", LA_TEXTDOMAIN),
		"param_name" => "count_style",
		"value" => array(
			__("Style 01",LA_TEXTDOMAIN) => "1",
			__("Style 02",LA_TEXTDOMAIN) => "2",
		)
	),
	array(
		"type" => "datetimepicker",
		"heading" => __("Target Time For Countdown", LA_TEXTDOMAIN),
		"param_name" => "datetime",
		"description" => __("Date and time format (yyyy/mm/dd hh:mm:ss).", LA_TEXTDOMAIN),
	),
	array(
		"type" => "dropdown",
		"heading" => __("Countdown Timer Depends on", LA_TEXTDOMAIN),
		"param_name" => "time_zone",
		"value" => array(
			__("WordPress Defined Timezone",LA_TEXTDOMAIN) => "wptz",
			__("User's System Timezone",LA_TEXTDOMAIN) => "usrtz",
		),
	),
	array(
		"type" => "checkbox",
		"heading" => __("Select Time Units To Display In Countdown Timer", LA_TEXTDOMAIN),
		"param_name" => "countdown_opts",
		"value" => array(
			__("Years",LA_TEXTDOMAIN) => "syear",
			__("Months",LA_TEXTDOMAIN) => "smonth",
			__("Weeks",LA_TEXTDOMAIN) => "sweek",
			__("Days",LA_TEXTDOMAIN) => "sday",
			__("Hours",LA_TEXTDOMAIN) => "shr",
			__("Minutes",LA_TEXTDOMAIN) => "smin",
			__("Seconds",LA_TEXTDOMAIN) => "ssec",
		),
	),
	LaStudio_Shortcodes_Helper::fieldCssAnimation(),
	LaStudio_Shortcodes_Helper::fieldExtraClass(),

	array(
		"type" => "textfield",
		"heading" => __("Day (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_days",
		"value" => "Day",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Days (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_days2",
		"value" => "Days",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Week (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_weeks",
		"value" => "Week",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Weeks (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_weeks2",
		"value" => "Weeks",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Month (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_months",
		"value" => "Month",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Months (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_months2",
		"value" => "Months",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Year (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_years",
		"value" => "Year",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Years (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_years2",
		"value" => "Years",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Hour (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_hours",
		"value" => "Hrs",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Hours (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_hours2",
		"value" => "Hrs",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Minute (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_minutes",
		"value" => "Mins",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Minutes (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_minutes2",
		"value" => "Mins",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Second (Singular)", LA_TEXTDOMAIN),
		"param_name" => "string_seconds",
		"value" => "Secs",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
	array(
		"type" => "textfield",
		"heading" => __("Seconds (Plural)", LA_TEXTDOMAIN),
		"param_name" => "string_seconds2",
		"value" => "Secs",
		'group' => __( 'Strings Translation', LA_TEXTDOMAIN ),
	),
);

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Count Down', LA_TEXTDOMAIN),
		'base'			=> 'la_countdown',
		'icon'          => 'la-wpb-icon la_countdown',
		'category'  	=> __('La Studio', LA_TEXTDOMAIN),
		'description' 	=> __('Countdown Timer',LA_TEXTDOMAIN),
		'params' 		=> $shortcode_params
	),
    'la_countdown'
);