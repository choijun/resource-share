<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' 			=> 'la_column',
        'heading' 		=> __('Divider Height', LA_TEXTDOMAIN),
        'admin_label'   => true,
        'param_name' 	=> 'height',
        'unit'			=> 'px',
        'media'			=> array(
            'xlg'	=> '',
            'lg'	=> '',
            'md'	=> '',
            'sm'	=> '',
            'xs'	=> ''
        )
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Divider', LA_TEXTDOMAIN),
        'base'			=> 'la_divider',
        'icon'          => 'la-wpb-icon la_divider',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Divider.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_divider'
);