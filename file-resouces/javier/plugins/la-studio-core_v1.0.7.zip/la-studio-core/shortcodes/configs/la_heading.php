<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'textfield',
        'heading' => __('Heading', LA_TEXTDOMAIN),
        'param_name' => 'title',
        'admin_label' => true,
    ),
    array(
        'type' => 'textarea_html',
        'heading' => __('Sub Heading(Optional)', LA_TEXTDOMAIN),
        'param_name' => 'content'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Heading tag',LA_TEXTDOMAIN),
        'param_name' => 'tag',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'h2',
            __('H1',LA_TEXTDOMAIN) => 'h1',
            __('H3',LA_TEXTDOMAIN) => 'h3',
            __('H4',LA_TEXTDOMAIN) => 'h4',
            __('H5',LA_TEXTDOMAIN) => 'h5',
            __('H6',LA_TEXTDOMAIN) => 'h6',
            __('DIV',LA_TEXTDOMAIN) => 'div',
            __('p',LA_TEXTDOMAIN) => 'p',
        ),
        'default' => 'h2',
        'description' => __('Default is H2', LA_TEXTDOMAIN),
    ),
    array(
        'type'  => 'dropdown',
        'heading' => __('Alignment',LA_TEXTDOMAIN),
        'param_name'    => 'alignment',
        'value' => array(
            __('Center',LA_TEXTDOMAIN)	    =>	'center',
            __('Left',LA_TEXTDOMAIN)	    =>	'left',
            __('Right',LA_TEXTDOMAIN)	    =>	'right'
        ),
        'default' => 'left',
    ),
    array(
        'type'  => 'dropdown',
        'heading' => __('Separator',LA_TEXTDOMAIN),
        'param_name'    => 'spacer',
        'value' => array(
            __('No Separator',LA_TEXTDOMAIN)	=>	'none',
            __('Line',LA_TEXTDOMAIN)	        =>	'line',
        ),
        'default' => 'none',
    ),
    array(
        'type'  => 'dropdown',
        'heading' => __('Separator Position',LA_TEXTDOMAIN),
        'param_name'    => 'spacer_position',
        'value' => array(
            __('Top',LA_TEXTDOMAIN)	                        =>	'top',
            __('Between Heading & Subheading',LA_TEXTDOMAIN)  =>	'middle',
            __('Bottom',LA_TEXTDOMAIN)	                    =>	'bottom',
            __('Title between separator',LA_TEXTDOMAIN)	    =>	'separator',
        ),
        'default' => 'top',
        'dependency' => array(
            'element'   => 'spacer',
            'value'     => 'line'
        )
    ),
    array(
        'type'      => 'dropdown',
        'heading'   => __('Line Style', LA_TEXTDOMAIN),
        'param_name'    => 'line_style',
        'value'         => array(
            __('Solid', LA_TEXTDOMAIN) => 'solid',
            __('Dashed', LA_TEXTDOMAIN) => 'dashed',
            __('Dotted', LA_TEXTDOMAIN) => 'dotted',
            __('Double', LA_TEXTDOMAIN) => 'double'
        ),
        'default' => 'solid',
        'dependency' => array(
            'element'   => 'spacer',
            'value'     => 'line'
        )
    ),
    array(
        'type' 			=> 'la_column',
        'heading' 		=> __('Line Width', LA_TEXTDOMAIN),
        'param_name' 	=> 'line_width',
        'unit'			=> 'px',
        'media'			=> array(
            'xlg'	=> '',
            'lg'	=> '',
            'md'	=> '',
            'sm'	=> '',
            'xs'	=> ''
        ),
        'dependency' => array(
            'element'   => 'spacer',
            'value'     => 'line'
        )
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Line Height', LA_TEXTDOMAIN),
        'param_name' => 'line_height',
        'value' => 1,
        'min' => 1,
        'suffix' => 'px',
        'dependency' => array(
            'element'   => 'spacer',
            'value'     => 'line'
        )
    ),
    array(
        'type' => 'colorpicker',
        'heading' => __('Line Color', LA_TEXTDOMAIN),
        'param_name' => 'line_color',
        'dependency' => array(
            'element'   => 'spacer',
            'value'     => 'line'
        )
    ),
    LaStudio_Shortcodes_Helper::fieldCssAnimation(),
    LaStudio_Shortcodes_Helper::fieldExtraClass(),
    LaStudio_Shortcodes_Helper::fieldExtraClass(array(
        'heading' 		=> __('Extra Class for heading', LA_TEXTDOMAIN),
        'param_name' 	=> 'title_class',
    )),
    LaStudio_Shortcodes_Helper::fieldExtraClass(array(
        'heading' 		=> __('Extra Class for subheading', LA_TEXTDOMAIN),
        'param_name' 	=> 'subtitle_class',
    ))
);

$title_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont();
$desc_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('subtitle', __('Subheading', LA_TEXTDOMAIN));

$shortcode_params = array_merge( $shortcode_params, $title_google_font_param, $desc_google_font_param, array(LaStudio_Shortcodes_Helper::fieldCssClass()));

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Headings', LA_TEXTDOMAIN),
        'base'			=> 'la_heading',
        'icon'          => 'la-wpb-icon la_heading',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Awesome heading styles.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_heading'
);