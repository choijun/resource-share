<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$icon_type = LaStudio_Shortcodes_Helper::fieldIconType();

$shortcode_params = array(
	array(
		'type' => 'textfield',
		'heading' => __('Heading', LA_TEXTDOMAIN),
		'param_name' => 'title',
		'admin_label' => true,
		'description' => __('Provide the title for this icon boxes.', LA_TEXTDOMAIN),
	),
	array(
		'type' => 'textarea_html',
		'heading' => __('Description', LA_TEXTDOMAIN),
		'param_name' => 'content',
		'description' => __('Provide the description for this icon box.', LA_TEXTDOMAIN),
	),
	array(
		'type'	=> 'dropdown',
		'heading'	=> __('Icon Position', LA_TEXTDOMAIN),
		'param_name' => 'icon_pos',
		'value'	=> array(
			__('Icon at left with heading', LA_TEXTDOMAIN) => 'default',
			__('Icon at Right with heading', LA_TEXTDOMAIN) => 'heading-right',
			__('Icon at Left', LA_TEXTDOMAIN) => 'left',
			__('Icon at Right', LA_TEXTDOMAIN) => 'right',
			__('Icon at Top', LA_TEXTDOMAIN) => 'top',
		),
		'std' => 'default',
		'description' => __('Select icon position. Icon box style will be changed according to the icon position.', LA_TEXTDOMAIN),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),

	array(
		'type' => 'dropdown',
		'heading' => __('Icon Styles', LA_TEXTDOMAIN),
		'param_name' => 'icon_style',
		'description' => __('We have given four quick preset if you are in a hurry. Otherwise, create your own with various options.', LA_TEXTDOMAIN),
		'std'	=> 'simple',
		'value' => array(
			__('Simple', LA_TEXTDOMAIN) => 'simple',
			__('Circle Background', LA_TEXTDOMAIN) => 'circle',
			__('Square Background', LA_TEXTDOMAIN) => 'square',
			__('Round Background', LA_TEXTDOMAIN) => 'round',
			__('Advanced', LA_TEXTDOMAIN) => 'advanced',
		),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),

	array(
		'type' => 'la_number',
		'heading' => __('Icon Size', LA_TEXTDOMAIN),
		'param_name' => 'icon_size',
		'value' => 30,
		'min' => 10,
		'suffix' => 'px',
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	array(
		'type' => 'la_number',
		'heading' => __('Icon Box Width', LA_TEXTDOMAIN),
		'param_name' => 'icon_width',
		'value' => 30,
		'min' => 10,
		'suffix' => 'px',
		'group' => __('Icon Settings', LA_TEXTDOMAIN),
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('circle','square','round','advanced')
		),
	),
	array(
		'type' => 'colorpicker',
		'heading' => __('Icon Color', LA_TEXTDOMAIN),
		'param_name' => 'icon_color',
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	array(
		'type' => 'colorpicker',
		'heading' => __('Icon Background Color', LA_TEXTDOMAIN),
		'param_name' => 'icon_bg',
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('circle','square','round','advanced')
		),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	array(
		'type' => 'dropdown',
		'heading' => __('Icon Border Style', LA_TEXTDOMAIN),
		'param_name' => 'icon_border_style',
		'value' => array(
			__('None', LA_TEXTDOMAIN) => '',
			__('Solid', LA_TEXTDOMAIN) => 'solid',
			__('Dashed', LA_TEXTDOMAIN) => 'dashed',
			__('Dotted', LA_TEXTDOMAIN) => 'dotted',
			__('Double', LA_TEXTDOMAIN) => 'double',
		),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	array(
		'type' => 'la_number',
		'heading' => __('Icon Border Width', LA_TEXTDOMAIN),
		'param_name' => 'icon_border_width',
		'value' => 1,
		'min' => 1,
		'max' => 10,
		'suffix' => 'px',
		'dependency' => array(
			'element' 	=> 'icon_border_style',
			'not_empty' 	=> true
		),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	array(
		'type' => 'colorpicker',
		'heading' => __('Icon Border Color', LA_TEXTDOMAIN),
		'param_name' => 'icon_border_color',
		'dependency' => array(
			'element' 	=> 'icon_border_style',
			'not_empty' 	=> true
		),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	array(
		'type' => 'la_number',
		'heading' => __('Icon Border Radius', LA_TEXTDOMAIN),
		'param_name' => 'icon_border_radius',
		'value' => 500,
		'min' => 1,
		'suffix' => 'px',
		'description' => __('0 pixel value will create a square border. As you increase the value, the shape convert in circle slowly. (e.g 500 pixels).', LA_TEXTDOMAIN),
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('advanced')
		),
		'group' => __('Icon Settings', LA_TEXTDOMAIN)
	),
	LaStudio_Shortcodes_Helper::fieldCssAnimation(),
	LaStudio_Shortcodes_Helper::fieldExtraClass(),
	LaStudio_Shortcodes_Helper::fieldExtraClass(array(
		'heading' 		=> __('Extra Class for heading', LA_TEXTDOMAIN),
		'param_name' 	=> 'title_class',
	)),
	LaStudio_Shortcodes_Helper::fieldExtraClass(array(
		'heading' 		=> __('Extra Class for description', LA_TEXTDOMAIN),
		'param_name' 	=> 'desc_class',
	))
);

$title_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont();
$desc_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('desc', __('Description', LA_TEXTDOMAIN));

$shortcode_params = array_merge( $icon_type, $shortcode_params, $title_google_font_param, $desc_google_font_param, array(LaStudio_Shortcodes_Helper::fieldCssClass()) );

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Icon boxes', LA_TEXTDOMAIN),
		'base'			=> 'la_icon_boxes',
		'icon'          => 'la-wpb-icon la_icon_boxes',
		'category'  	=> __('La Studio', LA_TEXTDOMAIN),
		'description' 	=> __('Adds icon box with custom font icon',LA_TEXTDOMAIN),
		'params' 		=> $shortcode_params
	),
    'la_icon_boxes'
);