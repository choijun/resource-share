<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Select Portfolio', LA_TEXTDOMAIN ),
        'param_name' => 'id',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => false,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 0,
            'auto_focus'     => true,
            'display_inline' => true,
        )
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);


return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Portfolio Metadata', LA_TEXTDOMAIN),
        'base'			=> 'la_portfolio_meta',
        'icon'          => 'la-wpb-icon la_portfolio_meta',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display portfolio metadata la-studio themes style.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_portfolio_meta'
);