<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
	array(
		'type' => 'textfield',
		'heading' => __( 'Package Name / Title', LA_TEXTDOMAIN ),
		'param_name' => 'package_title',
		'description' => __( 'Enter the package name or table heading', LA_TEXTDOMAIN )
	),
	array(
		'type' => 'textfield',
		'heading' => __( 'Package Price', LA_TEXTDOMAIN ),
		'param_name' => 'package_price',
		'description' => __( 'Enter the price for this package. e.g. $157', LA_TEXTDOMAIN )
	),
	array(
		'type' => 'textfield',
		'heading' => __( 'Price Unit', LA_TEXTDOMAIN ),
		'param_name' => 'price_unit',
		'description' => __( 'Enter the price unit for this package. e.g. per month', LA_TEXTDOMAIN )
	),
	array(
		'type' => 'param_group',
		'heading' => __( 'Features', LA_TEXTDOMAIN ),
		'param_name' => 'features',
		'description' => __( 'Create the features list', LA_TEXTDOMAIN ),
		'value' => urlencode( json_encode( array(
			array(
				'highlight' => 'Sample',
				'text' => 'Text'
			),
			array(
				'highlight' => 'Sample',
				'text' => 'Text',
			),
			array(
				'highlight' => 'Sample',
				'text' => 'Text',
			),
		) ) ),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => __( 'Highlight Text', LA_TEXTDOMAIN ),
				'param_name' => 'highlight',
				'admin_label' => true,
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Text', LA_TEXTDOMAIN ),
				'param_name' => 'text',
				'admin_label' => true,
			),
			array(
				'type' => 'iconpicker',
				'param_name' => 'icon',
				'settings' => array(
					'emptyIcon' => true,
					'iconsPerPage' => 50,
				),
			),
		),
	),
	array(
		'type' => 'textarea',
		'heading' => __( 'Description before featured', LA_TEXTDOMAIN ),
		'param_name' => 'desc_before',
	),
	array(
		'type' => 'textarea',
		'heading' => __( 'Description after featured', LA_TEXTDOMAIN ),
		'param_name' => 'desc_after',
	),
	array(
		'type' => 'textfield',
		'heading' => __( 'Button text', LA_TEXTDOMAIN ),
		'param_name' => 'button_text',
		'description' => __( 'Enter call to action button text', LA_TEXTDOMAIN ),
		'value' => 'View More'
	),
	array(
		'type'       => 'vc_link',
		'heading'    => __( 'Button Link', LA_TEXTDOMAIN ),
		'param_name' => 'button_link',
		'description' => __('Select / enter the link for call to action button', LA_TEXTDOMAIN)
	),
	array(
		'type'       => 'checkbox',
		'param_name' => 'package_featured',
		'value'      => array( __( 'Make this pricing box as featured', LA_TEXTDOMAIN ) => 'yes' ),
	),
	array(
		'type' => 'textfield',
		'heading' => __( 'Custom badge', LA_TEXTDOMAIN ),
		'param_name' => 'custom_badge',
		'value'		=> 'Recommended',
		'dependency' => array(
			'element' => 'package_featured',
			'value' => 'yes'
		)
	),
	LaStudio_Shortcodes_Helper::fieldCssAnimation(),
	LaStudio_Shortcodes_Helper::fieldExtraClass(),
	
	array(
		'type' => 'colorpicker',
		'param_name' => 'main_bg_color',
		'heading' => __('Main background color', LA_TEXTDOMAIN),
		'group' => 'Design',
	),
	array(
		'type' => 'colorpicker',
		'param_name' => 'main_text_color',
		'heading' => __('Main text color', LA_TEXTDOMAIN),
		'group' => 'Design',
	),
	array(
		'type' => 'colorpicker',
		'param_name' => 'highlight_color',
		'heading' => __('Highlight color', LA_TEXTDOMAIN),
		'group' => 'Design',
	),
);

$icon_type = LaStudio_Shortcodes_Helper::fieldIconType(array(), true);

$title_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('package_title', __('Package Name/Title', LA_TEXTDOMAIN));
$price_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('package_price', __('Price', LA_TEXTDOMAIN));
$price_unit_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('package_price_unit', __('Price Unit', LA_TEXTDOMAIN));
$desc_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('package_desc', __('After Featured/ Before Featured', LA_TEXTDOMAIN));
$featured_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('package_featured', __('Featured', LA_TEXTDOMAIN));
$button_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('package_button', __('Button', LA_TEXTDOMAIN));
$icon_google_font_param = array(
	array(
		'type' 			=> 'la_heading',
		'param_name' 	=> 'icon__typography',
		'text' 			=> __('Icon settings', LA_TEXTDOMAIN),
		'group' 		=> __('Typography', LA_TEXTDOMAIN)
	),
	array(
		'type' 			=> 'la_column',
		'heading' 		=> __('Icon Width', LA_TEXTDOMAIN),
		'param_name' 	=> 'icon_lh',
		'unit' 			=> 'px',
		'media' => array(
			'xlg'	=> '',
			'lg'    => '',
			'md'    => '',
			'sm'    => '',
			'xs'	=> ''
		),
		'group' 		=> __('Typography', LA_TEXTDOMAIN)
	),
	array(
		'type' 			=> 'la_column',
		'heading' 		=> __('Font size', LA_TEXTDOMAIN),
		'param_name' 	=> 'icon_fz',
		'unit' 			=> 'px',
		'media' => array(
			'xlg'	=> '',
			'lg'    => '',
			'md'    => '',
			'sm'    => '',
			'xs'	=> ''
		),
		'group' 		=> __('Typography', LA_TEXTDOMAIN)
	),
	array(
		'type' 			=> 'colorpicker',
		'param_name' 	=> 'icon_color',
		'heading' 		=> __('Color', LA_TEXTDOMAIN),
		'group' 		=> __('Typography', LA_TEXTDOMAIN)
	)
);


$shortcode_params = array_merge(
	array(
		array(
			'type' => 'dropdown',
			'heading' => __('Select Design',LA_TEXTDOMAIN),
			'description' => __('Select Pricing table design you would like to use',LA_TEXTDOMAIN),
			'param_name' => 'style',
			'value' => array(
				__("Design 01",LA_TEXTDOMAIN) => "1",
				__("Design 02",LA_TEXTDOMAIN) => "2"
			),
		)
	),
	$icon_type,
	$shortcode_params,
	$icon_google_font_param,
	$title_google_font_param,
	$price_google_font_param,
	$price_unit_google_font_param,
	$desc_google_font_param,
	$featured_google_font_param,
	$button_google_font_param
);

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Pricing Table', LA_TEXTDOMAIN),
		'base'			=> 'la_pricing_table',
		'icon'          => 'la-wpb-icon la_pricing_table',
		'category'  	=> __('La Studio', LA_TEXTDOMAIN),
		'description' 	=> __('Create nice looking pricing tables',LA_TEXTDOMAIN),
		'params' 		=> $shortcode_params
	),
    'la_pricing_table'
);