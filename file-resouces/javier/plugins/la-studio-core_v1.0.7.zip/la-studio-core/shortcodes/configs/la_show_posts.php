<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }
$carousel = LaStudio_Shortcodes_Helper::fieldCarousel(array(
    'element' => 'enable_carousel',
    'not_empty' => true
));
$shortcode_params = array(
    array(
        'type' => 'dropdown',
        'heading' => __('Layout',LA_TEXTDOMAIN),
        'param_name' => 'layout',
        'value' => array(
            __('List',LA_TEXTDOMAIN) => 'list',
            __('Grid',LA_TEXTDOMAIN) => 'grid',
            __('Masonry',LA_TEXTDOMAIN) => 'masonry',
        ),
        'default' => 'grid'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'list_style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => '1',
            __('Mini',LA_TEXTDOMAIN) => '5',
            __('No Thumbs',LA_TEXTDOMAIN) => '4',
            __('Style 02',LA_TEXTDOMAIN) => '2',
            __('Style 03',LA_TEXTDOMAIN) => '3'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'list'
        ),
        'default' => '1'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'grid_style',
        'value' => array(
            __('Style 01',LA_TEXTDOMAIN) => '1',
            __('Style 02',LA_TEXTDOMAIN) => '2',
            __('No Thumbnail 01',LA_TEXTDOMAIN) => 'no_thumb_1'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'grid'
        ),
        'default' => '1'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'masonry_style',
        'value' => array(
            __('Style 01',LA_TEXTDOMAIN) => '1',
            __('Style 02',LA_TEXTDOMAIN) => '2'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'masonry'
        ),
        'default' => '1'
    ),
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Category In:', LA_TEXTDOMAIN ),
        'param_name' => 'category__in',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => true,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 0,
            'auto_focus'     => true,
            'display_inline' => true,
        ),
        'group' => __('Query Settings', LA_TEXTDOMAIN)
    ),
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Category Not In:', LA_TEXTDOMAIN ),
        'param_name' => 'category__not_in',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => true,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 0,
            'auto_focus'     => true,
            'display_inline' => true,
        ),
        'group' => __('Query Settings', LA_TEXTDOMAIN)
    ),
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Post In:', LA_TEXTDOMAIN ),
        'param_name' => 'post__in',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => true,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 0,
            'auto_focus'     => true,
            'display_inline' => true,
        ),
        'group' => __('Query Settings', LA_TEXTDOMAIN)
    ),
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Post Not In:', LA_TEXTDOMAIN ),
        'param_name' => 'post__not_in',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => true,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 0,
            'auto_focus'     => true,
            'display_inline' => true,
        ),
        'group' => __('Query Settings', LA_TEXTDOMAIN)
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Order by', LA_TEXTDOMAIN ),
        'param_name' => 'orderby',
        'value' => array(
            '',
            __( 'Date', LA_TEXTDOMAIN ) => 'date',
            __( 'ID', LA_TEXTDOMAIN ) => 'ID',
            __( 'Author', LA_TEXTDOMAIN ) => 'author',
            __( 'Title', LA_TEXTDOMAIN ) => 'title',
            __( 'Modified', LA_TEXTDOMAIN ) => 'modified',
            __( 'Random', LA_TEXTDOMAIN ) => 'rand',
            __( 'Comment count', LA_TEXTDOMAIN ) => 'comment_count',
            __( 'Menu order', LA_TEXTDOMAIN ) => 'menu_order',
        ),
        'save_always' => true,
        'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', LA_TEXTDOMAIN ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
        'group' => __('Query Settings', LA_TEXTDOMAIN)
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Sort order', LA_TEXTDOMAIN ),
        'param_name' => 'order',
        'value' => array(
            '',
            __( 'Descending', LA_TEXTDOMAIN ) => 'DESC',
            __( 'Ascending', LA_TEXTDOMAIN ) => 'ASC',
        ),
        'save_always' => true,
        'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', LA_TEXTDOMAIN ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
        'group' => __('Query Settings', LA_TEXTDOMAIN)
    ),

    array(
        'type' => 'dropdown',
        'heading' => __('Item title tag',LA_TEXTDOMAIN),
        'param_name' => 'title_tag',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'h3',
            __('H1',LA_TEXTDOMAIN) => 'h1',
            __('H2',LA_TEXTDOMAIN) => 'h2',
            __('H4',LA_TEXTDOMAIN) => 'h4',
            __('H5',LA_TEXTDOMAIN) => 'h5',
            __('H6',LA_TEXTDOMAIN) => 'h6',
            __('DIV',LA_TEXTDOMAIN) => 'div',
        ),
        'default' => 'h3',
        'description' => __('Default is H3', LA_TEXTDOMAIN),
        'group' => __('Item Settings', LA_TEXTDOMAIN)
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Excerpt Length( Optional )', LA_TEXTDOMAIN),
        'param_name' => 'excerpt_length',
        'value' => 20,
        'min' => 1,
        'max' => 100,
        'suffix' => '',
        'group' => __('Item Settings', LA_TEXTDOMAIN)
    ),
    LaStudio_Shortcodes_Helper::fieldImageSize(array(
        'group' => __('Item Settings', LA_TEXTDOMAIN)
    )),
    LaStudio_Shortcodes_Helper::fieldColumn(array(
        'dependency' => array(
            'element'   => 'layout',
            'value'     => array('grid','masonry')
        ),
    )),
    array(
        'type'       => 'checkbox',
        'heading'    => __('Enable slider', LA_TEXTDOMAIN ),
        'param_name' => 'enable_carousel',
        'value'      => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'grid'
        )
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Display Style',LA_TEXTDOMAIN),
        'description' => __('Select display style for grid.', LA_TEXTDOMAIN),
        'param_name' => 'style',
        'value' => array(
            __('Show all',LA_TEXTDOMAIN) => 'all',
            __('Load more button',LA_TEXTDOMAIN) => 'load-more',
            __('Pagination',LA_TEXTDOMAIN) => 'pagination',
        ),
        'default' => 'all'
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Total items', LA_TEXTDOMAIN),
        'description' => __('Set max limit for items in grid or enter -1 to display all (limited to 1000).', LA_TEXTDOMAIN),
        'param_name' => 'per_page',
        'value' => 4,
        'min' => -1,
        'max' => 1000
    ),
    array(
        'type' => 'hidden',
        'heading' => __('Paged', LA_TEXTDOMAIN),
        'param_name' => 'paged',
        'value' => '1'
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Number items showing', LA_TEXTDOMAIN),
        'param_name' => 'items_per_page',
        'description' => __('Number of items to show per page.', LA_TEXTDOMAIN),
        'value' => 4,
        'min' => 1,
        'max' => 1000,
        'dependency' => array(
            'element'   => 'style',
            'value'     => array('load-more','pagination')
        )
    ),
    array(
        'type' => 'textfield',
        'heading' => __('Load more text', LA_TEXTDOMAIN),
        'param_name' => 'load_more_text',
        'value' => 'Read more',
        'dependency' => array(
            'element'   => 'style',
            'value'     => 'load-more'
        )
    ),

    LaStudio_Shortcodes_Helper::fieldExtraClass()
);


$shortcode_params = array_merge( $shortcode_params, $carousel);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Show Posts', LA_TEXTDOMAIN),
        'base'			=> 'la_show_posts',
        'icon'          => 'icon-wpb-application-icon-large',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display posts with la-studio themes style.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_show_posts'
);