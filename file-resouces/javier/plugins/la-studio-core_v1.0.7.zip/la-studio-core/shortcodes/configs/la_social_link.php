<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'default',
            __('Circle',LA_TEXTDOMAIN) => 'circle',
            __('Square',LA_TEXTDOMAIN) => 'square',
            __('Round',LA_TEXTDOMAIN) => 'round',
        ),
        'default' => 'default'
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass(),
);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Social Media Link', LA_TEXTDOMAIN),
        'base'			=> 'la_social_link',
        'icon'          => 'la-wpb-icon la_social_link',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display Social Media Link.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_social_link'
);