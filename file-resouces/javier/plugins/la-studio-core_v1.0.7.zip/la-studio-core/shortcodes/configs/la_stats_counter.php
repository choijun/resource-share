<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$icon_type = LaStudio_Shortcodes_Helper::fieldIconType(array(
	'element' => 'icon_pos',
	'value'	=> array('top','left','right')
));

$field_icon_settings = array(
	array(
		'type'	=> 'dropdown',
		'heading'	=> __('Icon Position', LA_TEXTDOMAIN),
		'param_name' => 'icon_pos',
		'value'	=> array(
			__('No display', LA_TEXTDOMAIN)	=> 'none',
			__('Icon at Top', LA_TEXTDOMAIN) => 'top',
			__('Icon at Left', LA_TEXTDOMAIN) => 'left',
			__('Icon at Right', LA_TEXTDOMAIN) => 'right'

		),
		'std' => 'top',
		'description' => __('Select icon position. Icon box style will be changed according to the icon position.', LA_TEXTDOMAIN)
	),

	array(
		'type' => 'la_number',
		'heading' => __('Icon Size', LA_TEXTDOMAIN),
		'param_name' => 'icon_size',
		'value' => 30,
		'min' => 10,
		'suffix' => 'px',
		'dependency' => array(
			'element' => 'icon_pos',
			'value'	=> array('top','left','right')
		)
	),
	array(
		'type' => 'colorpicker',
		'heading' => __('Icon Color', LA_TEXTDOMAIN),
		'param_name' => 'icon_color',
		'dependency' => array(
			'element' => 'icon_pos',
			'value'	=> array('top','left','right')
		)
	)
);

$field_icon_settings = array_merge($field_icon_settings, $icon_type);

$shortcode_params = array(
	array(
		'type' => 'textfield',
		'heading' => __('Title', LA_TEXTDOMAIN),
		'param_name' => 'title',
		'admin_label' => true,
	),
	array(
		'type' => 'la_number',
		'heading' => __('Value', LA_TEXTDOMAIN),
		'param_name' => 'value',
		'value' => 1250,
		'min' => 0,
		'suffix' => '',
		'description' => __('Enter number for counter without any special character. You may enter a decimal number. Eg 12.76', LA_TEXTDOMAIN)
	),
	array(
		'type'  => 'dropdown',
		'heading' => __('Separator',LA_TEXTDOMAIN),
		'param_name'    => 'spacer',
		'value' => array(
			__('No Separator',LA_TEXTDOMAIN)	=>	'none',
			__('Line',LA_TEXTDOMAIN)	        =>	'line',
		),
		'default' => 'none',
	),
	array(
		'type'  => 'dropdown',
		'heading' => __('Separator Position',LA_TEXTDOMAIN),
		'param_name'    => 'spacer_position',
		'value' => array(
			__('Top',LA_TEXTDOMAIN)	                        =>	'top',
			__('Bottom',LA_TEXTDOMAIN)	                    =>	'bottom'
		),
		'default' => 'top',
		'dependency' => array(
			'element'   => 'spacer',
			'value'     => 'line'
		)
	),
	array(
		'type'      => 'dropdown',
		'heading'   => __('Line Style', LA_TEXTDOMAIN),
		'param_name'    => 'line_style',
		'value'         => array(
			__('Solid', LA_TEXTDOMAIN) => 'solid',
			__('Dashed', LA_TEXTDOMAIN) => 'dashed',
			__('Dotted', LA_TEXTDOMAIN) => 'dotted',
			__('Double', LA_TEXTDOMAIN) => 'double'
		),
		'default' => 'solid',
		'dependency' => array(
			'element'   => 'spacer',
			'value'     => 'line'
		)
	),
	array(
		'type' 			=> 'la_column',
		'heading' 		=> __('Line Width', LA_TEXTDOMAIN),
		'param_name' 	=> 'line_width',
		'unit'			=> 'px',
		'media'			=> array(
			'xlg'	=> '',
			'lg'	=> '',
			'md'	=> '',
			'sm'	=> '',
			'xs'	=> ''
		),
		'dependency' => array(
			'element'   => 'spacer',
			'value'     => 'line'
		)
	),
	array(
		'type' => 'la_number',
		'heading' => __('Line Height', LA_TEXTDOMAIN),
		'param_name' => 'line_height',
		'value' => 1,
		'min' => 1,
		'suffix' => 'px',
		'dependency' => array(
			'element'   => 'spacer',
			'value'     => 'line'
		)
	),
	array(
		'type' => 'colorpicker',
		'heading' => __('Line Color', LA_TEXTDOMAIN),
		'param_name' => 'line_color',
		'dependency' => array(
			'element'   => 'spacer',
			'value'     => 'line'
		)
	),
	LaStudio_Shortcodes_Helper::fieldCssAnimation(),
	LaStudio_Shortcodes_Helper::fieldExtraClass()
);

$title_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont();
$value_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('value', __('Value', LA_TEXTDOMAIN));
$shortcode_params = array_merge( $field_icon_settings, $shortcode_params, $title_google_font_param, $value_google_font_param, array(LaStudio_Shortcodes_Helper::fieldCssClass()) );

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Stats Counter', LA_TEXTDOMAIN),
		'base'			=> 'la_stats_counter',
		'icon'          => 'la-wpb-icon la_stats_counter',
		'category'  	=> __('La Studio', LA_TEXTDOMAIN),
		'description' 	=> __('Your milestones, achievements, etc.',LA_TEXTDOMAIN),
		'params' 		=> $shortcode_params
	),
    'la_stats_counter'
);