<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$carousel = LaStudio_Shortcodes_Helper::fieldCarousel(array(
    'element' => 'enable_carousel',
    'not_empty' => true
));
$shortcode_params = array(
    array(
        'type' => 'dropdown',
        'heading' => __('Design',LA_TEXTDOMAIN),
        'param_name' => 'style',
        'value' => array(
            __('Style 01',LA_TEXTDOMAIN) => '1',
            __('Style 02',LA_TEXTDOMAIN) => '2',
            __('Style 03',LA_TEXTDOMAIN) => '3',
            __('Style 04',LA_TEXTDOMAIN) => '4',
            __('Style 05',LA_TEXTDOMAIN) => '5',
        ),
        'default' => '1'
    ),
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Choose member', LA_TEXTDOMAIN ),
        'param_name' => 'ids',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => true,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 1,
            'auto_focus'     => true,
            'display_inline' => true
        ),
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Total items', LA_TEXTDOMAIN),
        'description' => __('Set max limit for items in grid or enter -1 to display all (limited to 1000).', LA_TEXTDOMAIN),
        'param_name' => 'per_page',
        'value' => 4,
        'min' => -1,
        'max' => 1000
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Item title tag',LA_TEXTDOMAIN),
        'param_name' => 'title_tag',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'h3',
            __('H1',LA_TEXTDOMAIN) => 'h1',
            __('H2',LA_TEXTDOMAIN) => 'h2',
            __('H4',LA_TEXTDOMAIN) => 'h4',
            __('H5',LA_TEXTDOMAIN) => 'h5',
            __('H6',LA_TEXTDOMAIN) => 'h6',
            __('DIV',LA_TEXTDOMAIN) => 'div',
        ),
        'default' => 'h3',
        'description' => __('Default is H3', LA_TEXTDOMAIN),
    ),
    array(
        'type'       => 'checkbox',
        'heading'    => __('Enable slider', LA_TEXTDOMAIN ),
        'param_name' => 'enable_carousel',
        'value'      => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' )
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Excerpt Length(Optional)', LA_TEXTDOMAIN),
        'param_name' => 'excerpt_length',
        'value' => 10,
        'min' => 10,
        'suffix' => ''
    ),
    LaStudio_Shortcodes_Helper::fieldColumn(),
    LaStudio_Shortcodes_Helper::fieldImageSize(),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);


$shortcode_params = array_merge( $shortcode_params, $carousel);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Team Member', LA_TEXTDOMAIN),
        'base'			=> 'la_team_member',
        'icon'          => 'la-wpb-icon la_team_member',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display the team member',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_team_member'
);