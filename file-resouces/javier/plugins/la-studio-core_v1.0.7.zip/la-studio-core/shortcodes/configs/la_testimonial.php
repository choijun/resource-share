<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$carousel = LaStudio_Shortcodes_Helper::fieldCarousel(array(
    'element' => 'enable_carousel',
    'not_empty' => true
));
$shortcode_params = array(
    array(
        'type' => 'dropdown',
        'heading' => __('Design',LA_TEXTDOMAIN),
        'param_name' => 'style',
        'value' => array(
            __('Style 01',LA_TEXTDOMAIN) => '1',
            __('Style 02',LA_TEXTDOMAIN) => '2'
        ),
        'default' => '1'
    ),
    array(
        'type'       => 'autocomplete',
        'heading'    => __( 'Choose member', LA_TEXTDOMAIN ),
        'param_name' => 'ids',
        'settings'   => array(
            'unique_values'  => true,
            'multiple'       => true,
            'sortable'       => true,
            'groups'         => false,
            'min_length'     => 1,
            'auto_focus'     => true,
            'display_inline' => true
        ),
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Item title tag',LA_TEXTDOMAIN),
        'param_name' => 'title_tag',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'h3',
            __('H1',LA_TEXTDOMAIN) => 'h1',
            __('H2',LA_TEXTDOMAIN) => 'h2',
            __('H4',LA_TEXTDOMAIN) => 'h4',
            __('H5',LA_TEXTDOMAIN) => 'h5',
            __('H6',LA_TEXTDOMAIN) => 'h6',
            __('DIV',LA_TEXTDOMAIN) => 'div',
        ),
        'default' => 'h3',
        'description' => __('Default is H3', LA_TEXTDOMAIN),
    ),
    array(
        'type'       => 'checkbox',
        'heading'    => __('Enable slider', LA_TEXTDOMAIN ),
        'param_name' => 'enable_carousel',
        'value'      => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' )
    ),

    LaStudio_Shortcodes_Helper::fieldColumn(),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);

$shortcode_params = array_merge( $shortcode_params, $carousel);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Testimonials', LA_TEXTDOMAIN),
        'base'			=> 'la_testimonial',
        'icon'          => 'la-wpb-icon la_testimonial',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display the testimonial',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'la_testimonial'
);