<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Timeline', LA_TEXTDOMAIN),
		'base'			=> 'la_timeline',
		'icon'          => 'la-wpb-icon la_timeline',
		'category'  	=> __('La Studio', LA_TEXTDOMAIN),
		'description' 	=> __('Displays the timeline block',LA_TEXTDOMAIN),
		'as_parent'         => array('only' => 'la_timeline_item'),
		'content_element'   => true,
		'is_container'      => true,
		'show_settings_on_create' => false,
		'params' 		=> array(
			array(
				'type' => 'dropdown',
				'heading' => __( 'Design', LA_TEXTDOMAIN),
				'param_name' => 'style',
				'value' => array(
					__('Default', LA_TEXTDOMAIN) => 'default',
					__('Style 01', LA_TEXTDOMAIN) => '1',
					__('Style 02', LA_TEXTDOMAIN) => '2',
				),
			),
			LaStudio_Shortcodes_Helper::fieldExtraClass()
		),
		'js_view' => 'VcColumnView',
		'html_template' => plugin_dir_path(dirname(__FILE__)) . '/templates/la_timeline.php'
	),
    'la_timeline'
);