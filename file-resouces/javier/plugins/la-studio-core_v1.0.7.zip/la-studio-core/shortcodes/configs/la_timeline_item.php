<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Timeline', LA_TEXTDOMAIN),
		'base'			=> 'la_timeline_item',
		'icon'          => 'la-wpb-icon la_timeline_item',
		'category'  	=> __('La Studio', LA_TEXTDOMAIN),
		'description' 	=> __('Displays the timeline block',LA_TEXTDOMAIN),
		'as_child'         => array('only' => 'la_timeline'),
		'content_element'   => true,
		'params' 		=> array(
			array(
				"type" => "textfield",
				"heading" => __("Title", LA_TEXTDOMAIN),
				"param_name" => "title",
				"admin_label" => true
			),
			array(
				"type" => "textfield",
				"heading" => __("Sub-Title", LA_TEXTDOMAIN),
				"param_name" => "sub_title",
				"admin_label" => true
			),
			array(
				"type" => "textarea_html",
				"heading" => __("Content", LA_TEXTDOMAIN),
				"param_name" => "content",
			),
			array(
				"type" => "dropdown",
				"heading" => __("Apply link to:", LA_TEXTDOMAIN),
				"param_name" => "time_link_apply",
				"value" => array(
					__("None",LA_TEXTDOMAIN) => "",
					__("Complete box",LA_TEXTDOMAIN) => "box",
					__("Box Title",LA_TEXTDOMAIN) => "title",
					__("Display Read More",LA_TEXTDOMAIN) => "more",
				),
				"description" => __("Select the element for link.", LA_TEXTDOMAIN)
			),
			array(
				"type" => "vc_link",
				"heading" => __("Add Link", LA_TEXTDOMAIN),
				"param_name" => "time_link",
				"dependency" => Array("element" => "time_link_apply","value" => array("more","title","box")),
				"description" => __("Provide the link that will be applied to this timeline.", LA_TEXTDOMAIN)
			),
			array(
				"type" => "textfield",
				"heading" => __("Read More Text", LA_TEXTDOMAIN),
				"param_name" => "time_read_text",
				"value" => "Read More",
				"description" => __("Customize the read more text.", LA_TEXTDOMAIN),
				"dependency" => Array("element" => "time_link_apply","value" => array("more")),
			),
			LaStudio_Shortcodes_Helper::fieldCssAnimation(),
			LaStudio_Shortcodes_Helper::fieldExtraClass()
		),
	),
    'la_timeline_item'
);