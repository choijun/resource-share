<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'autocomplete',
        'heading' => __( 'Select identificator', LA_TEXTDOMAIN ),
        'param_name' => 'id',
        'description' => __( 'Input product ID or product SKU or product title to see suggestions', LA_TEXTDOMAIN ),
    ),
    array(
        'type' => 'hidden',
        'param_name' => 'sku',
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Layout',LA_TEXTDOMAIN),
        'param_name' => 'layout',
        'value' => array(
            __('List',LA_TEXTDOMAIN) => 'list',
            __('Grid',LA_TEXTDOMAIN) => 'grid'
        ),
        'default' => 'grid'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'list_style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'default',
            __('Mini',LA_TEXTDOMAIN) => 'mini'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'list'
        ),
        'default' => 'default'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'grid_style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'default',
            __('Design 02',LA_TEXTDOMAIN) => '2',
            __('Design 03',LA_TEXTDOMAIN) => '3',
            __('Design 04',LA_TEXTDOMAIN) => '4'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'grid'
        ),
        'default' => 'default'
    ),
    array(
        'type' 			=> 'checkbox',
        'heading' 		=> __( 'Enable Custom Image Size', LA_TEXTDOMAIN ),
        'param_name' 	=> 'enable_custom_image_size',
        'value' 		=> array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
    ),
    array(
        'type' 			=> 'checkbox',
        'heading' 		=> __( 'Disable alternative image ', LA_TEXTDOMAIN ),
        'param_name' 	=> 'disable_alt_image',
        'value' 		=> array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
    ),
    LaStudio_Shortcodes_Helper::fieldImageSize(array(
        'dependency' => array(
            'element'   => 'enable_custom_image_size',
            'value'     => 'yes'
        )
    )),
    array(
        'type' => 'checkbox',
        'heading' => __( 'Enable Ajax Loading', LA_TEXTDOMAIN ),
        'param_name' => 'enable_ajax_loader',
        'value' => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);


return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Product', LA_TEXTDOMAIN),
        'base'			=> 'product',
        'icon'          => 'icon-wpb-woocommerce',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Show a single product by ID or SKU.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'product'
);