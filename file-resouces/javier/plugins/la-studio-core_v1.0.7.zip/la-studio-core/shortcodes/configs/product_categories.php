<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'la_number',
        'heading' => __( 'Number', LA_TEXTDOMAIN ),
        'param_name' => 'number',
        'description' => __( 'The `number` field is used to display the number of products.', LA_TEXTDOMAIN ),
        'min' => 0,
        'max' => 1000
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Order by', LA_TEXTDOMAIN ),
        'param_name' => 'orderby',
        'value' => array(
            '',
            __( 'Date', LA_TEXTDOMAIN ) => 'date',
            __( 'ID', LA_TEXTDOMAIN ) => 'ID',
            __( 'Author', LA_TEXTDOMAIN ) => 'author',
            __( 'Title', LA_TEXTDOMAIN ) => 'title',
            __( 'Modified', LA_TEXTDOMAIN ) => 'modified',
            __( 'Random', LA_TEXTDOMAIN ) => 'rand',
            __( 'Comment count', LA_TEXTDOMAIN ) => 'comment_count',
            __( 'Menu order', LA_TEXTDOMAIN ) => 'menu_order',
        ),
        'save_always' => true,
        'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', LA_TEXTDOMAIN ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Sort order', LA_TEXTDOMAIN ),
        'param_name' => 'order',
        'value' => array(
            '',
            __( 'Descending', LA_TEXTDOMAIN ) => 'DESC',
            __( 'Ascending', LA_TEXTDOMAIN ) => 'ASC',
        ),
        'save_always' => true,
        'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', LA_TEXTDOMAIN ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
    ),
    array(
        'type' => 'checkbox',
        'heading' => __( 'Hide Empty', LA_TEXTDOMAIN ),
        'param_name' => 'hide_empty',
        'value' => array( __( 'Yes', LA_TEXTDOMAIN) => '1' ),
    ),
    array(
        'type' => 'autocomplete',
        'heading' => __( 'Categories', LA_TEXTDOMAIN ),
        'param_name' => 'ids',
        'settings' => array(
            'multiple' => true,
            'sortable' => true,
        ),
        'save_always' => true,
        'description' => __( 'List of product categories', LA_TEXTDOMAIN ),
    ),

    LaStudio_Shortcodes_Helper::fieldColumn(array(
        'heading' 		=> __('Columns', LA_TEXTDOMAIN),
        'param_name' 	=> 'columns'
    )),

    LaStudio_Shortcodes_Helper::fieldExtraClass()
);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Product Categories', LA_TEXTDOMAIN),
        'base'			=> 'product_categories',
        'icon'          => 'icon-wpb-woocommerce',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display product categories loop',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'product_categories'
);