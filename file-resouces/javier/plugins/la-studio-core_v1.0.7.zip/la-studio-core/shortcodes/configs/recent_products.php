<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

$shortcode_params = array(
    array(
        'type' => 'dropdown',
        'heading' => __('Layout',LA_TEXTDOMAIN),
        'param_name' => 'layout',
        'value' => array(
            __('List',LA_TEXTDOMAIN) => 'list',
            __('Grid',LA_TEXTDOMAIN) => 'grid'
        ),
        'default' => 'grid'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'list_style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'default',
            __('Mini',LA_TEXTDOMAIN) => 'mini',
            __('Book',LA_TEXTDOMAIN) => 'book'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'list'
        ),
        'default' => 'default'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Style',LA_TEXTDOMAIN),
        'param_name' => 'grid_style',
        'value' => array(
            __('Default',LA_TEXTDOMAIN) => 'default',
            __('Design 02',LA_TEXTDOMAIN) => '2',
            __('Design 03',LA_TEXTDOMAIN) => '3',
            __('Design 04',LA_TEXTDOMAIN) => '4'
        ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'grid'
        ),
        'default' => 'default'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Order by', LA_TEXTDOMAIN ),
        'param_name' => 'orderby',
        'value' => array(
            '',
            __( 'Date', LA_TEXTDOMAIN ) => 'date',
            __( 'ID', LA_TEXTDOMAIN ) => 'ID',
            __( 'Author', LA_TEXTDOMAIN ) => 'author',
            __( 'Title', LA_TEXTDOMAIN ) => 'title',
            __( 'Modified', LA_TEXTDOMAIN ) => 'modified',
            __( 'Random', LA_TEXTDOMAIN ) => 'rand',
            __( 'Comment count', LA_TEXTDOMAIN ) => 'comment_count',
            __( 'Menu order', LA_TEXTDOMAIN ) => 'menu_order',
        ),
        'save_always' => true,
        'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', LA_TEXTDOMAIN ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Sort order', LA_TEXTDOMAIN ),
        'param_name' => 'order',
        'value' => array(
            '',
            __( 'Descending', LA_TEXTDOMAIN ) => 'DESC',
            __( 'Ascending', LA_TEXTDOMAIN ) => 'ASC',
        ),
        'save_always' => true,
        'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', LA_TEXTDOMAIN ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
    ),
    array(
        'type' => 'la_number',
        'heading' => __('Total items', LA_TEXTDOMAIN),
        'description' => __('The "per_page" shortcode determines how many products to show on the page', LA_TEXTDOMAIN),
        'param_name' => 'per_page',
        'value' => 12,
        'min' => -1,
        'max' => 1000
    ),
    array(
        'type' => 'hidden',
        'heading' => __('Paged', LA_TEXTDOMAIN),
        'param_name' => 'paged',
        'value' => '1'
    ),
    LaStudio_Shortcodes_Helper::fieldColumn(array(
        'heading' 		=> __('Columns', LA_TEXTDOMAIN),
        'param_name' 	=> 'columns',
        'dependency' => array(
            'element'   => 'layout',
            'value'     => array('grid')
        )
    )),
    array(
        'type' 			=> 'checkbox',
        'heading' 		=> __( 'Enable Custom Image Size', LA_TEXTDOMAIN ),
        'param_name' 	=> 'enable_custom_image_size',
        'value' 		=> array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
    ),
    array(
        'type' 			=> 'checkbox',
        'heading' 		=> __( 'Disable alternative image ', LA_TEXTDOMAIN ),
        'param_name' 	=> 'disable_alt_image',
        'value' 		=> array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
    ),
    LaStudio_Shortcodes_Helper::fieldImageSize(array(
        'dependency' => array(
            'element'   => 'enable_custom_image_size',
            'value'     => 'yes'
        )
    )),
    array(
        'type'       => 'checkbox',
        'heading'    => __('Enable slider', LA_TEXTDOMAIN ),
        'param_name' => 'enable_carousel',
        'value'      => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
        'dependency' => array(
            'element'   => 'layout',
            'value'     => 'grid'
        )
    ),
    array(
        'type' => 'checkbox',
        'heading' => __( 'Enable Ajax Loading', LA_TEXTDOMAIN ),
        'param_name' => 'enable_ajax_loader',
        'value' => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
    ),
    array(
        'type'       => 'checkbox',
        'heading'    => __( 'Enable Load More', LA_TEXTDOMAIN ),
        'param_name' => 'enable_loadmore',
        'value'      => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' )
    ),
    array(
        'type' => 'textfield',
        'heading' => __('Load More Text', LA_TEXTDOMAIN),
        'param_name' => 'load_more_text',
        'value' => __('Load more', LA_TEXTDOMAIN),
        'dependency' => array( 'element' => 'enable_loadmore', 'value' => 'yes' ),
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);
$carousel = LaStudio_Shortcodes_Helper::fieldCarousel(array(
    'element' => 'enable_carousel',
    'not_empty' => true
));
$shortcode_params = array_merge( $shortcode_params, $carousel);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Recent products', LA_TEXTDOMAIN),
        'base'			=> 'recent_products',
        'icon'          => 'icon-wpb-woocommerce',
        'category'  	=> __('La Studio', LA_TEXTDOMAIN),
        'description' 	=> __('Display Recent Products.',LA_TEXTDOMAIN),
        'params' 		=> $shortcode_params
    ),
    'recent_products'
);