<?php

if (!defined('ABSPATH')){ die(); }

if(!class_exists('WPBakeryShortCode')){
	return;
}

if(!class_exists('LaStudio_Shortcodes_Abstract')){
	abstract class LaStudio_Shortcodes_Abstract extends WPBakeryShortCode {

		static $html_ajax_template, $_html_template;

		public $_template_folder = 'templates';

		protected function findShortcodeTemplate() {

			self::$html_ajax_template 	= plugin_dir_path(__FILE__) . $this->_template_folder . '/ajax_wrapper.php';
			self::$_html_template 		= plugin_dir_path(__FILE__) . $this->_template_folder . '/'. $this->getShortcode() .'.php';
			$_template = parent::findShortcodeTemplate();
			if($_template){
				return $_template;
			}else{
				if(isset($this->atts['enable_ajax_loader']) && !empty($this->atts['enable_ajax_loader'])){
					unset($this->atts['enable_ajax_loader']);
					return $this->setTemplate(self::$html_ajax_template);
				}else{
					return $this->setTemplate(self::$_html_template);
				}
			}
		}

		public function query($args){
			return new WP_Query($args);
		}

		public function renderAjax( $request_param ) {
			$shortcode_atts = isset($request_param['atts']) ? $request_param['atts'] : array();
			$content = isset($request_param['content']) ? $request_param['content'] : null;
			return $this->content($shortcode_atts,$content);
		}

		protected function getResponsiveColumn($atts){
			$array = array(
				'xlg' => 1,
				'lg' => 1,
				'md' => 1,
				'sm' => 1,
				'xs' => 1,
			);
			$atts = explode(';',$atts);
			if(!empty($atts)){
				foreach($atts as $val){
					$val = explode(':',$val);
					if(isset($val[0]) && isset($val[1])){
						if(isset($array[$val[0]])){
							$array[$val[0]] = absint($val[1]);
						}
					}
				}
			}
			return $array;
		}
	}
}

if(!class_exists('LaStudio_Shortcodes_Helper')){
	class LaStudio_Shortcodes_Helper{
		public static function fieldIconType($dependency = array(), $emptyIcon = false){
			return array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', LA_TEXTDOMAIN ),
					'value' => array(
						__( 'Font Awesome', LA_TEXTDOMAIN ) => 'fontawesome',
						__( 'Open Iconic', LA_TEXTDOMAIN ) => 'openiconic',
						__( 'Typicons', LA_TEXTDOMAIN ) => 'typicons',
						__( 'Entypo', LA_TEXTDOMAIN ) => 'entypo',
						__( 'Linecons', LA_TEXTDOMAIN ) => 'linecons',
						__( 'Mono Social', LA_TEXTDOMAIN ) => 'monosocial',
						__( 'Nucleo Outline', LA_TEXTDOMAIN ) => 'nucleo_outline',
						__( 'Custom Image', LA_TEXTDOMAIN) => 'custom',
					),
					'param_name' => 'icon_type',
					'description' => __( 'Select icon library.', LA_TEXTDOMAIN ),
					'dependency' => $dependency
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-info-circle',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'fontawesome',
					)
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_openiconic',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'type' => 'openiconic',
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'openiconic',
					)
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_typicons',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'type' => 'typicons',
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'typicons',
					)
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_entypo',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'type' => 'entypo',
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'entypo',
					),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_linecons',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'type' => 'linecons',
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'linecons',
					)
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_monosocial',
					'value' => 'vc-mono vc-mono-fivehundredpx',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'type' => 'monosocial',
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'monosocial',
					)
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', LA_TEXTDOMAIN ),
					'param_name' => 'icon_nucleo_outline',
					'value' => 'nc-icon-outline design-2_image',
					'settings' => array(
						'emptyIcon' => $emptyIcon,
						'type' => 'nucleo_outline',
						'iconsPerPage' => 50,
					),
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'nucleo_outline',
					)
				),
				array(
					'type' => 'attach_image',
					'heading' => __('Upload the custom image icon', LA_TEXTDOMAIN),
					'param_name' => "icon_image_id",
					'dependency' => array(
						'element' => 'icon_type',
						'value' => 'custom',
					),
				)
			);
		}
		public static function fieldColumn($options = array()){
			return array_merge(array(
				'type' 			=> 'la_column',
				'heading' 		=> __('Column', LA_TEXTDOMAIN),
				'param_name' 	=> 'column',
				'unit'			=> '',
				'media'			=> array(
					'xlg'	=> 1,
					'lg'	=> 1,
					'md'	=> 1,
					'sm'	=> 1,
					'xs'	=> 1
				)
			), $options);
		}
		public static function fieldImageSize($options = array()){
			return array_merge(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> __('Image size', LA_TEXTDOMAIN),
					'param_name' 	=> 'img_size',
					'value'			=> 'thumbnail',
					'description' 	=> __('Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', LA_TEXTDOMAIN),
				),
				$options
			);
		}

		public static function fieldCssAnimation($options = array()){
			return array_merge(
				array(
					'type' => 'animation_style',
					'heading' => __( 'CSS Animation', LA_TEXTDOMAIN ),
					'param_name' => 'css_animation',
					'value' => 'none',
					'settings' => array(
						'type' => array(
							'in',
							'other',
						),
					),
					'description' => __( 'Select initial loading animation for element.', LA_TEXTDOMAIN ),
				),
				$options
			);
		}

		public static function fieldExtraClass($options = array()){
			return array_merge(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> __('Extra Class name', LA_TEXTDOMAIN),
					'param_name' 	=> 'el_class',
					'description' 	=> __('Style particular content element differently - add a class name and refer to it in custom CSS.', LA_TEXTDOMAIN)
				),
				$options
			);
		}
		public static function fieldCssClass($options = array()){
			return array_merge(
				array(
					'type' 			=> 'css_editor',
					'heading' 		=> __('CSS box', LA_TEXTDOMAIN),
					'param_name' 	=> 'css',
					'group' 		=> __('Design Options', LA_TEXTDOMAIN)
				),
				$options
			);
		}
		public static function fieldCarousel($dependency = array()){
			$group = __('Slider Settings', LA_TEXTDOMAIN);
			return array(
				array(
					'type' 			=> 'la_number',
					'heading' 		=> __('Slide Scrolling Speed', LA_TEXTDOMAIN),
					'param_name' 	=> 'scroll_speed',
					'value' 		=> 1000,
					'min' 			=> 100,
					'suffix' 		=> __('Milliseconds', LA_TEXTDOMAIN),
					'description' 	=> __('Slide transition duration (in milliseconds)', LA_TEXTDOMAIN),
					'group' 		=> $group,
					'dependency' 	=> $dependency
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> __('Advanced settings', LA_TEXTDOMAIN),
					'param_name' 	=> 'advanced_opts',
					'value' 		=> array(
						__('Enable infinite scroll', LA_TEXTDOMAIN) . '<br/>' => 'loop',
						__('Enable dots', LA_TEXTDOMAIN) . '<br/>' 			=> 'dot',
						__('Enable navigation', LA_TEXTDOMAIN) . '<br/>' 		=> 'nav',
						__('Enable autoplay',LA_TEXTDOMAIN) . '<br/>' 		=> 'autoplay',
					),
					'group' 		=> $group,
					'dependency' 	=> $dependency

				),
				array(
					'type' 			=> 'la_number',
					'heading' 		=> __('AutoPlay Speed', LA_TEXTDOMAIN),
					'param_name'	=> 'autoplay_speed',
					'value' 		=> 3000,
					'min' 			=> 100,
					'suffix' 		=> 'ms',
					'description' 	=> __('Autoplay Speed in milliseconds', LA_TEXTDOMAIN),
					'group' 		=> $group,
					'dependency' 	=> array(
						'element'	=> 'advanced_opts',
						'value'		=> 'autoplay'
					)
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> __( 'Custom Navigation Carousel Element', LA_TEXTDOMAIN ),
					'param_name' 	=> 'custom_nav',
					'description' 	=> "Ex: jQuery('.{class_name}') or jQuery(#{id_name})",
					'group' 		=> $group,
					'dependency' 	=> array(
						'element'	=> 'advanced_opts',
						'value'		=> 'nav'
					)
				)
			);
		}
		public static function getColumnFromShortcodeAtts( $atts ){
			$array = array(
				'xlg'	=> 1,
				'lg' 	=> 1,
				'md' 	=> 1,
				'sm' 	=> 1,
				'xs' 	=> 1
			);
			$atts = explode(';',$atts);
			if(!empty($atts)){
				foreach($atts as $val){
					$val = explode(':',$val);
					if(isset($val[0]) && isset($val[1])){
						if(isset($array[$val[0]])){
							$array[$val[0]] = absint($val[1]);
						}
					}
				}
			}
			return $array;
		}
		public static function fieldTitleGFont( $name = 'title', $title = 'Title',  $options = array() ){
			$group = __('Typography', LA_TEXTDOMAIN);
			$array = array();
			$array[] = array(
				'type' 			=> 'la_heading',
				'param_name' 	=> $name . '__typography',
				'text' 			=> $title . __(' settings', LA_TEXTDOMAIN),
				'group' 		=> $group
			);
			$array[] = array(
				'type' => 'checkbox',
				'heading' => __( 'Use google fonts family?', LA_TEXTDOMAIN ),
				'param_name' => 'use_gfont_' . $name,
				'value' => array( __( 'Yes', LA_TEXTDOMAIN ) => 'yes' ),
				'description' => __( 'Use font family from the theme.', LA_TEXTDOMAIN ),
				'group' 		=> $group
			);
			$array[] = array(
				'type' 			=> 'google_fonts',
				'param_name' 	=> $name . '_font',
				'dependency' 	=> array(
					'element' => 'use_gfont_' . $name,
					'value' => 'yes',
				),
				'group' 		=> $group
			);
			$array[] = array(
				'type' 			=> 'la_column',
				'heading' 		=> __('Font size', LA_TEXTDOMAIN),
				'param_name' 	=> $name . '_fz',
				'unit' 			=> 'px',
				'media' => array(
					'xlg'	=> '',
					'lg'    => '',
					'md'    => '',
					'sm'    => '',
					'xs'	=> ''
				),
				'group' 		=> $group
			);
			$array[] = array(
				'type' 			=> 'la_column',
				'heading' 		=> __('Line Height', LA_TEXTDOMAIN),
				'param_name' 	=> $name . '_lh',
				'unit' 			=> 'px',
				'media' => array(
					'xlg'	=> '',
					'lg'    => '',
					'md'    => '',
					'sm'    => '',
					'xs'	=> ''
				),
				'group' 		=> $group
			);
			$array[] = array(
				'type' 			=> 'colorpicker',
				'param_name' 	=> $name . '_color',
				'heading' 		=> __('Color', LA_TEXTDOMAIN),
				'group' 		=> $group
			);
			return array_merge( $array, $options);
		}
		public static function getResponsiveMediaCss( $args ){
			$content = '';
			if(isset($args) && is_array($args)) {
				if (array_key_exists('target',$args)) {
					if(!empty($args['target'])) {
						$content .=  " data-unit-target='".esc_attr($args['target'])."' ";
					}
				}
				if (array_key_exists('media_sizes',$args)) {
					if(!empty($args['media_sizes'])) {
						$content .=  " data-responsive-json-new='".esc_attr(json_encode($args['media_sizes']))."' ";
					}
				}
			}
			return $content;
		}
		public static function parseGoogleFontAtts( $value ){
			$fields = array();
			$styles = array();
			$settings = get_option( 'wpb_js_google_fonts_subsets' );
			if ( is_array( $settings ) && ! empty( $settings ) ) {
				$subsets = '&subset=' . implode( ',', $settings );
			} else {
				$subsets = '';
			}
			$value = vc_parse_multi_attribute($value);
			if(isset($value['font_family']) && isset($value['font_style'])){
				$google_fonts_family = explode( ':', $value['font_family'] );
				$styles[] = 'font-family:' . $google_fonts_family[0];
				$google_fonts_styles = explode( ':', $value['font_style'] );
				$styles[] = 'font-weight:' . $google_fonts_styles[1];
				$styles[] = 'font-style:' . $google_fonts_styles[2];
				$fields['font_url'] = '//fonts.googleapis.com/css?family=' . rawurlencode($value['font_family']) . $subsets;
				$fields['font_family'] = vc_build_safe_css_class($value['font_family']);

				$fields['style'] = implode(';',$styles);
			}
			return $fields;
		}
		public static function getImageSizeFormString($thumb_size, $default = 'thumbnail'){
			if( strpos($thumb_size, 'la_') !== FALSE ){
				return $thumb_size;
			}
			global $_wp_additional_image_sizes;
			if ( is_string( $thumb_size ) && ( ( ! empty( $_wp_additional_image_sizes[ $thumb_size ] ) && is_array( $_wp_additional_image_sizes[ $thumb_size ] ) ) || in_array( $thumb_size, array(
						'thumbnail',
						'thumb',
						'medium',
						'large',
						'full'
					) ) )
			) {
				return $thumb_size;
			}
			else{
				preg_match_all( '/\d+/', $thumb_size, $thumb_matches );
				if ( isset( $thumb_matches[0] ) ) {
					$thumb_size = array();
					if ( count( $thumb_matches[0] ) > 1 ) {
						$thumb_size[] = $thumb_matches[0][0]; // width
						$thumb_size[] = $thumb_matches[0][1]; // height
					} elseif ( count( $thumb_matches[0] ) > 0 && count( $thumb_matches[0] ) < 2 ) {
						$thumb_size[] = $thumb_matches[0][0]; // width
						$thumb_size[] = 0; //$thumb_matches[0][0]; // height
					} else {
						$thumb_size = $default;
					}
				}else{
					$thumb_size = $default;
				}
				return $thumb_size;
			}
		}
		public static function getSliderConfigs($default = array()){
			$configs = array_merge($configs = array(
				'infinite' => false,
				'xlg' => 1,
				'lg' => 1,
				'md' => 1,
				'sm' => 1,
				'xs' => 1,
				'dots' => false,
				'autoplay' => false,
				'arrows' => false,
				'speed' => 1000,
				'autoplaySpeed' => 3000,
				'custom_nav' => ''
			), $default);
			$slider_config = array(
				'infinite' => $configs['infinite'],
				'dots' => $configs['dots'],
				'slidesToShow' => $configs['xlg'],
				'slidesToScroll' => $configs['xlg'],
				'autoplay' => $configs['autoplay'],
				'arrows' => $configs['arrows'],
				'speed' => $configs['speed'],
				'autoplaySpeed' => $configs['autoplaySpeed'],
				'responsive' => array(
					array(
						'breakpoint' => 1440,
						'settings' => array(
							'slidesToShow' => $configs['xlg'],
							'slidesToScroll' => $configs['xlg']
						)
					),
					array(
						'breakpoint' => 1200,
						'settings' => array(
							'slidesToShow' => $configs['lg'],
							'slidesToScroll' => $configs['lg']
						)
					),
					array(
						'breakpoint' => 1024,
						'settings' => array(
							'slidesToShow' => $configs['md'],
							'slidesToScroll' => $configs['md']
						)
					),
					array(
						'breakpoint' => 992,
						'settings' => array(
							'slidesToShow' => $configs['sm'],
							'slidesToScroll' => $configs['sm']
						)
					),
					array(
						'breakpoint' => 768,
						'settings' => array(
							'slidesToShow' => $configs['xs'],
							'slidesToScroll' => $configs['xs']
						)
					)
				)
			);
			if(isset($configs['custom_nav']) && !empty($configs['custom_nav'])){
				$slider_config['appendArrows'] = 'jQuery("'.esc_attr($configs['custom_nav']).'")';
			}
			return json_encode($slider_config);
		}
		public static function getLoadingIcon(){
			ob_start();
			?><svg class="nc-icon outline" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="64px" height="64px" viewBox="0 0 64 64">
				<g transform="translate(0.5, 0.5)">
					<line class="nc-bars-rect-1" data-color="color-2" fill="none" stroke="#2f50e0" stroke-width="1" stroke-linecap="square" stroke-miterlimit="10" x1="32" y1="14" x2="32" y2="48" stroke-linejoin="miter" transform="translate(0 15.822079999372363) scale(1 0.5055600000196137)" style="opacity:0.5055600000196137;"></line>
					<line class="nc-bars-rect-2" fill="none" stroke="#2f50e0" stroke-width="1" stroke-linecap="square" stroke-miterlimit="10" x1="6" y1="14" x2="6" y2="48" transform="translate(0 3.377920000627636) scale(1 0.8944399999803864)" style="opacity:0.8944399999803864;" stroke-linejoin="miter"></line>
					<line class="nc-bars-rect-3" fill="none" stroke="#2f50e0" stroke-width="1" stroke-linecap="square" stroke-miterlimit="10" x1="58" y1="14" x2="58" y2="48" transform="translate(0 3.377920000627636) scale(1 0.8944399999803864)" style="opacity:0.8944399999803864;" stroke-linejoin="miter"></line>
				</g>
				<script>function setAttributes(t,e){for(var a in e)t.setAttribute(a,e[a])}function barsStep(t){startBars||(startBars=t);{var e=t-startBars;Math.min(e/6,100)}600&gt;e||(startBars+=600);if(rectBars[0][0]){window.requestAnimationFrame(barsStep);var a=[],r=[];for(j = 0;  rectBarsNumber &gt; j ; j++) {for(a[0]=300&gt;e?1-2*e/1e3:.4+(e-300)/500,a[1]=a[2]=300&gt;e?.4+2*e/1e3:1-(e-300)/500,i=0;3&gt;i;i++)r[i]=32*(1-a[i]),setAttributes(rectBars[i][j],{transform:"translate(0 "+r[i]+") scale(1 "+a[i]+")",style:"opacity:"+a[i]+";"})}}}!function(){var t=0;window.requestAnimationFrame||(window.requestAnimationFrame=function(e){var a=(new Date).getTime(),r=Math.max(0,16-(a-t)),n=window.setTimeout(function(){e(a+r)},r);return t=a+r,n}),window.cancelAnimationFrame||(window.cancelAnimationFrame=function(t){clearTimeout(t)})}();var rectBars=[],startBars=null;rectBars[0]=document.getElementsByClassName("nc-bars-rect-1"),rectBars[1]=document.getElementsByClassName("nc-bars-rect-2"),rectBars[2]=document.getElementsByClassName("nc-bars-rect-3");var rectBarsNumber = rectBars[0].length; window.requestAnimationFrame(barsStep);</script>
			</svg><?php
			return ob_get_clean();
		}
        public static function getExtraClass( $el_class ) {
            $output = '';
            if ( '' !== $el_class ) {
                $output = ' ' . str_replace( '.', '', $el_class );
            }

            return $output;
        }
        public static function getLoopProducts($query_args, $atts, $loop_name){

            $globalVar      = apply_filters('LaStudio/global_loop_variable', 'lastudio_loop');
            $globalVarTmp   = (isset($GLOBALS[$globalVar]) ? $GLOBALS[$globalVar] : '');
            $globalParams   = array();

            $unique_id      = uniqid($loop_name . '_');
            $css_class      = 'woocommerce' . self::getExtraClass($atts['el_class']);
            $columns        = self::getColumnFromShortcodeAtts(isset($atts['columns']) ? $atts['columns'] : '');
            $layout         = isset($atts['layout']) ? $atts['layout'] : 'grid';
            $style          = $atts[$atts['layout'] . '_style'];

			$loopCssClass 	= array();
            $carousel_configs = $disable_alt_image = $image_size = false;
            if(isset($atts['enable_custom_image_size']) && $atts['enable_custom_image_size'] == 'yes'){
                $image_size = true;
            }
            if(isset($atts['disable_alt_image']) && $atts['disable_alt_image'] == 'yes'){
                $disable_alt_image = true;
            }
            if($layout == 'grid'){
                if(isset($atts['enable_carousel']) && $atts['enable_carousel'] == 'yes'){
                    $advanced_opts = array();
                    if(isset($atts['advanced_opts'])){
                        $advanced_opts = explode(",", $atts['advanced_opts']);
                    }
                    $carousel_configs= array_merge($columns,array(
                        'infinite' => in_array('loop', $advanced_opts) ? true : false,
                        'dots' => in_array('dot', $advanced_opts) ? true : false,
                        'autoplay' => in_array('autoplay', $advanced_opts) ? true : false,
                        'arrows' => in_array('nav', $advanced_opts) ? true : false,
                        'speed' => $atts['scroll_speed'],
                        'autoplaySpeed' => $atts['autoplay_speed'],
                        'custom_nav' => $atts['custom_nav']
                    ));
					$loopCssClass[] = 'la-slick-slider';
                }
            }
            $globalParams['loop_id'] = $unique_id;
            $globalParams['loop_layout'] = $layout;
            $globalParams['loop_style'] = $style;
            if($image_size){
				$globalParams['image_size'] = LaStudio_Shortcodes_Helper::getImageSizeFormString($atts['img_size']);
            }
            if($disable_alt_image){
                $globalParams['disable_alt_image'] = true;
            }
            $GLOBALS[$globalVar] = $globalParams;


            $loopCssClass[] = 'products';
            $loopCssClass[] = 'products-' . $layout;
            $loopCssClass[] = 'products-' . $layout . '-' . $style;
            $loopCssClass[] = 'grid-items';

			if($layout != 'list'){
				foreach( $columns as $screen => $value ){
					$loopCssClass[]  =  sprintf('%s-grid-%s-items', $screen, $value);
				}
			}

            $products = new WP_Query(apply_filters( 'woocommerce_shortcode_products_query', $query_args, $atts, $loop_name ));

            $GLOBALS[$globalVar] = $globalParams;

			$loop_tpl = array();
			$loop_tpl[] = "woocommerce/content-product-{$layout}-{$style}.php";
			$loop_tpl[] = "woocommerce/content-product-{$layout}.php";
			$loop_tpl[] = "woocommerce/content-product.php";

            ob_start();

            if($products->have_posts()){

                do_action('LaStudio/shortcodes/before_loop', 'woo_shortcode', $loop_name, $atts);

                printf('<div class="row"><div class="col-xs-12"><ul class="%s"%s>',
                    esc_attr(implode(' ', $loopCssClass)),
                    $carousel_configs ? '  data-slider_config="'.esc_attr(self::getSliderConfigs($carousel_configs)).'"' : ''
                );

                while( $products->have_posts() ){
                    $products->the_post();
					locate_template($loop_tpl, true, false);
                }

                printf('</ul></div></div>');

                do_action('LaStudio/shortcodes/after_loop', 'woo_shortcode', $loop_name, $atts);

            }

            if(isset($atts['enable_loadmore']) && $atts['enable_loadmore'] == 'yes'){
                echo sprintf(
                    '<div class="elm-loadmore-ajax" data-query-settings="%s" data-request="%s" data-paged="%s" data-max-page="%s" data-container="#%s ul.products" data-item-class=".product-item">%s<a href="#">%s</a></div>',
                    esc_attr( json_encode( array(
                        'tag' => $loop_name,
                        'atts' => $atts
                    ) ) ),
                    esc_url( admin_url( 'admin-ajax.php', 'relative' ) ),
                    esc_attr($atts['paged']),
                    esc_attr($products->max_num_pages),
                    esc_attr($unique_id),
                    LaStudio_Shortcodes_Helper::getLoadingIcon(),
                    esc_html($atts['load_more_text'])
                );
            }

            $GLOBALS[$globalVar] = $globalVarTmp;
            wp_reset_postdata();
            $output = ob_get_clean();

            printf('<div id="%s" class="%s">%s</div>',
                esc_attr($unique_id),
                esc_attr($css_class),
                $output
            );

        }
	}
}

if(!class_exists('LaStudio_Param_Shortcodes')){
	class LaStudio_Param_Shortcodes{
		function __construct(){
			vc_add_shortcode_param('la_column', array($this, 'columnResponsiveCallBack'),plugins_url('assets/js/param_responsive.js',__FILE__));
			vc_add_shortcode_param('la_number' , array($this, 'laNumberCallBack' ));
			vc_add_shortcode_param('la_heading' , array($this, 'headingCallBack' ));
			vc_add_shortcode_param('datetimepicker' , array($this, 'datetimePickerCallBack' ), plugins_url('assets/js/param_datetimepicker.js',__FILE__));
		}

		public function columnResponsiveCallBack($settings, $value){
			$unit = $settings['unit'];
			$medias = $settings['media'];

			if(is_numeric($value)){
				$value = "desktop:".$value.'px;';
			}

			$uid = 'lastudio-responsive-'. rand(1000, 9999);

			$require = sprintf(
				'<div class="simplify"><span class="la-icon"><div class="la-tooltip simplify-options">%s</div><i class="simplify-icon dashicons dashicons-arrow-right-alt2"></i></span></div>',
				__('Responsive Options', LA_TEXTDOMAIN)
			);
			$html  = '<div class="lastudio-responsive-wrapper" id="'.$uid.'"><div class="lastudio-responsive-items">';

			foreach($medias as $key => $default_value ) {

				switch ($key) {
					case 'xlg':
						$html .= $this->getParamMedia(
							'optional',
							'<i class="fa fa-desktop"></i>',
							__('On Extra Large devices Desktops > 1440px', LA_TEXTDOMAIN),
							$default_value,
							$unit,
							$key
						);
						break;

					case 'lg':
						$html .= $this->getParamMedia(
							'optional',
							'<i class="dashicons dashicons-desktop"></i>',
							__('On Large devices Desktops =< 1440px', LA_TEXTDOMAIN),
							$default_value,
							$unit,
							$key
						);
						break;

					case 'md':
						$html .= $this->getParamMedia(
							'required',
							'<i class="dashicons dashicons-desktop" style="transform: scale(0.8);"></i>',
							__('On Medium devices Desktops =< 1200px', LA_TEXTDOMAIN),
							$default_value,
							$unit,
							$key
						);
						$html .= $require;
						break;

					case 'sm':
						$html .= $this->getParamMedia(
							'optional',
							'<i class="dashicons dashicons-tablet"></i>',
							__('On Small devices Tablets  =< 992px', LA_TEXTDOMAIN),
							$default_value,
							$unit,
							$key
						);
						break;

					case 'xs':
						$html .= $this->getParamMedia(
							'optional',
							'<i class="dashicons dashicons-smartphone"></i>',
							__('On Extra small devices =< 768px', LA_TEXTDOMAIN),
							$default_value,
							$unit,
							$key
						);
						break;
				}
			}
			$html .= '</div>';
			$html .= '<div class="lastudio-unit-section"><label>'.$unit.'</label></div>';
			$html .= '<input type="hidden" data-unit="'.$unit.'"  name="'.$settings['param_name'].'" class="wpb_vc_param_value lastudio-responsive-value '.$settings['param_name'].' '.$settings['type'].'_field" value="'.$value.'" />';
			$html .= '</div>';
			return $html;
		}

		public function laNumberCallBack($settings, $value){
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$type = isset($settings['type']) ? $settings['type'] : '';
			$min = isset($settings['min']) ? $settings['min'] : '';
			$max = isset($settings['max']) ? $settings['max'] : '';
			$step = isset($settings['step']) ? $settings['step'] : '';
			$suffix = isset($settings['suffix']) ? $settings['suffix'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$output = '<input type="number" min="'.$min.'" max="'.$max.'" step="'.$step.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'" style="max-width:100px; margin-right: 10px;" />'.$suffix;
			return $output;
		}

		public function headingCallBack($settings, $value){
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$text = isset($settings['text']) ? $settings['text'] : '';
			$output = '<h4 class="wpb_vc_param_value '.$class.'">'.$text.'</h4>';
			$output .= '<input type="hidden" name="'.$param_name.'" class="wpb_vc_param_value lastudio-param-heading '.$param_name.' '.$settings['type'].'_field" value="'.$value.'" />';
			return $output;
		}

		public function datetimePickerCallBack($settings, $value){
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$type = isset($settings['type']) ? $settings['type'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$uni = uniqid('datetimepicker-'.rand());
			$output = '<div id="date-time-'.$uni.'" class="elm-datetime"><input data-format="yyyy/MM/dd hh:mm:ss" readonly class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" style="width:258px;" value="'.$value.'"/><div class="add-on"><i data-time-icon="dashicons-before dashicons-calendar" data-date-icon="dashicons-before dashicons-calendar"></i></div></div>';
			return $output;
		}

		private function getParamMedia($class, $icon, $tip, $default_value, $unit, $data_id){
			return sprintf(
				'<div class="la-responsive-item %1$s %2$s"><span class="la-icon"><div class="la-tooltip %1$s %2$s">%3$s</div>%4$s</span><input type="text" class="la-responsive-input" data-default="%5$s" data-unit="%6$s" data-id="%2$s"/></div>',
				esc_attr($class),
				esc_attr($data_id),
				esc_html($tip),
				$icon,
				esc_attr($default_value),
				esc_attr($unit)
			);
		}
	}
}

if(!class_exists('LaStudio_Shortcode_Autocomplete_Filters')){
	class LaStudio_Shortcode_Autocomplete_Filters{

		public $post_types = array();
		public $taxonomies = array();

		public function __construct(){
			$this->post_types = array(
				'post',
				'product',
				'la_portfolio',
				'la_testimonial',
				//'la_team_member',
				'la_block',
				'la_event',
				'la_course',
			);
			$this->taxonomies = array(
				'tag',
				'category',
				'product_cat',
				'product_tag',
				'la_portfolio_category',
				//'la_portfolio_skill',
				'la_event_category',
				'la_course_category',
			);
			$this->loadFilter();
		}

		private function loadFilter(){
			$filters = array(
				'la_testimonial' => array(
					'ids'	=> array(
						'callback' 	=> 'la_testimonialContentTypeCallback',
						'render' 	=> 'contentTypeRender'
					)
				),
				'la_block' 		 => array(
					'id'	=> array(
						'callback' 	=> 'la_blockContentTypeCallback',
						'render' 	=> 'contentTypeRender'
					)
				),
				'la_team_member' => array(
					'ids'	=> array(
						'callback' 	=> 'la_team_memberContentTypeCallback',
						'render' 	=> 'contentTypeRender'
					)
				),
				'la_show_posts' => array(
					'category__in' 	=> array(
						'callback' 	=> 'categoryTaxCallback',
						'render' 	=> 'categoryTaxRender',
					),
					'category__not_in' 	=> array(
						'callback' 	=> 'categoryTaxCallback',
						'render' 	=> 'categoryTaxRender',
					),
					'post__in' => array(
						'callback' 	=> 'postContentTypeCallback',
						'render' 	=> 'contentTypeRender',
					),
					'post__not_in' => array(
						'callback' 	=> 'postContentTypeCallback',
						'render' 	=> 'contentTypeRender',
					)
				),
				'la_show_portfolios' => array(
					'category__in' 	=> array(
						'callback' 	=> 'la_portfolio_categoryTaxCallback',
						'render' 	=> 'la_portfolio_categoryTaxRender',
					),
					'category__not_in' 	=> array(
						'callback' 	=> 'la_portfolio_categoryTaxCallback',
						'render' 	=> 'la_portfolio_categoryTaxRender',
					),
					'post__in' => array(
						'callback' 	=> 'la_portfolioContentTypeCallback',
						'render' 	=> 'contentTypeRender',
					),
					'post__not_in' => array(
						'callback' 	=> 'la_portfolioContentTypeCallback',
						'render' 	=> 'contentTypeRender',
					)
				),
				'la_portfolio_meta' => array(
					'id' => array(
						'callback' 	=> 'la_portfolioContentTypeCallback',
						'render' 	=> 'contentTypeRender',
					)
				),
				'sale_products' => array(
					'category__in' 	=> array(
						'callback' 	=> 'product_catTaxCallback',
						'render' 	=> 'product_catTaxRender',
					)
				),
			);

			foreach ($filters as $shortcode_name => $fields){
				foreach ( $fields as $field_name => $field){
					foreach( $field as $type => $method ){
						add_filter( "vc_autocomplete_{$shortcode_name}_{$field_name}_{$type}", array( $this, $method) );
					}
				}
			}
		}

		public function __call($name, $arguments){
			if(strpos($name, 'TaxCallback') !== FALSE){
				$taxonomy = str_replace('TaxCallback', '', $name);
				if(in_array($taxonomy, $this->taxonomies)){
					$query = isset($arguments[0]) ? $arguments[0] : array();
					$slug = isset($arguments[1]) ? $arguments[1] : false;
					return $this->getTaxCallback($query, $taxonomy, $slug);
				}
			}
			elseif(strpos($name, 'TaxRender') !== FALSE){
				$taxonomy = str_replace('TaxRender', '', $name);
				if(in_array($taxonomy, $this->taxonomies)){
					$query = isset($arguments[0]) ? $arguments[0] : array();
					return $this->getTaxRender($query, $taxonomy);
				}
			}
			elseif(strpos($name, 'ContentTypeCallback') !== FALSE){
				$post_type = str_replace('ContentTypeCallback', '', $name);
				if(in_array($post_type, $this->post_types)){
					$query = isset($arguments[0]) ? $arguments[0] : array();
					return $this->getPostTypeCallback($query, $post_type);
				}
			}
		}

		private  function getTaxCallback($query,$taxonomy,$slug = false){
			global $wpdb;
			$cat_id = (int) $query;
			$query = trim( $query );
			$array_category = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT a.term_id AS id, b.name as name, b.slug AS slug
								FROM {$wpdb->term_taxonomy} AS a
								INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
								WHERE a.taxonomy = '%s' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )",
					$taxonomy,
					$cat_id > 0 ? $cat_id : -1,
					stripslashes( $query ),
					stripslashes( $query )
				), ARRAY_A );

			$result = array();
			if ( is_array( $array_category ) && !empty( $array_category ) ) {
				foreach ( $array_category as $value ) {
					$data = array();
					$data[ 'value' ] = $slug ? $value[ 'slug' ] : $value[ 'id' ];
					$data[ 'label' ] = __( 'Id', LA_TEXTDOMAIN ) . ': ' .
						$value[ 'id' ] .
						( ( strlen( $value[ 'name' ] ) > 0 ) ? ' - ' . __( 'Name', LA_TEXTDOMAIN ) . ': ' .
							$value[ 'name' ] : '' ) .
						( ( strlen( $value[ 'slug' ] ) > 0 ) ? ' - ' . __( 'Slug', LA_TEXTDOMAIN ) . ': ' .
							$value[ 'slug' ] : '' );
					$result[ ] = $data;
				}
			}

			return $result;
		}

		private  function getTaxRender($query,$taxonomy){
			$query = $query[ 'value' ];
			$cat_id = (int) $query;
			$term = get_term( $cat_id, $taxonomy );

			$term_slug = $term->slug;
			$term_title = $term->name;
			$term_id = $term->term_id;

			$term_slug_display = '';
			if ( !empty( $term_slug ) ) {
				$term_slug_display = ' - ' . __( 'Slug', LA_TEXTDOMAIN ) . ': ' . $term_slug;
			}

			$term_title_display = '';
			if ( !empty( $term_title ) ) {
				$term_title_display = ' - ' . __( 'Title', LA_TEXTDOMAIN ) . ': ' . $term_title;
			}

			$term_id_display = __( 'Id', LA_TEXTDOMAIN ) . ': ' . $term_id;

			$data = array();
			$data[ 'value' ] = $term_id;
			$data[ 'label' ] = $term_id_display . $term_title_display . $term_slug_display;

			return !empty( $data ) ? $data : false;
		}

		private  function getPostTypeCallback($query,$post_type){
			global $wpdb;
			$post_id = (int) $query;
			$array_posts = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT a.ID AS id, a.post_title AS title
						FROM {$wpdb->posts} AS a
						WHERE a.post_type = '%s'
						AND a.post_status LIKE 'publish'
						AND ( a.ID = '%d' OR a.post_title LIKE '%%%s%%' )",
					$post_type,
					$post_id > 0 ? $post_id : -1,
					stripslashes( $query )
				), ARRAY_A );

			$results = array();
			if ( is_array( $array_posts ) && !empty( $array_posts ) ) {
				foreach ( $array_posts as $value ) {
					$data = array();
					$data[ 'value' ] = $value[ 'id' ];
					$data[ 'label' ] = __( 'Id', LA_TEXTDOMAIN ) . ': ' .
						$value[ 'id' ] .
						( ( strlen( $value[ 'title' ] ) > 0 ) ? ' - ' . __( 'Title', LA_TEXTDOMAIN ) . ': ' .
							$value[ 'title' ] : '' );
					$results[ ] = $data;
				}
			}
			return $results;
		}

		public function contentTypeRender($query){
			$query = trim( $query[ 'value' ] );
			if ( !empty( $query ) ) {
				$post_object = get_post( (int) $query );
				if ( is_object( $post_object ) ) {
					$slug = $post_object->post_name;
					$title = $post_object->post_title;
					$post_id = $post_object->ID;
					$post_slug_display = '';
					if ( !empty( $slug ) ) {
						$post_slug_display = ' - ' . __( 'Slug', LA_TEXTDOMAIN ) . ': ' . $slug;
					}
					$post_title_display = '';
					if ( !empty( $title ) ) {
						$post_title_display = ' - ' . __( 'Title', LA_TEXTDOMAIN ) . ': ' . $title;
					}
					$post_id_display = __( 'Id', LA_TEXTDOMAIN ) . ': ' . $post_id;
					$data = array();
					$data[ 'value' ] = $post_id;
					$data[ 'label' ] = $post_id_display . $post_title_display . $post_slug_display;
					return !empty( $data ) ? $data : false;
				}
				return false;
			}
			return false;
		}

	}
}

if(!class_exists('LaStudio_Shortcodes_Class')){
	class LaStudio_Shortcodes_Class {

		private $_shortcodes = array(
			'la_icon_boxes',
			'la_heading',
			//'la_team_member',
			'la_stats_counter',
			'la_testimonial',
			'la_show_posts',
			'la_show_portfolios',
			'la_portfolio_meta',
            'la_maps',
			'la_social_link',
            'la_banner',
			'la_block',
			'la_countdown',
			'la_timeline',
			'la_timeline_item',
			'la_pricing_table',
			'la_divider'
		);

		private $_woo_shortcodes = array(
			'product',
			'products',
			'recent_products',
			'featured_products',
			'product_category',
			'product_categories',
			'sale_products',
			'best_selling_products',
			'top_rated_products',
			'product_attribute'
		);

		private static $instance = null;

		public static function instance() {
			if ( null === static::$instance ) {
				static::$instance = new static();
			}
			return static::$instance;
		}

		protected function __construct() {

			add_shortcode('la_dropcap', array( $this, 'registerDropcapShortcode') );
			add_shortcode('wp_nav_menu', array( $this, 'registerWpNavMenu') );

			add_action( 'init', array( $this, 'overrideWooShortcodes' ) );
			add_action( 'after_setup_theme', array( $this, 'removeDeprecatedWooShortcode') );
			add_action( 'admin_enqueue_scripts', array( $this, 'registerAdminScripts' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'registerFrontEndScripts' ) );

			add_action( 'vc_after_init', array( $this, 'mapShortcodes' ) );

			add_action( 'wp_ajax_get_shortcode_loader_by_ajax', array( $this, 'getItemsForAjax' ) );
			add_action( 'wp_ajax_nopriv_get_shortcode_loader_by_ajax', array( $this, 'getItemsForAjax' ) );

			add_filter( 'the_content', array( $this, 'formatting' ) );
			add_filter( 'widget_text', array( $this, 'formatting' ) );

			add_shortcode( 'la_woocommerce_registration', array( 'LaStudio_Shortcodes_Class', 'registration_template' ) );
		}

		public function mapShortcodes(){

			foreach ($this->_shortcodes as $shortcode) {
				$sc_file = plugin_dir_path(__FILE__) . 'shortcodes/' . $shortcode . '.php';
				$config_file = plugin_dir_path(__FILE__) . 'configs/' . $shortcode . '.php';
				if(file_exists($sc_file) && file_exists( $config_file)){
					require_once $sc_file;
					vc_lean_map( $shortcode, null, $config_file );
				}
			}
			if(class_exists('WooCommerce')){
				foreach ($this->_woo_shortcodes as $shortcode) {
					$sc_file = plugin_dir_path(__FILE__) . 'shortcodes/' . $shortcode . '.php';
					$config_file = plugin_dir_path(__FILE__) . 'configs/' . $shortcode . '.php';
					if(file_exists($sc_file) && file_exists( $config_file)){
						require_once $sc_file;
						vc_lean_map( $shortcode, null, $config_file );
					}
				}
			}
			new LaStudio_Param_Shortcodes();
			new LaStudio_Shortcode_Autocomplete_Filters();
		}

		public function registerAdminScripts() {
			wp_enqueue_style(
				'la-shortcodes-admin',
				plugin_dir_url(__FILE__) . 'assets/css/admin.css'
			);
			wp_enqueue_script(
				'la-shortcodes-admin',
				plugin_dir_url(__FILE__) . 'assets/js/admin.js',
				array( 'jquery' ),
				'1.0.0',
				true
			);
		}

		public function registerFrontEndScripts(){
			$key = cs_get_customize_option('google_key', cs_get_option('google_key'));
			$url = 'https://maps.googleapis.com/maps/api/js';
			if(!empty($key)){
				$url = add_query_arg('key',$key, $url);
			}
            wp_register_script("googleapis", $url ,array(),null,false);
		}

		public function formatting($content) {
			$shortcodes = array_merge($this->_shortcodes, $this->_woo_shortcodes);
			$block = join("|", $shortcodes);
			$content = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]", $content);
			$content = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)/","[/$2]", $content);
			return $content;
		}

		public function getItemsForAjax() {
			$tag = isset($_REQUEST['tag']) ? $_REQUEST['tag'] : '';
			$data = isset($_REQUEST['data']) ? $_REQUEST['data'] : '';
			if( !empty($tag) && !empty($data) ) {
				if(function_exists('visual_composer')){
					$shortcode_fishbone = visual_composer()->getShortCode( $tag );
					if ( is_object( $shortcode_fishbone ) ) {
						$vc_grid = $shortcode_fishbone->shortcodeClass();
						WPBMap::addAllMappedShortcodes();
						if (method_exists( $vc_grid, 'renderAjax' ) ) {
							echo $vc_grid->renderAjax( $data );
						}
					}
				}
			}
			die();
		}

		public function registerDropcapShortcode( $atts, $content = null){
			$style = $color = '';
			extract(shortcode_atts(array(
				'style' => 1,
				'color' => '',
			), $atts));

			ob_start();

			?><span class="la-dropcap style-<?php echo esc_attr($style);?>" style="color:<?php echo esc_attr($color); ?>"><?php echo wp_strip_all_tags($content, true); ?></span><?php

			return ob_get_clean();
		}

		public function registerWpNavMenu( $atts, $content = null){
			$menu_id = $container_class = '';
			extract(shortcode_atts(array(
				'menu_id' => '',
				'container_class' => '',
			), $atts));
			if(!is_nav_menu( $menu_id)){
				return '';
			}
			ob_start();
			wp_nav_menu(array(
				'menu' => $menu_id,
				'container_class' => $container_class
			));
			return ob_get_clean();
		}

		/*
		 * For Woo-Ecommerce
		 */
		public function overrideWooShortcodes(){
			foreach ($this->_woo_shortcodes as $shortcode) {
				add_filter( "{$shortcode}_shortcode_tag", array( $this, 'addDeprecatedWooShortcodeTag' ) );
			}
		}

		public static function registration_template() {

			if(!function_exists('wc_get_template')){
				return;
			}

			ob_start();

			if ( ! is_user_logged_in() ) :

				wc_get_template( 'registration-form.php', array(), 'la-woocommerce-registration/', plugin_dir_path( __FILE__ ) . 'templates/' );

			endif;

			return ob_get_clean();

		}

		public function addDeprecatedWooShortcodeTag( $shortcode ){
			return "{$shortcode}_deprecated";
		}
		public function removeDeprecatedWooShortcode(){
			foreach ($this->_woo_shortcodes as $shortcode) {
				remove_shortcode( "{$shortcode}_deprecated" );
			}
		}
	}
}