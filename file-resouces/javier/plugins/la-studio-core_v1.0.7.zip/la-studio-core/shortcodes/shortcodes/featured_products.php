<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_featured_products' ) ) {
    class WPBakeryShortCode_featured_products extends LaStudio_Shortcodes_Abstract{

    }
}