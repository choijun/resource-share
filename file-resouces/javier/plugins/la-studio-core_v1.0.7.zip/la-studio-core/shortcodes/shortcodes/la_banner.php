<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_banner' ) ) {
    class WPBakeryShortCode_la_banner extends LaStudio_Shortcodes_Abstract{

    }
}