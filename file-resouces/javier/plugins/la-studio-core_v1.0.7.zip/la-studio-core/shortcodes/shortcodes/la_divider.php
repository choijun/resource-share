<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_divider' ) ) {
    class WPBakeryShortCode_la_divider extends LaStudio_Shortcodes_Abstract{

    }
}