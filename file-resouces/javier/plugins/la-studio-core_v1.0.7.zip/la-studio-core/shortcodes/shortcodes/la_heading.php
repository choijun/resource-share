<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_heading' ) ) {
    class WPBakeryShortCode_la_heading extends LaStudio_Shortcodes_Abstract{

    }
}