<?php
if (!defined('ABSPATH')){
	die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_icon_boxes' ) ) {
	class WPBakeryShortCode_la_icon_boxes extends LaStudio_Shortcodes_Abstract{

	}
}