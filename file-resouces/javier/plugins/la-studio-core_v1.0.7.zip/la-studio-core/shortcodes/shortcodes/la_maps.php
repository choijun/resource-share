<?php
if (!defined('ABSPATH')){
	die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_maps' ) ) {
	class WPBakeryShortCode_la_maps extends LaStudio_Shortcodes_Abstract{

	}
}