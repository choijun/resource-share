<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_portfolio_meta' ) ) {
    class WPBakeryShortCode_la_portfolio_meta extends LaStudio_Shortcodes_Abstract{

    }
}