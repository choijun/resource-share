<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_show_portfolios' ) ) {
    class WPBakeryShortCode_la_show_portfolios extends LaStudio_Shortcodes_Abstract{

    }
}