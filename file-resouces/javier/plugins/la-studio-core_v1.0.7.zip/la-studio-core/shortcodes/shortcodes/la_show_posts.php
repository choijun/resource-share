<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_show_posts' ) ) {
    class WPBakeryShortCode_la_show_posts extends LaStudio_Shortcodes_Abstract{

    }
}