<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_social_link' ) ) {
    class WPBakeryShortCode_la_social_link extends LaStudio_Shortcodes_Abstract{

    }
}