<?php
if (!defined('ABSPATH')){
	die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_team_member' ) ) {
	class WPBakeryShortCode_la_team_member extends LaStudio_Shortcodes_Abstract{

	}
}