<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_timeline' ) ) {
    class WPBakeryShortCode_la_timeline extends WPBakeryShortCodesContainer{

    }
}