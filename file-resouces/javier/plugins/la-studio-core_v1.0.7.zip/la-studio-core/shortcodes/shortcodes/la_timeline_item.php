<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_la_timeline_item' ) ) {
    class WPBakeryShortCode_la_timeline_item extends LaStudio_Shortcodes_Abstract{

    }
}