<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_product_categories' ) ) {
    class WPBakeryShortCode_product_categories extends LaStudio_Shortcodes_Abstract{

    }
}