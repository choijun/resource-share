<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_product_category' ) ) {
    class WPBakeryShortCode_product_category extends LaStudio_Shortcodes_Abstract{

    }
}