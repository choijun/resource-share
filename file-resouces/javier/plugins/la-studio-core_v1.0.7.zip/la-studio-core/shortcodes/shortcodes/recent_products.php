<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_recent_products' ) ) {
    class WPBakeryShortCode_recent_products extends LaStudio_Shortcodes_Abstract{

    }
}