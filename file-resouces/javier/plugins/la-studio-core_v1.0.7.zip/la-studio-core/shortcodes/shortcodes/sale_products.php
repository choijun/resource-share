<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_sale_products' ) ) {
    class WPBakeryShortCode_sale_products extends LaStudio_Shortcodes_Abstract{

    }
}