<?php
if (!defined('ABSPATH')){
    die('-1');
}

if ( !class_exists( 'WPBakeryShortCode_top_rated_products' ) ) {
    class WPBakeryShortCode_top_rated_products extends LaStudio_Shortcodes_Abstract{

    }
}