<?php

$number = $orderby = $order = $hide_empty = $ids = $columns = $el_class = $output = '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$css_class = 'woocommerce' . $this->getExtraClass($el_class);

if(!empty($ids)){
    $ids = explode( ',', $ids );
    $ids = array_map( 'trim', $ids );
}

$hide_empty = ( $hide_empty == 1 || $hide_empty == true) ? 1 : 0;

// get terms and workaround WP bug with parents/pad counts
$args = array(
    'orderby'    => $orderby,
    'order'      => $order,
    'hide_empty' => $hide_empty,
    'include'    => $ids,
    'pad_counts' => true
);

$product_categories = get_terms( 'product_cat', $args );


if ( $hide_empty ) {
    foreach ( $product_categories as $key => $category ) {
        if ( $category->count == 0 ) {
            unset( $product_categories[ $key ] );
        }
    }
}

if ( !empty($number) ) {
    $product_categories = array_slice( $product_categories, 0, $number );
}

$columns        = LaStudio_Shortcodes_Helper::getColumnFromShortcodeAtts($columns);
$loopCssClass = array();
$loopCssClass[] = 'products';
$loopCssClass[] = 'grid-items';
foreach( $columns as $screen => $value ){
    $loopCssClass[]  =  sprintf('%s-grid-%s-items', $screen, $value);
}
ob_start();

if ( $product_categories ) {

    echo '<div class="product-categories-wrapper">';
    echo '<ul class="'.esc_attr( implode(' ', $loopCssClass)).'">';
    foreach ( $product_categories as $category ) {
        wc_get_template( 'content-product_cat.php', array(
            'category' => $category
        ) );
    }
    echo '</ul>';
    echo '</div>';
}

woocommerce_reset_loop();

echo '<div class="woocommerce '. esc_attr($css_class) .'">' . ob_get_clean() . '</div>';