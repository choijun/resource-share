<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$query_args = array(
    'post_type'           => 'product',
    'post_status'         => 'publish',
    'ignore_sticky_posts' => 1,
    'orderby'             => $atts['orderby'],
    'order'               => $atts['order'],
    'posts_per_page'      => $atts['per_page'],
    'paged'               => $atts['paged'],
    'meta_query'          => WC()->query->get_meta_query()
);

add_filter( 'posts_clauses', array( 'WC_Shortcodes', 'order_by_rating_post_clauses' ) );

LaStudio_Shortcodes_Helper::getLoopProducts($query_args, $atts, $this->getShortcode());

remove_filter( 'posts_clauses', array( 'WC_Shortcodes', 'order_by_rating_post_clauses' ) );