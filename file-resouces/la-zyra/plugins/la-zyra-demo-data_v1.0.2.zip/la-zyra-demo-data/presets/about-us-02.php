<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_about_us_02()
{
    return array(

        array(
            'key' => 'logo_transparency',
            'value' => '822'
        ),
        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_height|header_sticky_height',
            'value' => '140'
        ),



        /** Color
         *
         */

        array(
            'key' => 'header_link_hover_color|header_top_link_hover_color|transparency_header_link_hover_color|transparency_header_top_link_hover_color|transparency_mm_lv_1_hover_color',
            'value' => '#ef5619'
        ),
        array(
            'key' => 'transparency_header_text_color|transparency_header_link_color|transparency_mm_lv_1_color',
            'value' => '#fff'
        ),


        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.enable-header-transparency .site-header:not(.is-sticky) .site-header-outer .header_component.la_compt_iem.la_com_action--aside_header > .component-target{
    color: #232324;
    background-color: #fff;
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'la_zyra/filter/footer_column_5',
            'value' => 'footer-maps'
        ),
    );
}