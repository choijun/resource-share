<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_blog_01(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'blog_masonry',
            'value' => 'off'
        ),
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_small_layout',
            'value' => 'on'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_4'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '770x0'
        ),
        array(
            'key' => 'blog_item_space',
            'value' => 'default'
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => 45
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg'   => '1',
                'lg'    => '1',
                'md'    => '1',
                'sm'    => '1',
                'xs'    => '1',
                'mb'    => '1'
            )
        ),
        array(
            'key' => 'main_space',
            'value' => array(
                'top' => 100
            )
        ),
        array(
            'key' => 'page_title_bar_layout_blog_global',
            'value' => 'yes'
        ),
        array(
            'filter_name' => 'la_zyra/filter/page_title',
            'value' => '<header><div class="page-title h3">Blog Style 01</div></header>'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '

                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}