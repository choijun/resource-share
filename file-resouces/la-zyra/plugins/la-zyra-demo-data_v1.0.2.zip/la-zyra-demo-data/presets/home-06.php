<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_home_06()
{
    return array(


        array(
            'key' => 'header_layout',
            'value' => '5'
        ),

        array(
            'key' => 'header_access_icon',
            'value' => array(
                array(
                    'type' => 'dropdown_menu',
                    'menu_id' => 57,
                    'icon' => 'fa fa-user-circle-o'
                ),
                array(
                    'type' => 'wishlist'
                ),
                array(
                    'type' => 'cart'
                ),
                array(
                    'type' => 'search_1'
                )
            )
        ),

        array(
            'key' => 'footer_layout',
            'value' => '1col'
        ),


        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '50px',
                'padding_bottom' => '0px',
            )
        ),

        /**
         * Colors
         */

        array(
            'key' => 'offcanvas_text_color|offcanvas_link_color',
            'value' => '#232324'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#ef5619'
        ),
        array(
            'key' => 'offcanvas_background',
            'value' => '#f9f9f9'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'la_zyra/filter/footer_column_1',
            'value' => 'demo-06-footer-column-1'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '

                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}