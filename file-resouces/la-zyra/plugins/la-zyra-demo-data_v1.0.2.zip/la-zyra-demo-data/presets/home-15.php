<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_home_15()
{
    return array(

        array(
            'key' => 'header_layout',
            'value' => '2b'
        ),
        array(
            'key' => 'header_height|header_sticky_height',
            'value' => '140'
        ),



        /** Color
         *
         */

        array(
            'key' => 'primary_color|header_link_hover_color|header_top_link_hover_color|transparency_header_link_hover_color|transparency_header_top_link_hover_color',
            'value' => '#d6c49f'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'la_zyra/filter/footer_column_5',
            'value' => 'footer-maps'
        ),

    );
}