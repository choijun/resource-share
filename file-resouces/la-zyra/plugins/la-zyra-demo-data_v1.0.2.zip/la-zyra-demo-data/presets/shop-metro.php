<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_shop_metro(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'active_shop_filter',
            'value' => 'off'
        ),

        array(
            'key' => 'hide_shop_toolbar',
            'value' => 'off'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),

        array(
            'key' => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),
        array(
            'key' => 'woocommerce_enable_crossfade_effect',
            'value' => 'off'
        ),

        array(
            'key' => 'active_shop_masonry',
            'value' => 'on'
        ),

        array(
            'key' => 'shop_item_space',
            'value' => '10'
        ),

        array(
            'key' => 'shop_catalog_grid_style',
            'value' => '4'
        ),

        array(
            'key' => 'shop_masonry_column_type',
            'value' => 'custom'
        ),

        array(
            'key' => 'product_masonry_item_width',
            'value' => '550'
        ),
        array(
            'key' => 'product_masonry_item_height',
            'value' => '400'
        ),

        array(
            'key'   => 'woocommerce_shop_masonry_custom_columns',
            'value' => array(
                'md' => 2,
                'sm' => 2,
                'xs' => 1,
                'mb' => 1
            )
        ),

        array(
            'key' => 'enable_shop_masonry_custom_setting',
            'value' => 'on'
        ),

        array(
            'key' => 'shop_masonry_item_setting',
            'value' => array(
                0 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                1 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                2 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                3 => array(
                    'size_name' => '2x2',
                    'width' => '2',
                    'height' => '2'
                ),
                4 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                5 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                6 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                7 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                8 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                9 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                ),
                10 => array(
                    'size_name' => '2x2',
                    'width' => '2',
                    'height' => '2'
                ),
                11 => array(
                    'size_name' => '1x1',
                    'width' => '1',
                    'height' => '1'
                )
            )
        ),

        array(
            'key' => 'main_space',
            'value' => array(
                'top' => 80,
                'bottom' => 80
            )
        ),
        array(
            'filter_name' => 'la_zyra/filter/page_title',
            'value' => '<header><div class="page-title h3">Shop Metro</div></header>'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.prods_masonry.cover-img-bg .product_cat-shoes .product_item--thumbnail-holder .pig-m-fallback {
    background-position: center center;
}
.wc-toolbar-container{
    display: none;
}
.section-page-header{
    background-image: url(//zyra.la-studioweb.com/wp-content/uploads/2017/11/page-title-collection.jpg);
}
@media (min-width: 1300px) {
  .site-main > .container{
    padding-left: 40px;
    padding-right: 40px;
  }
}

@media (min-width: 1400px) {
  .site-main > .container{
    padding-left: 60px;
    padding-right: 60px;
  }
}

@media (min-width: 1500px) {
  .site-main > .container{
    padding-left: 80px;
    padding-right: 80px;
  }
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}