<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_shop_sidebar(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-2cl'
        ),
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'active_shop_filter',
            'value' => 'off'
        ),
        array(
            'key' => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),

        array(
            'filter_name' => 'la_zyra/filter/page_title',
            'value' => '<header><div class="page-title h3">Shop Sidebar</div></header>'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.section-page-header{
    background-image: url(//zyra.la-studioweb.com/wp-content/uploads/2017/11/page-title-shop2.jpg);
}
@media (min-width: 1300px) {
  .site-main > .container{
    padding-left: 40px;
    padding-right: 40px;
  }
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}