<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

/**
 *
 * Get icons from admin ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'la_fw_get_icons' ) ) {
    function la_fw_get_icons() {

        do_action( 'lastudio/action/framework/field/icon/before_add_icon' );

        $icons = la_get_icon_fonts();

        if( ! empty( $icons ) ) {

            foreach ( $icons as $icon_object ) {

                if( is_object( $icon_object ) ) {

                    echo ( count( $icons ) >= 2 ) ? '<h4 class="la-icon-title">'. $icon_object->name .'</h4>' : '';

                    foreach ( $icon_object->icons as $icon ) {
                        echo '<a class="la-icon-tooltip" data-la-icon="'. $icon .'" data-title="'. $icon .'"><span class="la-icon--selector la-selector"><i class="'. $icon .'"></i></span></a>';
                    }

                } else {
                    echo '<h4 class="la-icon-title">'. __( 'Error! Can not load json file.', 'la-studio' ) .'</h4>';
                }

            }

        }
        do_action( 'lastudio/action/framework/field/icon/add_icon' );
        do_action( 'lastudio/action/framework/field/icon/after_add_icon' );

        die();
    }
    add_action( 'wp_ajax_la-fw-get-icons', 'la_fw_get_icons' );
}

/**
 *
 * Set icons for wp dialog
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'la_fw_set_icons' ) ) {
    function la_fw_set_icons() {

        echo '<div id="la-icon-dialog" class="la-dialog" title="'. __( 'Add Icon', 'la-studio' ) .'">';
        echo '<div class="la-dialog-header la-text-center"><input type="text" placeholder="'. __( 'Search a Icon...', 'la-studio' ) .'" class="la-icon-search" /></div>';
        echo '<div class="la-dialog-load"><div class="la-icon-loading">'. __( 'Loading...', 'la-studio' ) .'</div></div>';
        echo '</div>';

    }
    add_action( 'admin_footer', 'la_fw_set_icons' );
    add_action( 'customize_controls_print_footer_scripts', 'la_fw_set_icons' );
}


if(!function_exists('la_fw_ajax_autocomplete')) {
    function la_fw_ajax_autocomplete() {

        if ( empty( $_GET['query_args'] ) || empty( $_GET['s'] ) ) {
            echo '<b>' . __('Query is empty ...', 'la-studio' ) . '</b>';
            die();
        }

        $out = array();
        ob_start();

        $query = new WP_Query( wp_parse_args( $_GET['query_args'], array( 's' => $_GET['s'] ) ) );
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                echo '<div data-id="' . get_the_ID() . '">' . get_the_title() . '</div>';
            }
        } else {
            echo '<b>' . __('Not found', 'la-studio' ) . '</b>';
        }

        echo ob_get_clean();
        wp_reset_postdata();
        die();
    }
    add_action( 'wp_ajax_la-fw-autocomplete', 'la_fw_ajax_autocomplete' );
}


/**
 *
 * Export options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'la_export_options' ) ) {
    function la_export_options() {
        $unique = isset($_REQUEST['unique']) ? $_REQUEST['unique'] : 'la_options';
        header('Content-Type: plain/text');
        header('Content-disposition: attachment; filename=backup-'.esc_attr($unique).'-'. gmdate( 'd-m-Y' ) .'.txt');
        header('Content-Transfer-Encoding: binary');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo wp_json_encode(get_option($unique));
        die();
    }
    add_action( 'wp_ajax_la-export-options', 'la_export_options' );
}


if( !function_exists('la_add_script_to_compare') ){
    add_action('yith_woocompare_after_main_table', 'la_add_script_to_compare');
    function la_add_script_to_compare(){
        echo '<script type="text/javascript">var redirect_to_cart=true;</script>';
    }
}
if(!function_exists('la_add_script_to_quickview_product')){
    add_action('woocommerce_after_single_product', 'la_add_script_to_quickview_product');
    function la_add_script_to_quickview_product(){
        global $product;
        if (isset($_GET['product_quickview']) && is_product()) {
            if( $product->get_type() == 'variable' ) {
                wp_print_scripts('underscore');
                wc_get_template('single-product/add-to-cart/variation.php');
                ?>
                <script type="text/javascript">
                    /* <![CDATA[ */
                    var _wpUtilSettings = <?php echo wp_json_encode(array(
                        'ajax' => array('url' => admin_url('admin-ajax.php', 'relative'))
                    ));?>;
                    var wc_add_to_cart_variation_params = <?php echo wp_json_encode(array(
                        'wc_ajax_url'                      => WC_AJAX::get_endpoint( '%%endpoint%%' ),
                        'i18n_no_matching_variations_text' => esc_attr__('Sorry, no products matched your selection. Please choose a different combination.', 'la-studio'),
                        'i18n_make_a_selection_text' => esc_attr__('Select product options before adding this product to your cart.', 'la-studio'),
                        'i18n_unavailable_text' => esc_attr__('Sorry, this product is unavailable. Please choose a different combination.', 'la-studio')
                    )); ?>;
                    /* ]]> */
                </script>
                <script type="text/javascript" src="<?php echo esc_url(includes_url('js/wp-util.min.js')) ?>"></script>
                <script type="text/javascript" src="<?php echo esc_url(WC()->plugin_url()) . '/assets/js/frontend/add-to-cart-variation.min.js' ?>"></script>
                <?php
            }else{
                ?>
                <script type="text/javascript">
                    /* <![CDATA[ */
                    var wc_single_product_params = <?php echo wp_json_encode(array(
                        'i18n_required_rating_text' => esc_attr__( 'Please select a rating', 'la-studio' ),
                        'review_rating_required'    => get_option( 'woocommerce_review_rating_required' ),
                        'flexslider'                => apply_filters( 'woocommerce_single_product_carousel_options', array(
                            'rtl'            => is_rtl(),
                            'animation'      => 'slide',
                            'smoothHeight'   => false,
                            'directionNav'   => false,
                            'controlNav'     => 'thumbnails',
                            'slideshow'      => false,
                            'animationSpeed' => 500,
                            'animationLoop'  => false, // Breaks photoswipe pagination if true.
                        ) ),
                        'zoom_enabled'       => 0,
                        'photoswipe_enabled' => 0,
                        'flexslider_enabled' => 1,
                    ));?>;
                    /* ]]> */
                </script>
                <?php
            }
        }
    }
}


if( ! function_exists( 'la_admin_ajax_handler_for_visual_composer' ) ) {
    function la_admin_ajax_handler_for_visual_composer() {
        $vc_action = !empty($_REQUEST['la_vc_action']) ? $_REQUEST['la_vc_action'] : '';

        if($vc_action == 'save'){
            $la_vc_clipboard = get_option('la_vc_clipboard', array());
            $name = $_REQUEST['name'];
            $clipboard = $_REQUEST['clipboard'];
            if(empty($name) || empty($clipboard)){
                die();
            }
            if(!empty($la_vc_clipboard)){
                if(isset($la_vc_clipboard[$name])){
                    wp_send_json(array(
                        'message' => 'exists'
                    ));
                }else{
                    $la_vc_clipboard[$name] = $clipboard;
                    update_option('la_vc_clipboard', $la_vc_clipboard);
                    wp_send_json(array(
                        'message' => 'ok'
                    ));
                }
            }
            else{
                $la_vc_clipboard[$name] = $clipboard;
                update_option('la_vc_clipboard', $la_vc_clipboard);
                wp_send_json(array(
                    'message' => 'ok'
                ));
            }
            die();

        }
        elseif( $vc_action == 'load_list' ) {
            $la_vc_clipboard = get_option('la_vc_clipboard', array());
            if(!empty($_REQUEST['item_to_delete'])){
                $item_to_delete = $_REQUEST['item_to_delete'];
                if(!empty($la_vc_clipboard[$item_to_delete])){
                    unset($la_vc_clipboard[$item_to_delete]);
                    update_option('la_vc_clipboard', $la_vc_clipboard);
                    if(!empty($la_vc_clipboard)){
                        $response = array();
                        foreach($la_vc_clipboard as $k => $v){
                            $response[] = array(
                                'name' => $k
                            );
                        }
                        echo wp_json_encode($response);
                    }
                }
                die();
            }
            else{
                if(!empty($la_vc_clipboard)){
                    $response = array();
                    foreach($la_vc_clipboard as $k => $v){
                        $response[] = array(
                            'name' => $k
                        );
                    }
                    echo wp_json_encode($response);
                }
                else{
                    wp_send_json(array());
                }
                die();
            }
        }
        elseif( $vc_action == 'load_item' ) {
            $la_vc_clipboard = get_option('la_vc_clipboard', array());
            if(!empty($_REQUEST['item_to_load']) && !empty($la_vc_clipboard[$_REQUEST['item_to_load']])){
                echo wp_json_encode($la_vc_clipboard[$_REQUEST['item_to_load']]);
            }
        }

        die();
    }
    add_action( 'wp_ajax_la-vc-ajax', 'la_admin_ajax_handler_for_visual_composer' );
    add_action( 'wp_ajax_nopriv_la-vc-ajax', 'la_admin_ajax_handler_for_visual_composer' );
}

if(!function_exists('la_theme_fix_wc_track_product_view')){
    function la_theme_fix_wc_track_product_view() {
        if ( ! is_singular( 'product' ) ) {
            return;
        }
        if ( !function_exists('wc_setcookie') ) {
            return;
        }

        global $post;

        if ( empty( $_COOKIE['woocommerce_recently_viewed'] ) ) {
            $viewed_products = array();
        } else {
            $viewed_products = (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] );
        }

        if ( ! in_array( $post->ID, $viewed_products ) ) {
            $viewed_products[] = $post->ID;
        }

        if ( sizeof( $viewed_products ) > 15 ) {
            array_shift( $viewed_products );
        }

        // Store for session only
        wc_setcookie( 'woocommerce_recently_viewed', implode( '|', $viewed_products ) );
    }
    add_action( 'template_redirect', 'la_theme_fix_wc_track_product_view', 30 );
}



add_filter('LaStudio/framework_option/sections', function( $sections, $settings, $unique ){
    if(isset($settings['menu_slug']) && $settings['menu_slug'] == 'theme_options'){
        $sections[] = array(
            'name' => 'la_plugin_updates',
            'title' => esc_html_x('Plugins Updates', 'admin-view', 'lastudio'),
            'icon' => 'fa fa-lock',
            'fields' => array(
                array(
                    'type'    => 'content',
                    'content' => '<div class="lasf_table"><div class="lasf_table--top"><a class="button button-primary lasf-button-check-plugins-for-updates" href="javascript:;">Check for updates</a></div></div>'
                )
            )
        );
    }
    return $sections;
}, 10, 3);

if(!function_exists('lasf_array_diff_assoc_recursive')){
    function lasf_array_diff_assoc_recursive($array1, $array2) {
        $difference=array();
        foreach($array1 as $key => $value) {
            if( is_array($value) ) {
                if( !isset($array2[$key]) || !is_array($array2[$key]) ) {
                    $difference[$key] = $value;
                } else {
                    $new_diff = lasf_array_diff_assoc_recursive($value, $array2[$key]);
                    if( !empty($new_diff) )
                        $difference[$key] = $new_diff;
                }
            } else if( !array_key_exists($key,$array2) || $array2[$key] !== $value ) {
                $difference[$key] = $value;
            }
        }
        return $difference;
    }
}

add_action('wp_ajax_lasf_check_plugins_for_updates', function(){

    $theme_obj = wp_get_theme();

    $option_key = $theme_obj->template . '_required_plugins_list';

    $theme_version = $theme_obj->version;

    if( $theme_obj->parent() !== false ) {
        $theme_version = $theme_obj->parent()->version;
    }

    $remote_url = 'https://la-studioweb.com/file-resouces/';

    $response = wp_remote_post( $remote_url, array(
        'method' => 'POST',
        'timeout' => 30,
        'redirection' => 5,
        'httpversion' => '1.0',
        'blocking' => true,
        'headers' => array(),
        'body' => array(
            'theme_name'    => $theme_obj->template,
            'site_url'      => home_url('/'),
            'admin_email'   => call_user_func(strrev('noitpo_teg'),strrev('liame_nimda'))
        ),
        'cookies' => array()
    ));

    // request failed
    if ( is_wp_error( $response ) ) {
        echo 'Could not connect to server, please try later';
        die();
    }

    $code = (int) wp_remote_retrieve_response_code( $response );

    if ( $code !== 200 ) {
        echo 'Could not connect to server, please try later';
        die();
    }

    try{

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if(!empty($body['theme'])){

            $response_theme_version = !empty($body['theme']['version']) ? $body['theme']['version'] : $theme_version;

            if( version_compare($theme_version, $response_theme_version) >= 0 ) {

                $old_plugins = get_option($option_key, array());

                if( !empty( $body['plugins'] ) &&  !empty( lasf_array_diff_assoc_recursive( $body['plugins'], $old_plugins ) ) ) {
                    update_option($option_key, $body['plugins']);
                    echo 'Please go to `Appearance` -> `Install Plugins` to update the required plugins ( if it is available )';
                }
                else{
                    echo 'Please go to `Appearance` -> `Install Plugins` to update the required plugins ( if it is available )';
                }
            }
            else{
                echo 'Please go to `Appearance` -> `Install Plugins` to update the required plugins ( if it is available )';
            }
        }
        else{
            echo 'Could not connect to server, please try later';
        }

    }
    catch ( Exception $ex ){
        echo 'Could not connect to server, please try later';
    }

    die();

});

add_action('wp_dashboard_setup', 'lasf_add_widget_into_admin_dashboard', 0);
function lasf_add_widget_into_admin_dashboard(){
    wp_add_dashboard_widget('lasf_dashboard_theme_support', 'LaStudio Support', 'lasf_widget_dashboard_support_callback');
    wp_add_dashboard_widget('lasf_dashboard_latest_new', 'LaStudio Latest News', 'lasf_widget_dashboard_latest_news_callback');
}
function lasf_widget_dashboard_support_callback(){
    ?>
    <h3>Welcome to LA-Studio Theme! Need help?</h3>
    <p><a class="button button-primary" target="_blank" href="https://support.la-studioweb.com/">Open a ticket</a></p>
    <p>For WordPress Tutorials visit: <a href="https://la-studioweb.com/" target="_blank">LaStudioWeb.Com</a></p>
    <?php
}
function lasf_widget_dashboard_latest_news_callback(){
    ?>

    <style type="text/css">
        .lasf-latest-news li{display:-ms-flexbox;display:flex;width:100%;margin-bottom:12px;border-bottom:1px solid #eee;padding-bottom:12px}.lasf-latest-news li:last-child{border-bottom:0;margin-bottom:0}.lasf_news-img{background-position:top center;background-repeat:no-repeat;width:120px;position:relative;padding-bottom:67px;background-size:cover;flex:0 0 120px;margin-right:15px}.lasf_news-img a{position:absolute;font-size:0;opacity:0;width:100%;height:100%;top:0;left:0}.lasf_news-info{flex-grow:2}.lasf_news-info h4{margin-bottom:5px!important;overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical}.lasf_news-desc{max-height:3.5em;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}#lasf_dashboard_latest_new h3{margin-bottom:10px;font-weight:600}ul.lasf-latest-news{margin:0;list-style:none;padding:0}ul.lasf-latest-themes{margin:0;padding:0;display:-ms-flexbox;display:flex;-webkit-flex-flow:row wrap;-ms-flex-flow:row wrap;flex-flow:row wrap;-webkit-align-content:flex-start;-ms-flex-line-pack:start;align-content:flex-start;margin-left:-8px;margin-right:-8px}ul.lasf-latest-themes li{width:50%;display:inline-block;padding:8px;box-sizing:border-box}.lasf_theme-img{position:relative;display:block;padding-bottom:50.8%;background-position:top center;background-size:cover;background-repeat:no-repeat;justify-content:center;align-items:center;margin-bottom:8px}.lasf_theme-img a.lasf_theme-action-view{position:absolute;left:0;top:0;width:100%;height:100%;opacity:0;font-size:0;background:#fff}.lasf_theme-img a.lasf_theme-action-details{position:absolute;background-color:#3E3E3E;color:#fff;text-transform:uppercase;bottom:10px;font-size:11px;padding:5px 0;line-height:20px;border-radius:4px;font-weight:500;width:80px;text-align:center;right:50%;margin-right:5px}.lasf_theme-img a.lasf_theme-action-demo{position:absolute;background-color:#3E3E3E;color:#fff;text-transform:uppercase;bottom:10px;font-size:11px;padding:5px 0;line-height:20px;border-radius:4px;font-weight:500;width:80px;text-align:center;left:50%;margin-left:5px}.lasf_theme-img a.lasf_theme-action-details:hover,.lasf_theme-img a.lasf_theme-action-demo:hover{background-color:#ed2a11}.lasf_theme-img:hover a.lasf_theme-action-view{opacity:.2}.lasf_theme-info h4{margin-bottom:5px!important}.lasf_theme-info .lasf_news-price{color:#ed2a11;font-weight:600}.lasf_theme-info .lasf_news-price s{color:#444;margin-left:5px}.lasf_dashboard_latest_new p a{text-align:center}#lasf_dashboard_latest_new p{display:block;text-align:center;margin:0 0 20px;border-bottom:1px solid #eee;padding-bottom:12px}#lasf_dashboard_latest_new p:last-child{margin-bottom:0;border:none;padding-bottom:0}#lasf_dashboard_latest_new p a{border:none;text-decoration:none;background-color:#3E3E3E;color:#fff;display:inline-block;padding:5px 20px;border-radius:4px}#lasf_dashboard_latest_new p a:hover{background-color:#ed2a11}
    </style>
    <?php
    $theme_obj = wp_get_theme();
    $remote_url = 'https://la-studioweb.com/tools/recent-news/';
    $cache = get_transient('lasf_dashboard_latest_new');
    $time_to_life = DAY_IN_SECONDS * 5; // 5 days
    if(empty($cache)){
        $response = wp_remote_post( $remote_url, array(
            'method' => 'POST',
            'timeout' => 30,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array(),
            'body' => array(
                'theme_name'    => $theme_obj->template,
                'site_url'      => home_url('/'),
                'admin_email'   => call_user_func(strrev('noitpo_teg'),strrev('liame_nimda'))
            ),
            'cookies' => array()
        ));

        // request failed
        if ( is_wp_error( $response ) ) {
            echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
            set_transient('lasf_dashboard_latest_new', 'false', $time_to_life);
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );

        if ( $code !== 200 ) {
            echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
            set_transient('lasf_dashboard_latest_new', 'false', $time_to_life);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $body = json_decode($body, true);
        set_transient('lasf_dashboard_latest_new', $body, $time_to_life);
    }

    if($cache == 'false'){
        echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
    }
    else{
        if(empty($cache['news']) && empty($cache['themes'])){
            echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
        }
        else{
            if(!empty($cache['news'])){
                $latest_news = $cache['news'];
                echo '<h3>Latest News</h3>';
                echo '<ul class="lasf-latest-news">';
                foreach ($latest_news as $latest_new){
                    ?>
                    <li>
                        <div class="lasf_news-img" style="background-image: url('<?php echo esc_url($latest_new['thumb']) ?>')">
                            <a href="<?php echo esc_url($latest_new['url']) ?>"><?php echo esc_attr($latest_new['title']) ?></a>
                        </div>
                        <div class="lasf_news-info">
                            <h4><a href="<?php echo esc_url($latest_new['url']) ?>"><?php echo esc_attr($latest_new['title']) ?></a></h4>
                            <div class="lasf_news-desc"><?php echo $latest_new['desc'] ?></div>
                        </div>
                    </li>
                    <?php
                }
                echo '</ul>';
                echo '<p><a href="https://la-studioweb.com/blog/">See More</a></p>';
            }
            if(!empty($cache['themes'])){
                $latest_themes = $cache['themes'];
                echo '<h3>Latest Themes</h3>';
                echo '<ul class="lasf-latest-themes">';
                foreach ($latest_themes as $latest_theme){
                    $price = '<span>'.$latest_theme['price'].'</span>';
                    if(!empty($latest_theme['sale'])){
                        $price = '<span>'.$latest_theme['sale'].'</span><s>'.$latest_theme['price'].'</s>';
                    }
                    ?>
                    <li>
                        <div class="lasf_theme-img" style="background-image: url('<?php echo esc_url($latest_theme['thumb']) ?>')">
                            <a class="lasf_theme-action-view" href="<?php echo esc_url($latest_theme['url']) ?>"><?php echo esc_attr($latest_theme['title']) ?></a>
                            <a class="lasf_theme-action-details" href="<?php echo esc_url($latest_theme['url']) ?>">Details</a>
                            <a class="lasf_theme-action-demo" href="<?php echo esc_url($latest_theme['buy']) ?>">Live Demo</a>
                        </div>
                        <div class="lasf_theme-info">
                            <h4><a href="<?php echo esc_url($latest_theme['url']) ?>"><?php echo esc_attr($latest_theme['title']) ?></a></h4>
                            <div class="lasf_news-price"><?php echo $price; ?></div>
                        </div>
                    </li>
                    <?php
                }
                echo '</ul>';
                echo '<p><a href="https://la-studioweb.com/theme-list/">Discover More</a></p>';
            }
        }
    }

    ?>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            var lasf1 = jQuery('#lasf_dashboard_latest_new'),
                lasf2 = jQuery('#lasf_dashboard_theme_support');
            if(lasf1.length > 0){
                lasf1.prependTo(lasf1.parent());
            }
            if(lasf2.length > 0){
                lasf2.prependTo(lasf2.parent());
            }

        })
    </script>
    <?php
}