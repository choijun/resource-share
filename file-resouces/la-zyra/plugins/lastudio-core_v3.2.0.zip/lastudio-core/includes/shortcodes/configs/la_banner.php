<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


$shortcode_params = array(
    array(
        'type' => 'attach_image',
        'heading' => __('Upload the banner image', 'la-studio'),
        'param_name' => 'banner_id'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Design','la-studio'),
        'param_name' => 'style',
        'value' => array(
            __('Style 1','la-studio') => '1',
            __('Style 1-1','la-studio') => '1-1',
            __('Style 2','la-studio') => '2',
            __('Style 3','la-studio') => '3',
            __('Style 4','la-studio') => '4',
            __('Style 5','la-studio') => '5',
            __('Style 6','la-studio') => '6',
            __('Style 7','la-studio') => '7',
            __('Style 8','la-studio') => '8',
            __('Style 9','la-studio') => '9'
        ),
        'std' => '1'
    ),

    array(
        'type' => 'vc_link',
        'heading' => __('Banner Link', 'la-studio'),
        'param_name' => 'banner_link',
        'description' => __('Add link / select existing page to link to this banner', 'la-studio')
    ),


    array(
        'type' => 'textfield',
        'heading' => __( 'Banner Title 1', 'la-studio' ),
        'param_name' => 'title_1',
        'admin_label' => true
    ),

    array(
        'type' => 'textfield',
        'heading' => __( 'Banner Title 2', 'la-studio' ),
        'param_name' => 'title_2',
        'admin_label' => true,
        'dependency' => array(
            'element' => 'style',
            'value' => array('5', '6', '7', '8', '9')
        ),
    ),
    array(
        'type' => 'textfield',
        'heading' => __( 'Banner Title 3', 'la-studio' ),
        'param_name' => 'title_3',
        'admin_label' => true,
        'dependency' => array(
            'element' => 'style',
            'value' => array('9')
        ),
    ),

    LaStudio_Shortcodes_Helper::fieldExtraClass(),
    LaStudio_Shortcodes_Helper::fieldExtraClass(array(
        'heading' 		=> __('Extra class name for title 1', 'la-studio'),
        'param_name' 	=> 'el_class1',
    )),
    LaStudio_Shortcodes_Helper::fieldExtraClass(array(
        'heading' 		=> __('Extra class name for title 2', 'la-studio'),
        'param_name' 	=> 'el_class2',
        'dependency' => array(
            'element' => 'style',
            'value' => array('5', '6', '7', '8', '9')
        )
    )),
    LaStudio_Shortcodes_Helper::fieldExtraClass(array(
        'heading' 		=> __('Extra class name for title 3', 'la-studio'),
        'param_name' 	=> 'el_class3',
        'dependency' => array(
            'element' => 'style',
            'value' => array('9')
        )
    )),
);

$param_fonts_title1 = LaStudio_Shortcodes_Helper::fieldTitleGFont('title_1', __('Title 1', 'la-studio'));
$param_fonts_title2 = LaStudio_Shortcodes_Helper::fieldTitleGFont('title_2', __('Title 2', 'la-studio'), array(
    'element' => 'style',
    'value' => array('5', '6', '7', '8', '9')
));
$param_fonts_title3 = LaStudio_Shortcodes_Helper::fieldTitleGFont('title_3', __('Title 3', 'la-studio'), array(
    'element' => 'style',
    'value' => array('9')
));


$shortcode_params = array_merge( $shortcode_params, $param_fonts_title1, $param_fonts_title2, $param_fonts_title3);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Banner Box', 'la-studio'),
        'base'			=> 'la_banner',
        'icon'          => 'la-wpb-icon la_banner',
        'category'  	=> __('La Studio', 'la-studio'),
        'description'   => __('Displays the banner image with Information', 'la-studio'),
        'params' 		=> $shortcode_params
    ),
    'la_banner'
);