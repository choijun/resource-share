<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


$shortcode_params = array(
    array(
        'type' => 'textarea',
        'heading' => __('Title', 'la-studio'),
        'param_name' => 'content'
    ),

    LaStudio_Shortcodes_Helper::fieldColumn(array(
        'heading' 		=> __('Items to show', 'la-studio')
    )),
    LaStudio_Shortcodes_Helper::getParamItemSpace(array(
        'std' => 'default'
    )),

    array(
        'type'       => 'checkbox',
        'heading'    => __('Enable slider', 'la-studio' ),
        'param_name' => 'enable_carousel',
        'value'      => array( __( 'Yes', 'la-studio' ) => 'yes' )
    ),

    array(
        'type' => 'textfield',
        'heading' => __('Limit', 'la-studio'),
        'description' => __('Maximum number of Images to add. Max of 12', 'la-studio'),
        'param_name' => 'limit',
        'admin_label' => true,
        'value' => 5
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Image size','la-studio'),
        'param_name' => 'image_size',
        'value' => array(
            __('Thumbnail','la-studio') => 'thumbnail',
            __('Low Resolution','la-studio') => 'low_resolution',
            __('Standard Resolution','la-studio') => 'standard_resolution'
        ),
        'std' => 'thumbnail'
    ),
    array(
        'type' => 'dropdown',
        'heading' => __('Image Aspect Ration','la-studio'),
        'param_name' => 'image_aspect_ration',
        'value' => array(
            __('1:1','la-studio') => '11',
            __('16:9','la-studio') => '169',
            __('4:3','la-studio') => '43',
            __('2.35:1','la-studio') => '2351'
        ),
        'std' => '11'
    ),
    LaStudio_Shortcodes_Helper::fieldExtraClass()
);

$carousel = LaStudio_Shortcodes_Helper::paramCarouselShortCode(false);
$slides_column_idx = LaStudio_Shortcodes_Helper::getParamIndex( $carousel, 'slides_column');
if($slides_column_idx){
    unset($carousel[$slides_column_idx]);
}

$shortcode_params = array_merge( $shortcode_params, $carousel);

return apply_filters(
    'LaStudio/shortcodes/configs',
    array(
        'name'			=> __('Instagram Feed', 'la-studio'),
        'base'			=> 'la_instagram_feed',
        'icon'          => 'la-wpb-icon la_instagram_feed',
        'category'  	=> __('La Studio', 'la-studio'),
        'description'   => __('Display Instagram photos from any non-private Instagram accounts', 'la-studio'),
        'params' 		=> $shortcode_params
    ),
    'la_instagram_feed'
);