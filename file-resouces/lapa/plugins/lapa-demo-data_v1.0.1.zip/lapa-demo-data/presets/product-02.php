<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_lapa_preset_product_02()
{
    return array(
        array(
            'key' => 'woocommerce_product_page_design',
            'value' => 2
        )
    );
}