=== LA-Studio Core ===
Contributors: Duy Pham
Tags: core
Requires at least: 4.9
Tested up to: 4.9
Stable tag: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
This plugin use only for LA-Studio theme


== Changelog ==

= 1.0.0 =

= 1.0.1 =

= 1.0.2 =