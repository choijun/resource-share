<?php

// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}


if (!function_exists('la_log')) {
    function la_log($log)
    {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }
}


/**
 *
 * Add framework element
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if (!function_exists('la_fw_add_element')) {
    function la_fw_add_element($field = array(), $value = '', $unique = '')
    {
        $output = '';
        $depend = '';
        $sub = (isset($field['sub'])) ? 'sub-' : '';
        $unique = (isset($unique)) ? $unique : '';
        $class = 'LaStudio_Theme_Options_Field_' . strtolower($field['type']);
        $wrap_class = (isset($field['wrap_class'])) ? ' ' . $field['wrap_class'] : '';
        $el_class = (isset($field['title'])) ? sanitize_title($field['title']) : 'no-title';
        $hidden = '';
        $is_pseudo = (isset($field['pseudo'])) ? ' la-pseudo-field' : '';

        if (isset($field['dependency'])) {
            $hidden = ' hidden';
            $depend .= ' data-' . $sub . 'controller="' . $field['dependency'][0] . '"';
            $depend .= ' data-' . $sub . 'condition="' . $field['dependency'][1] . '"';
            $depend .= ' data-' . $sub . 'value="' . $field['dependency'][2] . '"';
        }

        $output .= '<div class="la-element la-element-' . $el_class . ' la-field-' . $field['type'] . $is_pseudo . $wrap_class . $hidden . '"' . $depend . '>';

        if (isset($field['title'])) {
            $field_desc = (isset($field['desc'])) ? '<p class="la-text-desc">' . $field['desc'] . '</p>' : '';
            $output .= '<div class="la-title"><h4>' . $field['title'] . '</h4>' . $field_desc . '</div>';
        }

        $output .= (isset($field['title'])) ? '<div class="la-fieldset">' : '';

        $value = (!isset($value) && isset($field['default'])) ? $field['default'] : $value;
        $value = (isset($field['value'])) ? $field['value'] : $value;

        if (class_exists($class)) {
            ob_start();
            $element = new $class($field, $value, $unique);
            $element->output();
            $output .= ob_get_clean();
        } else {
            $output .= '<p>' . __('This field class is not available!', 'lastudio') . '</p>';
        }

        $output .= (isset($field['title'])) ? '</div>' : '';
        $output .= '<div class="clear"></div>';
        $output .= '</div>';

        return $output;

    }
}


/**
 *
 * Array search key & value
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if (!function_exists('la_array_search')) {
    function la_array_search($array, $key, $value)
    {
        $results = array();
        if (is_array($array)) {
            if (isset($array[$key]) && $array[$key] == $value) {
                $results[] = $array;
            }
            foreach ($array as $sub_array) {
                $results = array_merge($results, la_array_search($sub_array, $key, $value));
            }
        }
        return $results;
    }
}

/**
 *
 * Get google font from json file
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if (!function_exists('la_get_google_fonts')) {
    function la_get_google_fonts()
    {
        $cache = wp_cache_get('google_font', 'la_studio');
        if (empty($cache)) {
            $file = plugin_dir_path(dirname(__FILE__)) . 'public/fonts/google-fonts.json';
            if (file_exists($file)) {
                $tmp = @file_get_contents($file);
                if (!is_wp_error($tmp)) {
                    $tmp = json_decode($tmp, false);
                    wp_cache_set('google_font', maybe_serialize($tmp), 'la_studio');
                    return $tmp;
                }
            }
        }
        if (empty($cache)) {
            return array();
        }
        return maybe_unserialize($cache);
    }
}


/**
 *
 * Getting POST Var
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if (!function_exists('la_get_var')) {
    function la_get_var($var, $default = '')
    {
        if (isset($_POST[$var])) {
            return $_POST[$var];
        }
        if (isset($_GET[$var])) {
            return $_GET[$var];
        }
        return $default;
    }
}

/**
 *
 * Getting POST Vars
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if (!function_exists('la_get_vars')) {
    function la_get_vars($var, $depth, $default = '')
    {
        if (isset($_POST[$var][$depth])) {
            return $_POST[$var][$depth];
        }
        if (isset($_GET[$var][$depth])) {
            return $_GET[$var][$depth];
        }
        return $default;
    }
}

if (!function_exists('la_convert_option_to_customize')) {
    function la_convert_option_to_customize($options)
    {
        $panels = array();
        foreach ($options as $section) {
            if (empty($section['sections']) && empty($section['fields'])) {
                continue;
            }

            $panel = array(
                'name' => (isset($section['name']) ? $section['name'] : uniqid()),
                'title' => $section['title'],
                'description' => (isset($section['description']) ? $section['description'] : '')
            );

            if (!empty($section['sections'])) {
                $sub_panel = array();
                foreach ($section['sections'] as $sub_section) {
                    if (!empty($sub_section['fields'])) {
                        $sub_panel2 = array(
                            'name' => (isset($sub_section['name']) ? $sub_section['name'] : uniqid()),
                            'title' => $sub_section['title'],
                            'description' => (isset($sub_section['description']) ? $sub_section['description'] : '')
                        );
                        $fields = array();
                        foreach ($sub_section['fields'] as $field) {
                            $fields[] = la_convert_field_option_to_customize($field);
                        }
                        $sub_panel2['settings'] = $fields;
                        $sub_panel[] = $sub_panel2;
                    }
                }
                $panel['sections'] = $sub_panel;
                $panels[] = $panel;
            } elseif (!empty($section['fields'])) {
                $fields = array();

                foreach ($section['fields'] as $field) {
                    $fields[] = la_convert_field_option_to_customize($field);
                }
                $panel['settings'] = $fields;
                $panels[] = $panel;
            }
        }
        return $panels;
    }
}

if (!function_exists('la_convert_field_option_to_customize')) {
    function la_convert_field_option_to_customize($field)
    {
        $backup_field = $field;
        if (isset($backup_field['id'])) {
            $field_id = $backup_field['id'];
            unset($backup_field['id']);
        } else {
            $field_id = uniqid();
        }
        if (isset($backup_field['type']) && 'wp_editor' === $backup_field['type']) {
            $backup_field['type'] = 'textarea';
        }
        $tmp = array(
            'name' => $field_id,
            'control' => array(
                'type' => 'la_field',
                'options' => $backup_field
            )
        );
        if (isset($backup_field['default'])) {
            $tmp['default'] = $backup_field['default'];
            unset($backup_field['default']);
        }
        return $tmp;
    }
}


if (!function_exists('hex2rgbUltParallax')) {
    function hex2rgbUltParallax($hex, $opacity)
    {
        $hex = str_replace("#", "", $hex);
        if (preg_match("/^([a-f0-9]{3}|[a-f0-9]{6})$/i", $hex)):
            if (strlen($hex) == 3) { // three letters code
                $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
                $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
                $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
            } else { // six letters coode
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
            }
            return 'rgba(' . implode(",", array($r, $g, $b)) . ',' . $opacity . ')';
        else:
            return "";
        endif;
    }
}
if (!function_exists('rgbaToHexUltimate')) {
    function rgbaToHexUltimate($r, $g, $b)
    {
        $hex = "#";
        $hex .= str_pad(dechex($r), 2, "0", STR_PAD_LEFT);
        $hex .= str_pad(dechex($g), 2, "0", STR_PAD_LEFT);
        $hex .= str_pad(dechex($b), 2, "0", STR_PAD_LEFT);
        return $hex;
    }
}

if (!function_exists('la_fw_get_child_shortcode_nested')) {
    function la_fw_get_child_shortcode_nested($content, $atts = null)
    {
        $res = array();
        $reg = get_shortcode_regex();
        preg_match_all('~' . $reg . '~', $content, $matches);
        if (isset($matches[2]) && !empty($matches[2])) {
            foreach ($matches[2] as $key => $name) {
                $res[$name] = $name;
            }
        }
        return $res;
    }
}

if (!function_exists('la_fw_override_shortcodes')) {
    function la_fw_override_shortcodes($content = null)
    {
        if (!empty($content)) {
            global $shortcode_tags, $backup_shortcode_tags;
            $backup_shortcode_tags = $shortcode_tags;
            $child_exists = la_fw_get_child_shortcode_nested($content);
            if (!empty($child_exists)) {
                foreach ($child_exists as $tag) {
                    $shortcode_tags[$tag] = 'la_fw_wrap_shortcode_in_div';
                }
            }
        }
    }
}

if (!function_exists('la_fw_wrap_shortcode_in_div')) {
    function la_fw_wrap_shortcode_in_div($attr, $content = null, $tag = '')
    {
        global $backup_shortcode_tags;
        return '<div class="la-item-wrap">' . call_user_func($backup_shortcode_tags[$tag], $attr, $content, $tag) . '</div>';
    }
}
if (!function_exists('la_fw_restore_shortcodes')) {
    function la_fw_restore_shortcodes()
    {
        global $shortcode_tags, $backup_shortcode_tags;
        // Restore the original callbacks
        if (isset($backup_shortcode_tags)) {
            $shortcode_tags = $backup_shortcode_tags;
        }
    }
}

if (!function_exists('la_pagespeed_detected')) {
    function la_pagespeed_detected()
    {
        return (
            isset($_SERVER['HTTP_USER_AGENT'])
            && preg_match('/GTmetrix|Page Speed/i', $_SERVER['HTTP_USER_AGENT'])
        );
    }
}

if (!function_exists('la_shortcode_custom_css_class')) {
    function la_shortcode_custom_css_class($param_value, $prefix = '')
    {
        $css_class = preg_match('/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', $param_value) ? $prefix . preg_replace('/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', '$1', $param_value) : '';
        return $css_class;
    }
}

if (!function_exists('la_build_link_from_atts')) {
    function la_build_link_from_atts($value)
    {
        $result = array('url' => '', 'title' => '', 'target' => '', 'rel' => '');
        $params_pairs = explode('|', $value);
        if (!empty($params_pairs)) {
            foreach ($params_pairs as $pair) {
                $param = preg_split('/\:/', $pair);
                if (!empty($param[0]) && isset($param[1])) {
                    $result[$param[0]] = rawurldecode($param[1]);
                }
            }
        }
        return $result;
    }
}


if (!function_exists('la_get_blank_image_src')) {
    function la_get_blank_image_src()
    {
        return 'data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==';
    }
}

if (!function_exists('la_get_product_grid_style')) {
    function la_get_product_grid_style()
    {
        return array(
            __('Design 01', 'lastudio') => '1',
            __('Design 02', 'lastudio') => '2',
            __('Design 03', 'lastudio') => '3',
            __('Design 04', 'lastudio') => '4',
            __('Design 05', 'lastudio') => '5',
            __('Design 06', 'lastudio') => '6',
            __('Design 07', 'lastudio') => '7'
        );
    }
}

if (!function_exists('la_get_product_list_style')) {
    function la_get_product_list_style()
    {
        return array(
            __('Default', 'lastudio') => 'default',
            __('Mini', 'lastudio') => 'mini'
        );
    }
}

if (!function_exists('la_export_options')) {
    function la_export_options()
    {
        $unique = isset($_REQUEST['unique']) ? $_REQUEST['unique'] : 'la_options';
        header('Content-Type: plain/text');
        header('Content-disposition: attachment; filename=backup-' . esc_attr($unique) . '-' . gmdate('d-m-Y') . '.txt');
        header('Content-Transfer-Encoding: binary');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo wp_json_encode(get_option($unique));
        die();
    }

    add_action('wp_ajax_la-export-options', 'la_export_options');
}

if (!function_exists('la_add_script_to_compare')) {
    function la_add_script_to_compare()
    {
        echo '<script type="text/javascript">var redirect_to_cart=true;</script>';
    }

    add_action('yith_woocompare_after_main_table', 'la_add_script_to_compare');
}

if (!function_exists('la_add_script_to_quickview_product')) {
    function la_add_script_to_quickview_product()
    {
        global $product;
        if (isset($_GET['product_quickview']) && is_product()) {
            if ($product->get_type() == 'variable') {
                wp_print_scripts('underscore');
                wc_get_template('single-product/add-to-cart/variation.php');
                ?>
                <script type="text/javascript">
                    /* <![CDATA[ */
                    var _wpUtilSettings = <?php echo wp_json_encode(array(
                        'ajax' => array('url' => admin_url('admin-ajax.php', 'relative'))
                    ));?>;
                    var wc_add_to_cart_variation_params = <?php echo wp_json_encode(array(
                        'wc_ajax_url'                      => WC_AJAX::get_endpoint( '%%endpoint%%' ),
                        'i18n_no_matching_variations_text' => esc_attr__('Sorry, no products matched your selection. Please choose a different combination.', 'lastudio'),
                        'i18n_make_a_selection_text' => esc_attr__('Select product options before adding this product to your cart.', 'lastudio'),
                        'i18n_unavailable_text' => esc_attr__('Sorry, this product is unavailable. Please choose a different combination.', 'lastudio')
                    )); ?>;
                    /* ]]> */
                </script>
                <script type="text/javascript"
                        src="<?php echo esc_url(includes_url('js/wp-util.min.js')) ?>"></script>
                <script type="text/javascript"
                        src="<?php echo esc_url(WC()->plugin_url()) . '/assets/js/frontend/add-to-cart-variation.min.js' ?>"></script>
                <?php
            } else {
                ?>
                <script type="text/javascript">
                    /* <![CDATA[ */
                    var wc_single_product_params = <?php echo wp_json_encode(array(
                        'i18n_required_rating_text' => esc_attr__('Please select a rating', 'lastudio'),
                        'review_rating_required' => get_option('woocommerce_review_rating_required'),
                        'flexslider' => apply_filters('woocommerce_single_product_carousel_options', array(
                            'rtl' => is_rtl(),
                            'animation' => 'slide',
                            'smoothHeight' => false,
                            'directionNav' => false,
                            'controlNav' => 'thumbnails',
                            'slideshow' => false,
                            'animationSpeed' => 500,
                            'animationLoop' => false, // Breaks photoswipe pagination if true.
                        )),
                        'zoom_enabled' => 0,
                        'photoswipe_enabled' => 0,
                        'flexslider_enabled' => 1,
                    ));?>;
                    /* ]]> */
                </script>
                <?php
            }
        }
    }

    add_action('woocommerce_after_single_product', 'la_add_script_to_quickview_product');
}

if (!function_exists('la_theme_fix_wc_track_product_view')) {
    function la_theme_fix_wc_track_product_view()
    {
        if (!is_singular('product')) {
            return;
        }
        if (!function_exists('wc_setcookie')) {
            return;
        }
        global $post;
        if (empty($_COOKIE['woocommerce_recently_viewed'])) {
            $viewed_products = array();
        } else {
            $viewed_products = (array)explode('|', $_COOKIE['woocommerce_recently_viewed']);
        }
        if (!in_array($post->ID, $viewed_products)) {
            $viewed_products[] = $post->ID;
        }
        if (sizeof($viewed_products) > 15) {
            array_shift($viewed_products);
        }
        wc_setcookie('woocommerce_recently_viewed', implode('|', $viewed_products));
    }

    add_action('template_redirect', 'la_theme_fix_wc_track_product_view', 30);

}


add_filter('LaStudio/framework_option/sections', function( $sections, $settings, $unique ){
    if(isset($settings['menu_slug']) && $settings['menu_slug'] == 'theme_options'){
        $sections[] = array(
            'name' => 'la_plugin_update',
            'title' => esc_html_x('Plugins Updates', 'admin-view', 'lastudio'),
            'icon' => 'fa fa-lock',
            'fields' => array(
                array(
                    'type'    => 'content',
                    'content' => '<div class="lasf_table"><div class="lasf_table--top"><a class="button button-primary lasf-button-check-plugins-for-updates" href="javascript:;">Check for updates</a></div></div>'
                )
            )
        );
    }
    return $sections;
}, 10, 3);


if(!function_exists('lasf_array_diff_assoc_recursive')){
    function lasf_array_diff_assoc_recursive($array1, $array2) {
        $difference=array();
        foreach($array1 as $key => $value) {
            if( is_array($value) ) {
                if( !isset($array2[$key]) || !is_array($array2[$key]) ) {
                    $difference[$key] = $value;
                } else {
                    $new_diff = lasf_array_diff_assoc_recursive($value, $array2[$key]);
                    if( !empty($new_diff) )
                        $difference[$key] = $new_diff;
                }
            } else if( !array_key_exists($key,$array2) || $array2[$key] !== $value ) {
                $difference[$key] = $value;
            }
        }
        return $difference;
    }
}

add_action('wp_ajax_lasf_check_plugins_for_updates', function(){

    $theme_obj = wp_get_theme();

    $option_key = $theme_obj->template . '_required_plugins_list';

    $theme_version = $theme_obj->version;

    if( $theme_obj->parent() !== false ) {
        $theme_version = $theme_obj->parent()->version;
    }

    $remote_url = 'https://la-studioweb.com/file-resouces/';

    $response = wp_remote_post( $remote_url, array(
        'method' => 'POST',
        'timeout' => 30,
        'redirection' => 5,
        'httpversion' => '1.0',
        'blocking' => true,
        'headers' => array(),
        'body' => array(
            'theme_name'    => $theme_obj->template,
            'site_url'      => home_url('/'),
            'admin_email'   => call_user_func(strrev('noitpo_teg'),strrev('liame_nimda'))
        ),
        'cookies' => array()
    ));

    // request failed
    if ( is_wp_error( $response ) ) {
        echo 'Could not connect to server, please try later';
        die();
    }

    $code = (int) wp_remote_retrieve_response_code( $response );

    if ( $code !== 200 ) {
        echo 'Could not connect to server, please try later';
        die();
    }

    try{

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if(!empty($body['theme'])){

            $response_theme_version = !empty($body['theme']['version']) ? $body['theme']['version'] : $theme_version;

            if( version_compare($theme_version, $response_theme_version) >= 0 ) {

                $old_plugins = get_option($option_key, array());

                if( !empty( $body['plugins'] ) &&  !empty( lasf_array_diff_assoc_recursive( $body['plugins'], $old_plugins ) ) ) {
                    update_option($option_key, $body['plugins']);
                    echo 'Please go to `Appearance` -> `Install Plugins` to update the required plugins ( if it is available )';
                }
                else{
                    echo 'Please go to `Appearance` -> `Install Plugins` to update the required plugins ( if it is available )';
                }
            }
            else{
                echo 'Please go to `Appearance` -> `Install Plugins` to update the required plugins ( if it is available )';
            }
        }
        else{
            echo 'Could not connect to server, please try later';
        }

    }
    catch ( Exception $ex ){
        echo 'Could not connect to server, please try later';
    }

    die();

});

add_action('wp_dashboard_setup', 'lasf_add_widget_into_admin_dashboard', 0);
function lasf_add_widget_into_admin_dashboard(){
    wp_add_dashboard_widget('lasf_dashboard_theme_support', 'LaStudio Support', 'lasf_widget_dashboard_support_callback');
    wp_add_dashboard_widget('lasf_dashboard_latest_new', 'LaStudio Latest News', 'lasf_widget_dashboard_latest_news_callback');
}
function lasf_widget_dashboard_support_callback(){
    ?>
    <h3>Welcome to LA-Studio Theme! Need help?</h3>
    <p><a class="button button-primary" target="_blank" href="https://support.la-studioweb.com/">Open a ticket</a></p>
    <p>For WordPress Tutorials visit: <a href="https://la-studioweb.com/" target="_blank">LaStudioWeb.Com</a></p>
    <?php
}
function lasf_widget_dashboard_latest_news_callback(){
    ?>

    <style type="text/css">
        .lasf-latest-news li{display:-ms-flexbox;display:flex;width:100%;margin-bottom:12px;border-bottom:1px solid #eee;padding-bottom:12px}.lasf-latest-news li:last-child{border-bottom:0;margin-bottom:0}.lasf_news-img{background-position:top center;background-repeat:no-repeat;width:120px;position:relative;padding-bottom:67px;background-size:cover;flex:0 0 120px;margin-right:15px}.lasf_news-img a{position:absolute;font-size:0;opacity:0;width:100%;height:100%;top:0;left:0}.lasf_news-info{flex-grow:2}.lasf_news-info h4{margin-bottom:5px!important;overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical}.lasf_news-desc{max-height:3.5em;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}#lasf_dashboard_latest_new h3{margin-bottom:10px;font-weight:600}ul.lasf-latest-news{margin:0;list-style:none;padding:0}ul.lasf-latest-themes{margin:0;padding:0;display:-ms-flexbox;display:flex;-webkit-flex-flow:row wrap;-ms-flex-flow:row wrap;flex-flow:row wrap;-webkit-align-content:flex-start;-ms-flex-line-pack:start;align-content:flex-start;margin-left:-8px;margin-right:-8px}ul.lasf-latest-themes li{width:50%;display:inline-block;padding:8px;box-sizing:border-box}.lasf_theme-img{position:relative;display:block;padding-bottom:50.8%;background-position:top center;background-size:cover;background-repeat:no-repeat;justify-content:center;align-items:center;margin-bottom:8px}.lasf_theme-img a.lasf_theme-action-view{position:absolute;left:0;top:0;width:100%;height:100%;opacity:0;font-size:0;background:#fff}.lasf_theme-img a.lasf_theme-action-details{position:absolute;background-color:#3E3E3E;color:#fff;text-transform:uppercase;bottom:10px;font-size:11px;padding:5px 0;line-height:20px;border-radius:4px;font-weight:500;width:80px;text-align:center;right:50%;margin-right:5px}.lasf_theme-img a.lasf_theme-action-demo{position:absolute;background-color:#3E3E3E;color:#fff;text-transform:uppercase;bottom:10px;font-size:11px;padding:5px 0;line-height:20px;border-radius:4px;font-weight:500;width:80px;text-align:center;left:50%;margin-left:5px}.lasf_theme-img a.lasf_theme-action-details:hover,.lasf_theme-img a.lasf_theme-action-demo:hover{background-color:#ed2a11}.lasf_theme-img:hover a.lasf_theme-action-view{opacity:.2}.lasf_theme-info h4{margin-bottom:5px!important}.lasf_theme-info .lasf_news-price{color:#ed2a11;font-weight:600}.lasf_theme-info .lasf_news-price s{color:#444;margin-left:5px}.lasf_dashboard_latest_new p a{text-align:center}#lasf_dashboard_latest_new p{display:block;text-align:center;margin:0 0 20px;border-bottom:1px solid #eee;padding-bottom:12px}#lasf_dashboard_latest_new p:last-child{margin-bottom:0;border:none;padding-bottom:0}#lasf_dashboard_latest_new p a{border:none;text-decoration:none;background-color:#3E3E3E;color:#fff;display:inline-block;padding:5px 20px;border-radius:4px}#lasf_dashboard_latest_new p a:hover{background-color:#ed2a11}
    </style>
    <?php
    $theme_obj = wp_get_theme();
    $remote_url = 'https://la-studioweb.com/tools/recent-news/';
    $cache = get_transient('lasf_dashboard_latest_new');
    $time_to_life = DAY_IN_SECONDS * 5; // 5 days
    if(empty($cache)){
        $response = wp_remote_post( $remote_url, array(
            'method' => 'POST',
            'timeout' => 30,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array(),
            'body' => array(
                'theme_name'    => $theme_obj->template,
                'site_url'      => home_url('/'),
                'admin_email'   => call_user_func(strrev('noitpo_teg'),strrev('liame_nimda'))
            ),
            'cookies' => array()
        ));

        // request failed
        if ( is_wp_error( $response ) ) {
            echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
            set_transient('lasf_dashboard_latest_new', 'false', $time_to_life);
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );

        if ( $code !== 200 ) {
            echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
            set_transient('lasf_dashboard_latest_new', 'false', $time_to_life);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $body = json_decode($body, true);
        set_transient('lasf_dashboard_latest_new', $body, $time_to_life);
    }

    if($cache == 'false'){
        echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
    }
    else{
        if(empty($cache['news']) && empty($cache['themes'])){
            echo '<style>#lasf_dashboard_latest_new{ display: none !important; }</style>';
        }
        else{
            if(!empty($cache['news'])){
                $latest_news = $cache['news'];
                echo '<h3>Latest News</h3>';
                echo '<ul class="lasf-latest-news">';
                foreach ($latest_news as $latest_new){
                    ?>
                    <li>
                        <div class="lasf_news-img" style="background-image: url('<?php echo esc_url($latest_new['thumb']) ?>')">
                            <a href="<?php echo esc_url($latest_new['url']) ?>"><?php echo esc_attr($latest_new['title']) ?></a>
                        </div>
                        <div class="lasf_news-info">
                            <h4><a href="<?php echo esc_url($latest_new['url']) ?>"><?php echo esc_attr($latest_new['title']) ?></a></h4>
                            <div class="lasf_news-desc"><?php echo $latest_new['desc'] ?></div>
                        </div>
                    </li>
                    <?php
                }
                echo '</ul>';
                echo '<p><a href="https://la-studioweb.com/blog/">See More</a></p>';
            }
            if(!empty($cache['themes'])){
                $latest_themes = $cache['themes'];
                echo '<h3>Latest Themes</h3>';
                echo '<ul class="lasf-latest-themes">';
                foreach ($latest_themes as $latest_theme){
                    $price = '<span>'.$latest_theme['price'].'</span>';
                    if(!empty($latest_theme['sale'])){
                        $price = '<span>'.$latest_theme['sale'].'</span><s>'.$latest_theme['price'].'</s>';
                    }
                    ?>
                    <li>
                        <div class="lasf_theme-img" style="background-image: url('<?php echo esc_url($latest_theme['thumb']) ?>')">
                            <a class="lasf_theme-action-view" href="<?php echo esc_url($latest_theme['url']) ?>"><?php echo esc_attr($latest_theme['title']) ?></a>
                            <a class="lasf_theme-action-details" href="<?php echo esc_url($latest_theme['url']) ?>">Details</a>
                            <a class="lasf_theme-action-demo" href="<?php echo esc_url($latest_theme['buy']) ?>">Live Demo</a>
                        </div>
                        <div class="lasf_theme-info">
                            <h4><a href="<?php echo esc_url($latest_theme['url']) ?>"><?php echo esc_attr($latest_theme['title']) ?></a></h4>
                            <div class="lasf_news-price"><?php echo $price; ?></div>
                        </div>
                    </li>
                    <?php
                }
                echo '</ul>';
                echo '<p><a href="https://la-studioweb.com/theme-list/">Discover More</a></p>';
            }
        }
    }
}