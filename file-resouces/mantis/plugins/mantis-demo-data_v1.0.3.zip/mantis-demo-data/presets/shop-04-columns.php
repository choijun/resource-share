<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_mantis_preset_shop_04_columns()
{
    return array(

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1cl'
        ),

        array(
            'key' => 'woocommerce_toggle_grid_list',
            'value' => 'no'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),

        array(
            'key' => 'product_per_page_allow',
            'value' => ''
        ),

        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 4,
                'lg' => 4,
                'md' => 3,
                'sm' => 2,
                'xs' => 1,
                'mb' => 1
            )
        ),


        array(
            'filter_name' => 'mantis/filter/page_title',
            'value' => '<header><h1 class="page-title h1">Shop 04 Columns</h1></header>'
        ),
    );
}