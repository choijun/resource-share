<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_03(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-02-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'footer-column-useful-link'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_3',
            'value' => 'footer-column-gallery'
        )
    );
}