<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_04(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Poppins',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-04-footer-column-1'
        )
    );
}