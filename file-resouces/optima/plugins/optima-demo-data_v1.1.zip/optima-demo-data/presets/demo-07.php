<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_07(){
    return array(
        array(
            'key' => 'logo',
            'value' => 1905
        ),
        array(
            'key' => 'logo_2x',
            'value' => 1906
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 1903
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 1904
        ),
        array(
            'key' => 'header_layout',
            'value' => 3
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Roboto Condensed',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Roboto Condensed',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'highlight_font',
            'value' => array (
                'family' => 'Roboto Condensed',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_hover_bg_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '4col3333'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#232324'
            )
        ),
        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#232324'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.site-footer .widget .widget-title{text-transform: uppercase}.footer-column .widget .yikes-easy-mc-form .yikes-easy-mc-submit-button{color: #000}.footer-column .widget .yikes-easy-mc-form .yikes-easy-mc-submit-button:hover{background: #000;color: #fff}'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-07-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_3',
            'value' => 'footer-column-useful-link'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_4',
            'value' => 'home-07-footer-column-4'
        )
    );
}