<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_09(){
    return array(
        array(
            'key' => 'logo_transparency',
            'value' => 2525
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2526
        ),
        array(
            'key' => 'header_layout',
            'value' => 6
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Roboto',
                'font' => 'google',
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Roboto',
                'font' => 'google',
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#232324'
            )
        ),
        array(
            'key' => 'header_text_color',
            'value' => '#9d9d9d'
        ),
        array(
            'key' => 'header_link_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#1c1c1c'
            )
        ),
        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#1c1c1c'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-09-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'home-09-footer-column-2'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_3',
            'value' => 'home-09-footer-column-3'
        )
    );
}