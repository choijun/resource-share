<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_11(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2562
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2563
        ),
        array(
            'key' => 'header_layout',
            'value' => 5
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'yes'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#fff'
            )
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'offcanvas_text_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_heading_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_link_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'fashion-footer-column-1'
        )
    );
}