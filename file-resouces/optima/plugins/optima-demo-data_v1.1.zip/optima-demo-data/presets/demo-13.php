<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_13(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Roboto',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Roboto Condensed',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#ff6577'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#ff6577'
        )
    );
}