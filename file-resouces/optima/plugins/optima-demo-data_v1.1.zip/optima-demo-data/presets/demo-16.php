<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_16(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_layout',
            'value' => 8
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '2col66'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#ffffff'
            )
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#526df9'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-16-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'home-16-footer-column-2'
        ),
    );
}