<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_17(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 8
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '1col12'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#ffffff'
            )
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#526df9'
        ),
        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_copyright_text_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_copyright_link_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_copyright_link_hover_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.site-footer .widget{ margin-bottom: 0 } .footer-bottom .footer-bottom-inner{ padding-bottom: 50px}'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-17-footer-column-1'
        ),
    );
}