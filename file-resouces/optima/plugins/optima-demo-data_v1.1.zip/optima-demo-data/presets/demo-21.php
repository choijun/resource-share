<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_21(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2600
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2601
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2600
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2601
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Roboto Slab',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Roboto Slab',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.footer-top{padding: 40px 0 20px}'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-19-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'home-19-footer-column-2'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_3',
            'value' => 'home-19-footer-column-3'
        )
    );
}