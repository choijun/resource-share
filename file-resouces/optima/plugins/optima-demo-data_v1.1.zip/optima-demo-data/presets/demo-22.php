<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_22(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2616
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2617
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2618
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2619
        ),
        array(
            'key' => 'logo_mobile',
            'value' => 2616
        ),
        array(
            'key' => 'logo_mobile_2x',
            'value' => 2617
        ),
        array(
            'key' => 'header_layout',
            'value' => 4
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Merriweather',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Merriweather',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'highlight_font',
            'value' => array (
                'family' => 'Roboto Slab',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '1col12'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#282828'
            )
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#9d9d9d'
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#9d9d9d'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#9d9d9d'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-22-footer-column-1'
        )
    );
}