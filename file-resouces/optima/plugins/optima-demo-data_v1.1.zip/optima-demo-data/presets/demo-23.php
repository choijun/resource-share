<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_23(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2633
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2634
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2633
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2634
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Playfair Display',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),
        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#232324'
            )
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#6c6c6c'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#6c6c6c'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#eede56'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.footer-top{padding: 45px 15px 10px}'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-23-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'home-23-footer-column-2'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_3',
            'value' => 'home-23-footer-column-3'
        )
    );
}