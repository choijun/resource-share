<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_24(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2546
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2547
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2546
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2547
        ),
        array(
            'key' => 'header_layout',
            'value' => 10
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Merriweather',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#5097f7'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#f7f7f7'
            )
        ),
        array(
            'key' => 'offcanvas_text_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_heading_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_link_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#5097f7'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#5097f7'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#5097f7'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#5097f7'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#5097f7'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '1col12'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '#masthead_aside .header-right{display:none}'
        ),
        array(
            'filter_name' => 'optima/filter/aside_widget_bottom',
            'value' => 'home-24-header-aside'
        )
    );
}