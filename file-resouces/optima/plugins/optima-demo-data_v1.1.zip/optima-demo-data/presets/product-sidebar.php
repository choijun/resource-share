<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_product_sidebar(){
    return array(
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'layout_single_product',
            'value' => 'col-2cr'
        ),
        array(
            'key' => 'related_products_columns',
            'value' => array(
                'xlg' => 3,
                'lg' => 3,
                'md' => 3,
                'sm' => 2,
                'xs' => 2,
                'mb' => 1
            )
        ),
        array(
            'filter_name' => 'optima/filter/page_title',
            'value' => '<header><div class="page-title h1">Single Right Sidebar</div></header>'
        ),
        array(
            'filter_name' => 'optima/setting/option/get_woo_page_title_bar_background',
            'value' => array(
                'image' => 'http://optima.la-studioweb.com/wp-content/uploads/2017/03/shop-page-header2.jpg',
                'repeat' => 'no-repeat',
                'position' => 'center top',
                'attachment' => 'scroll',
                'size' => 'cover'
            )
        )
    );
}