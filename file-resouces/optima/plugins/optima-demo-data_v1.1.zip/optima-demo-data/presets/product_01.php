<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_product_01(){
    return array(
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'woocommerce_product_page_design',
            'value' => '1'
        ),
        array(
            'filter_name' => 'optima/filter/page_title',
            'value' => '<header><div class="page-title h1">Design 01</div></header>'
        ),
        array(
            'filter_name' => 'optima/setting/option/get_woo_page_title_bar_background',
            'value' => array(
                'image' => 'http://optima.la-studioweb.com/wp-content/uploads/2017/03/shop-page-header2.jpg',
                'repeat' => 'no-repeat',
                'position' => 'center top',
                'attachment' => 'scroll',
                'size' => 'cover'
            )
        )
    );
}