<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_related_post_3(){
    return array(
        array(
            'key' => 'blog_related_posts',
            'value' => 'on'
        ),
        array(
            'key' => 'blog_related_design',
            'value' => 3
        ),
        array(
            'key' => 'blog_related_by',
            'value' => 'random'
        ),
        array(
            'key' => 'blog_related_max_post',
            'value' => 2
        )
    );
}