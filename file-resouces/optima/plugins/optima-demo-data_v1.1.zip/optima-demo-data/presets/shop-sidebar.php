<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_shop_sidebar(){
    return array(
        array(
            'key' => 'layout_archive_product',
            'value' => 'col-2cr'
        ),
        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 3,
                'lg' => 3,
                'md' => 2,
                'sm' => 3,
                'xs' => 1,
                'mb' => 1
            )
        ),
        array(
            'key' => 'product_per_page_default',
            'value' => 12
        ),
        array(
            'filter_name' => 'optima/filter/page_title',
            'value' => '<header><div class="page-title h1">Shop Sidebar</div></header>'
        ),
        array(
            'filter_name' => 'optima/setting/option/get_woo_page_title_bar_background',
            'value' => array(
                'image' => 'http://optima.la-studioweb.com/wp-content/uploads/2017/03/shop-page-header2.jpg',
                'repeat' => 'repeat',
                'position' => 'left top',
                'attachment' => 'fixed'
            )
        )
    );
}