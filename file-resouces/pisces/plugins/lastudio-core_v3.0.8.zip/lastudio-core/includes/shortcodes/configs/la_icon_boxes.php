<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

if ( !class_exists( 'WPBakeryShortCode_la_icon_boxes' ) ) {
	class WPBakeryShortCode_la_icon_boxes extends LaStudio_Shortcodes_Abstract{

	}
}

$icon_type = LaStudio_Shortcodes_Helper::fieldIconType();
$icon_type[0]['value'][__( 'Custom Number', 'la-studio') ] = 'number';
$icon_type[] = array(
	'type' => 'textfield',
	'heading' => __('Enter the number', 'la-studio'),
	'param_name' => 'custom_number',
	'dependency' => array(
		'element' => 'icon_type',
		'value' => 'number'
	)
);

$shortcode_params = array(
	array(
		'type' => 'textfield',
		'heading' => __('Heading', 'la-studio'),
		'param_name' => 'title',
		'admin_label' => true,
		'description' => __('Provide the title for this icon boxes.', 'la-studio'),
	),
	array(
		'type' => 'textarea_html',
		'heading' => __('Description', 'la-studio'),
		'param_name' => 'content',
		'description' => __('Provide the description for this icon box.', 'la-studio'),
	),
	// Select link option - to box or with read more text
	array(
		'type' 			=> 'dropdown',
		'heading' 		=> __('Apply link to:', 'la-studio'),
		'param_name' 	=> 'read_more',
		'value' 		=> array(
			__('No Link','la-studio') => 'none',
			__('Complete Box','la-studio') => 'box',
			__('Box Title','la-studio') => 'title',
			__('Icon','la-studio') => 'icon'
		)
	),
	// Add link to existing content or to another resource
	array(
		'type' 			=> 'vc_link',
		'heading' 		=> __('Add Link', 'la-studio'),
		'param_name' 	=> 'link',
		'description' 	=> __('Add a custom link or select existing page. You can remove existing link as well.', 'la-studio'),
		'dependency' 	=> array(
			'element' 	=> 'read_more',
			'value' 	=> array('box','title','icon')
		)
	),
	array(
		'type'	=> 'dropdown',
		'heading'	=> __('Icon Position', 'la-studio'),
		'param_name' => 'icon_pos',
		'value'	=> array(
			__('Icon at left with heading', 'la-studio') => 'default',
			__('Icon at Right with heading', 'la-studio') => 'heading-right',
			__('Icon at Left', 'la-studio') => 'left',
			__('Icon at Right', 'la-studio') => 'right',
			__('Icon at Top', 'la-studio') => 'top',
		),
		'std' => 'default',
		'description' => __('Select icon position. Icon box style will be changed according to the icon position.', 'la-studio'),
		'group' => __('Icon Settings', 'la-studio')
	),

	array(
		'type' => 'dropdown',
		'heading' => __('Icon Styles', 'la-studio'),
		'param_name' => 'icon_style',
		'description' => __('We have given four quick preset if you are in a hurry. Otherwise, create your own with various options.', 'la-studio'),
		'std'	=> 'simple',
		'value' => array(
			__('Simple', 'la-studio') => 'simple',
			__('Circle Background', 'la-studio') => 'circle',
			__('Square Background', 'la-studio') => 'square',
			__('Round Background', 'la-studio') => 'round',
			__('Advanced', 'la-studio') => 'advanced',
		),
		'group' => __('Icon Settings', 'la-studio')
	),

	array(
		'type' => 'la_number',
		'heading' => __('Icon Size', 'la-studio'),
		'param_name' => 'icon_size',
		'value' => 30,
		'min' => 10,
		'suffix' => 'px',
		'group' => __('Icon Settings', 'la-studio')
	),
	array(
		'type' => 'la_number',
		'heading' => __('Icon Box Width', 'la-studio'),
		'param_name' => 'icon_width',
		'value' => 30,
		'min' => 10,
		'suffix' => 'px',
		'group' => __('Icon Settings', 'la-studio'),
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('circle','square','round','advanced')
		),
	),
	array(
		'type' => 'la_number',
		'heading' => __('Icon Padding', 'la-studio'),
		'param_name' => 'icon_padding',
		'value' => 0,
		'min' => 0,
		'suffix' => 'px',
		'group' => __('Icon Settings', 'la-studio'),
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('advanced')
		)
	),
	array(
		'type' 		=> 'dropdown',
		'heading' 	=> __('Icon Color Type', 'la-studio'),
		'param_name'=> 'icon_color_type',
		'std'		=> 'simple',
		'value' 	=> array(
			__('Simple', 'la-studio') => 'simple',
			__('Gradient', 'la-studio') => 'gradient',
		),
		'group' 	=> __('Icon Settings', 'la-studio')
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Color', 'la-studio'),
		'param_name'=> 'icon_color',
		'group' 	=> __('Icon Settings', 'la-studio')
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Hover Color', 'la-studio'),
		'param_name'=> 'icon_h_color',
		'group' 	=> __('Hover Style', 'la-studio')
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Color #2', 'la-studio'),
		'param_name'=> 'icon_color2',
		'group' 	=> __('Icon Settings', 'la-studio'),
		'dependency' => array(
			'element' 	=> 'icon_color_type',
			'value' 	=> array('gradient')
		)
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Hover Color #2', 'la-studio'),
		'param_name'=> 'icon_h_color2',
		'dependency' => array(
			'element' 	=> 'icon_color_type',
			'value' 	=> array('gradient')
		),
		'group' 	=> __('Hover Style', 'la-studio')
	),

	array(
		'type' 		=> 'dropdown',
		'heading' 	=> __('Icon Background Type', 'la-studio'),
		'param_name'=> 'icon_bg_type',
		'std'		=> 'simple',
		'value' 	=> array(
			__('Simple', 'la-studio') => 'simple',
			__('Gradient', 'la-studio') => 'gradient',
		),
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('circle','square','round','advanced')
		),
		'group' 	=> __('Icon Settings', 'la-studio')
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Background Color', 'la-studio'),
		'param_name'=> 'icon_bg',
		'dependency'=> array(
			'element' 	=> 'icon_style',
			'value' 	=> array('circle','square','round','advanced')
		),
		'group' 	=> __('Icon Settings', 'la-studio')
	),
	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Hover Background Color', 'la-studio'),
		'param_name'=> 'icon_h_bg',
		'dependency'=> array(
			'element' 	=> 'icon_style',
			'value' 	=> array('circle','square','round','advanced')
		),
		'group' 	=> __('Hover Style', 'la-studio')
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Background Color #2', 'la-studio'),
		'param_name'=> 'icon_bg2',
		'dependency'=> array(
			'element' 	=> 'icon_bg_type',
			'value' 	=> array('gradient')
		),
		'group' 	=> __('Icon Settings', 'la-studio')
	),

	array(
		'type' 		=> 'colorpicker',
		'heading' 	=> __('Icon Hover Background Color #2', 'la-studio'),
		'param_name'=> 'icon_h_bg2',
		'dependency'=> array(
			'element' 	=> 'icon_bg_type',
			'value' 	=> array('gradient')
		),
		'group' 	=> __('Hover Style', 'la-studio')
	),

	array(
		'type' => 'dropdown',
		'heading' => __('Icon Border Style', 'la-studio'),
		'param_name' => 'icon_border_style',
		'value' => array(
			__('None', 'la-studio') => '',
			__('Solid', 'la-studio') => 'solid',
			__('Dashed', 'la-studio') => 'dashed',
			__('Dotted', 'la-studio') => 'dotted',
			__('Double', 'la-studio') => 'double',
		),
		'group' => __('Icon Settings', 'la-studio')
	),
	array(
		'type' => 'la_number',
		'heading' => __('Icon Border Width', 'la-studio'),
		'param_name' => 'icon_border_width',
		'value' => 1,
		'min' => 1,
		'max' => 10,
		'suffix' => 'px',
		'dependency' => array(
			'element' 	=> 'icon_border_style',
			'not_empty' 	=> true
		),
		'group' => __('Icon Settings', 'la-studio')
	),
	array(
		'type' => 'colorpicker',
		'heading' => __('Icon Border Color', 'la-studio'),
		'param_name' => 'icon_border_color',
		'dependency' => array(
			'element' 	=> 'icon_border_style',
			'not_empty' 	=> true
		),
		'group' => __('Icon Settings', 'la-studio')
	),

	array(
		'type' => 'colorpicker',
		'heading' => __('Icon Hover Border Color', 'la-studio'),
		'param_name' => 'icon_h_border_color',
		'dependency' => array(
			'element' 	=> 'icon_border_style',
			'not_empty' 	=> true
		),
		'group' => __('Hover Style', 'la-studio')
	),

	array(
		'type' => 'la_number',
		'heading' => __('Icon Border Radius', 'la-studio'),
		'param_name' => 'icon_border_radius',
		'value' => 500,
		'min' => 1,
		'suffix' => 'px',
		'description' => __('0 pixel value will create a square border. As you increase the value, the shape convert in circle slowly. (e.g 500 pixels).', 'la-studio'),
		'dependency' => array(
			'element' 	=> 'icon_style',
			'value' 	=> array('advanced')
		),
		'group' => __('Icon Settings', 'la-studio')
	),



	LaStudio_Shortcodes_Helper::fieldExtraClass(),
	LaStudio_Shortcodes_Helper::fieldExtraClass(array(
		'heading' 		=> __('Extra Class for heading', 'la-studio'),
		'param_name' 	=> 'title_class',
	)),
	LaStudio_Shortcodes_Helper::fieldExtraClass(array(
		'heading' 		=> __('Extra Class for description', 'la-studio'),
		'param_name' 	=> 'desc_class',
	))
);

$title_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont();
$desc_google_font_param = LaStudio_Shortcodes_Helper::fieldTitleGFont('desc', __('Description', 'la-studio'));

$shortcode_params = array_merge( $icon_type, $shortcode_params, $title_google_font_param, $desc_google_font_param, array(LaStudio_Shortcodes_Helper::fieldCssClass()) );

return apply_filters(
	'LaStudio/shortcodes/configs',
	array(
		'name'			=> __('Icon boxes', 'la-studio'),
		'base'			=> 'la_icon_boxes',
		'icon'          => 'la-wpb-icon la_icon_boxes',
		'category'  	=> __('La Studio', 'la-studio'),
		'description' 	=> __('Adds icon box with custom font icon','la-studio'),
		'params' 		=> $shortcode_params
	),
    'la_icon_boxes'
);